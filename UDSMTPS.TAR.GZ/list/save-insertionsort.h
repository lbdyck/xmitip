/**
    $Id: save-insertionsort.h,v 1.1 2005/04/11 22:08:17 mike Exp $

    Template routine for doing an insertion sort.  Define approriate
    macros, function header, and then include this file.
**/

/**
    Do an insertion sort on the list.  The list must have more than
    one object.

    From Knuth, Searching and Sorting.  Copy the object pointers
    to an array and do an insertion sort.  Then reconstruct into
    a list.

    We do it this way rather than moving object and length pointers
    so that contexts remain valid.

    Interestingly, this routine contributes little to the run-time.
    Put a return as the first statement and compare the run-times
    if you do not believe me.
**/

{
    PTobjlist pobj;		/* Used to iterate over the list */
    PTobjlist objects[ INS_BE+2 ];/* Array of objects in the list */
    PTobjlist object;		/* Current node to insert */

    int i;
    int j;

/*
    Extract to an array.  Note that the first list entry is the node
    prior to the first one we want to sort, and that the last node
    we don't sort either.  The 'cnt' accurately reflects the
    number of nodes to sort, this loop runs for an extra 2 nodes.
*/

    for( i = 0, pobj = H; i < cnt+2; i++, pobj = pobj->next ) {
	objects[i] = pobj;
    }

/*
    Insertion sort.  Note we skip the first entry, which is just a
    dummy.
*/

    for( j = 2; j < cnt+1; j++ ) {
        for( i = j - 1, object = objects[j]; i > 0 ; --i) {
	    if ((cmprtn) CMPARGS( object->object, object->len,
			          objects[i]->object, objects[i]->len, ci ) >=0)
		break;

	    objects[i+1] = objects[i];
        }
	objects[i+1] = object;
    }

/*
    Reconstruct the list.  We need to set pointers for the node prior
    to the first node to sort, plus all the nodes we sorted.
*/

    for( i = 0; i < cnt+1; i++ ) {
	objects[i]->next = objects[i+1];
    }
}

/**
    End of InsertionSort.
**/

/**
    End of insertionsort.h
**/
