/**
    UDSMTP - Simple SMTP client.
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: genincl.h,v 1.1.1.1 1999/03/15 16:25:15 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    Things that differ from system to system.
**/

#if !defined(GENINCL)
#define GENINCL 1

#if defined(I370)
#   include "mvscfg.h"
#else
#   if defined(HAVE_CONFIG_H)
#	include "config.h"
#   endif
#endif

#if defined(STDC_HEADERS)
#   include <stdarg.h>
#   include <string.h>
#   include <ctype.h>
#   include <stdlib.h>
#   include <stdio.h>
#   include <errno.h>
#else
#   include <stdio.h>
#   if defined(HAVE_STRING_H)
#	include <string.h>
#   endif
#   if defined(HAVE_STRINGS_H)
#	include <strings.h>
#   endif
#   if !defined(HAVE_STRCHR)
#	define strchr index
#	define strrchr rindex
#   endif
#   if defined(HAVE_ERRNO_H)
#	include <errno.h>
#   endif
#   if defined(HAVE_MALLOC_H)
#	include <malloc.h>
#   endif
#   if defined(HAVE_MATH_H)
#	include <math.h>
#   endif
#   if defined(HAVE_MEMORY_H)
#	include <memory.h>
#   endif
#   if defined(HAVE_STDLIB_H)
#	include <stdlib.h>
#   endif
#   if defined(HAVE_STDARG_H)
#	include <stdarg.h>
#   endif
#   if defined(HAVE_VARARGS_H)
#	include <varargs.h>
#   endif
#   if !defined(HAVE_STRING_H) && !defined(HAVE_STRINGS_H)
char * strchr();
char * strrchr();
#   endif
#   if !defined(HAVE_MEMCPY)
#	define memcpy( d, s, n ) bcopy( (s), (d), (n))
#   endif
#   if !defined(HAVE_MEMMOVE)
#	define memmove( d, s, n ) bcopy( (s), (d), (n))
#   endif
#   if !defined(HAVE_MEMSET)
#	define memset( s, b, l ) \
	    if (b != 0) exit( 99 ); \
	    bzero( s, l )
#   endif
#endif


#if defined(HAVE_UNISTD_H)
#   include <unistd.h>
#else
#   if defined(HAVE_FCNTL_H)
#	include <fcntl.h>
#   endif
#   if defined(HAVE_GETHOSTNAME)
#	if defined(__STDC__)
int gethostname( char * namebuff, int namebufflen );
#	else
int gethostname();
#	endif
#   endif
#endif

#if defined(I370)
#   include <lcstring.h>
#   include <lcio.h>
#   include <lclib.h>
#else
#   define UNIX 1
#endif

#define ASCII_COMPILER ('1' == 49)
#define EBCDIC_COMPILER ('1' == 0xf1)

#define TRUE (1 == 1)
#define FALSE (1 == 0)
#define LOOP while TRUE
#define DIM( x ) (sizeof( (x) )/sizeof( (x)[0] ))

/*
    Add defines for locally emulated routines whose need is
    detected by './configure'.
*/

#if !defined(HAVE_STRERROR)
char * strerror();
#endif

#endif	    /* GENINCL */

/**
    End of Genincl.h
**/
