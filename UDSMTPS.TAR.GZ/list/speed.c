#include <stdio.h>
#include <stdlib.h>
#include <time.h>
#include <glib.h>
#include <string.h>
#include "list.h"

#define M 1
#define N (1000000/M)

static char buff[ 30 * N * 4 ];
static char * buffp = buff;
static char headers[ ((sizeof( void * ) * 3) + sizeof( int )) * N * 4 ];
static char * headersp = headers;

static void * alloc( int len, enum ListFlags f, void * dummy )
{
    void * r;

    if ( f == ListMemNode ) {
	r = headersp;
	headersp += len;
    } else if (f == ListMemObject) {
	r = buffp;
	buffp += len;
    } else {
	r = malloc( len );
    }

    return( r );
}

static int cmp = 0;

#define DISPLAY_COMPARISONS 0
int qstrcmp( const void * p1, const void * p2 )
{
    cmp++;
#if DISPLAY_COMPARISONS
    printf( "'%s', '%s'\n", *((char **) p1), *((char **) p2) );
#endif
    return( strcmp( *((char **) p1), *((char **) p2) ) );
}

int lqstrcmp( const void * p1, const void * p2 )
{
    cmp++;
#if DISPLAY_COMPARISONS
    printf( "'%s', '%s'\n", (char *) p1, (char *) p2 );
#endif
    return( strcmp( (char *) p1, (char *) p2 ) );
}

int main( int argc, char * argv[] )
{
    PTobjlistHeader hmain;
    PTobjlistHeader h1;
    PTobjlistHeader h2;
    GList *glist = NULL;
    int i;
    PTobjectArray a;
    clock_t start, end;

    hmain = ListCreate();

/*    srand48( (long) time( NULL ) ); */

    for( i = N; i > 0; i-- ) {
	char buff[ 20 ];
	int j;
	int n;

/*	n	= N - i; */
/*	n	= i; */
/*	n	= lrand48() % 100000; */
	n	= lrand48();

	for( j = 0; j < M; j++ ) {
	    sprintf( buff, "test%08d", n+j );
	    glist = g_list_prepend( glist, strdup( buff ) );
	    ListStrInsert( hmain, buff );
	}
    }

    h1     = ListCreate();
    ListSetComparatorShort( h1, lqstrcmp );
    ListCopy( hmain, h1 );
    h2     = ListCreate();
    ListSetComparatorShort( h2, lqstrcmp );
    ListCopy( hmain, h2 );


    printf( "Starting glib (Gimp ToolKit) sort\n" );
    cmp = 0;
    start = clock();
    glist = g_list_sort( glist, lqstrcmp );
    end = clock();
    printf( "Ending glib (Gimp ToolKit) sort: %f secs, %d cmp\n",
	(end - start) / (double) CLOCKS_PER_SEC, cmp );

    printf( "Starting my qsort\n" );
    start = clock();
    cmp = 0;
    ListQSort( h1 );
    end = clock();
    printf( "Ending my qsort: %f secs, %d cmp\n",
	(end - start) / (double) CLOCKS_PER_SEC, cmp );

    printf( "Starting glibc qsort\n" );
    cmp = 0;
    a = ListArray( h2 );
    start = clock();
    glibc_qsort( a, ListCnt( h2 ), sizeof( void * ), qstrcmp );
    end = clock();
    printf( "Ending glibc qsort: %f secs, %d cmp\n",
	(end - start) / (double) CLOCKS_PER_SEC, cmp );
    free( a );

    ListDelete( h1 );
    ListDelete( h2 );
    ListDelete( hmain );

    return( 0 );
}
