/**
    UDSMTP - Simple SMTP Client
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: mx.h,v 1.2 1999/12/14 15:10:24 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    MX record routines.
**/
 
#ifndef MX
#if defined(__STDC__)
PTobjlistHeader GetMX( const char * hostname, boolean MX );
#else
PTobjlistHeader GetMX();
#endif
#define MX

#endif

/**
    End of mx.h
**/
