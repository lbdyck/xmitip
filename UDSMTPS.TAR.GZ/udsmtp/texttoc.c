/**
    CvtPost - Convert text to PostScript.
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: texttoc.c,v 1.1.1.1 1999/03/15 16:25:16 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:
**/

#include "genincl.h"
#ifdef I370
#include <options.h>
#endif

#ifdef I370
const char * _stdoamp =
    "PRINT=NO,PAD=NO";
#endif

int main( argc, argv )
    int argc;
    char * argv[];

/*
    Simple program that takes standard input and returns a
    C array char * <argv[1]>[] = { ... };
*/

{
    int FirstLine;

    if (argc < 2 || argc > 3)
    {
	fprintf( stderr, "%s: [-s] c-var-name\n", argv[ 0 ] );
	exit( 1 );
    }
    if (strcmp( argv[ 1 ], "-s") == 0 ||
	strcmp( argv[ 1 ], "-S") == 0) {
	printf( "static const char * %s[] = {\n", argv[ 2 ] );
    } else
	printf( "const char * %s[] = {\n", argv[ 1 ] );

    FirstLine = 1;
    while( 1 )
    {
	char	buff[ 2048 ];
	char	buff2[ sizeof buff * 2 ];
	char *	p1;
	char *	p2;
	char *	nl;

	fgets( buff, sizeof buff - 1, stdin );
	if (ferror( stdin ) || feof( stdin )) break;

	if (!FirstLine)
	    printf( ",\n" );
	else
	    FirstLine = 0;

	nl = strchr( buff, '\n' );
	if (nl != NULL) *nl = '\0';

	p1 = buff;
	p2 = buff2;
	while( *p1 != '\0' ) {
	    if (*p1 == '"') {
		*p2++	= '\\';
	    } else if (*p1 == '\\') {
		*p2++ = '\\';
	    }
	    *p2++ = *p1++;
	}
	*p2 = '\0';
	printf( "    \"%s\"", buff2 );
	if (ferror( stdout )) break;
    }
    if (!FirstLine) printf( "\n};\n" );
    if (ferror( stdout ))
	fprintf( stderr, "Error writing standard output.\n" );
    if (!feof( stdin ) && ferror( stdin ))
	fprintf( stderr, "Error reading standard input.\n" );
    return( feof( stdin ) ? 0 : 1 );
}
