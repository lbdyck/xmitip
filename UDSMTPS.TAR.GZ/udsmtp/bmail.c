/**
    BMAIL.C

    $Id: bmail.c,v 1.5 2009/01/27 17:43:31 mike Exp $
 
    This module contains the main routines that make up the batch
    mail program.  The batch mail program, in conjunction with
    its PROC, gives users a simple way to send mail from a batch
    program.
 
    Notes:
 
    1.  This program issues error messages in the form:
        BMA9xxE, where xx is 00 -- 12 (currently).
        (Info messages are also present, and suffixed with 'I').
 
    Program Documentation:
    (Placed into an array so it can be printed.)
**/

static const char * help[ ] = {
"                                                                     ",
"                                                                     ",
"                                BMAIL                                ",
"   ===============================================================   ",
"                                                                     ",
"   Overview:                                                         ",
"                                                                     ",
"   BMAIL is a batch mailing program.  It is best invoked using       ",
"   the PROC BMAIL.  It can also be invoked directly from ISPF`       ",
"   using 'TSO BMAIL'.  See the sample JCL section below for          ",
"   examples on using the proc.  See the sections below for           ",
"   information on command and data formats.                          ",
"                                                                     ",
"   Command Syntax:                                                   ",
"                                                                     ",
"       H                (This text, parameters only)                 ",
"       T<to>,...                                                     ",
"       U<cc-to>,...                                                  ",
"       V<bcc-to>,...                                                 ",
"       R<reply-to>...                                                ",
"       S<subject>                                                    ",
"       O<topic>                                                      ",
"       C                (Gets commands from SYSUT1, not SYSIN)       ",
"       P                (Sends failed mail to postmaster)            ",
"       2                (Writes to SYSUT2, nothing actually mailed)  ",
"                        (-2 only allowed in program parameters)      ",
#if defined(ENABLE_WTO)
"       E                (Writes error messages to SYSPRINT)          ",
"                        (-E only allows in program parameters)       ",
#endif
"       M<mailtext>      (Start message in SYSIN)                     ",
"       ' '<mailtext>    (Continue mail message in SYSIN)             ",
"       .                (Ends mail message in SYSIN)                 ",
"                                                                     ",
"   Commands are taken from:                                          ",
"                                                                     ",
"   o   Program Parameters                                            ",
"   o   SYSUT1                                                        ",
"   o   SYSIN                                                         ",
"                                                                     ",
"   The message is taken from:                                        ",
"                                                                     ",
"   o   SYSIN                                                         ",
"                                                                     ",
"   General Rules:                                                    ",
"                                                                     ",
"   o   All commands are single characters.  Commands passed as       ",
"       program parameters must be prefixed with a dash ('-').        ",
"       Commands in datasets must be in column 1.                     ",
"                                                                     ",
"   o   Commands are only taken from SYSUT1 if the Program            ",
"       parameter command 'C' is used.                                ",
"                                                                     ",
"   o   Commands are only taken from SYSIN when the program           ",
"       parameter command 'C' is NOT present.                         ",
"                                                                     ",
"   o   Commands cease to be read from SYSIN if a 'C' command is      ",
"       present in SYSIN.  In this case, SYSUT1 is not read, and      ",
"       the rest of the text in SYSIN is assumed to be the mail       ",
"       message.                                                      ",
"                                                                     ",
"   o   If commands are NOT being taken from SYSIN, it is assumed     ",
"       that SYSIN contains the message.                              ",
"                                                                     ",
"   o   Either SYSIN or SYSUT1 may be DUMMY.  If so, enough           ",
"       commands must have been specified on the program              ",
"       parameters to generate a valid message.                       ",
"                                                                     ",
"   o   If the -2 parameter is present, a network mail format         ",
"       message is written to SYSUT2.                                 ",
"       The message will not be delivered                             ",
"       unless other steps are taken.  This option is used by         ",
"       systems and network programmers.  Only one message can        ",
"       can be delivered per program invokation when -2 is used.      ",
"       (This is because the SYSOUT dataset is not released and       ",
"       re-allocated between messages).                               ",
"                                                                     ",
"   Command Semantics:                                                ",
"                                                                     ",
"   C - If present, commands are read from the parameters and         ",
"       SYSUT1.  Otherwise, they are read from the parameters and     ",
"       SYSIN.  A C command can be placed in SYSIN, but SYSUT1        ",
"       will not be read.  In addition, no more commands can be       ",
"       read from SYSIN.  All further records are treated as          ",
"       message text.  This can be used to prefix a report with       ",
"       some commands, then cause the report to be mailed without     ",
"       having to insert an M command, and a trailing '.'.  Of        ",
"       course, you could have just as easily left the commands on    ",
"       SYSUT1 in the first place.                                    ",
"                                                                     ",
"   P - If the message fails to post, send it to postmaster.          ",
"                                                                     ",
"   T - Who the message is to be mailed to.  The format of the        ",
"       argument is simply the name of the receipient.  Multiple      ",
"       receipients may be specified in a single command.  Seperate   ",
"       them by commas.  In addition, this command can be issued      ",
"       more than once.                                               ",
"                                                                     ",
"   U - The message is also mailed to this person.  The mail          ",
"       envelope will have a \"CC\" for this person.  All rules that  ",
"       apply to the \"T\" command apply to this command.             ",
"                                                                     ",
"   V - Similar to \"U\", except that \"BCC\" is used.                ",
"                                                                     ",
"   R - Sets the 'Reply-To:' field.  Used by some mailers to          ",
"       generate the reply field.  Can be issued more than once.      ",
"                                                                     ",
"   S - Subject line.                                                 ",
"                                                                     ",
"   O - Topic.                                                        ",
"                                                                     ",
"   M - Start of message text.  Only valid in SYSIN when the 'C'      ",
"       command is not in effect.                                     ",
"                                                                     ",
"   2 - Write RFC822/SNSTCP format mail message to SYSUT2.  Name      ",
"       of job sending mail must be allowed to send network           ",
"       mail through the spool if you want to mail the message.       ",
"                                                                     ",
#if defined(ENABLE_WTO)
"   E - Write all messages to SYSPRINT rather than using WTO.         ",
"       This parameter does not take affect until it is 'seen'.       ",
"       That is, if any other command parameters that appear          ",
"       before 'E' cause messages to be output, the output will       ",
"       be printed using WTO, and not appear in SYSPRINT.  For        ",
"       this reason, it is best to put 'E' as the first program       ",
"       parameter (unless you have good reason not to).               ",
"                                                                     ",
#endif
" ' ' - Continued message text.  Only processed in SYSIN when the     ",
"       'C' command is not effect.                                    ",
"                                                                     ",
"   . - End of message text.  Only processed in SYSIN when the        ",
"       'C' command is not in effect.                                 ",
"                                                                     ",
"   Notes:                                                            ",
"                                                                     ",
"   1.  When processing SYSIN and 'C' is not in effect, 'T, S, O,     ",
"       and M' are ignored between a valid 'M' and '.' command        ",
"       pair.  In other words, you can't have commands mixed          ",
"       within the message itself.                                    ",
"                                                                     ",
"   2. Commands 'S,O,F', when read from SYSUT1 or SYSIN, override     ",
"      the program parameter commands.                                ",
"                                                                     ",
"   3. The 'T' command, when read from SYSUT1 or SYSIN, adds to       ",
"      the list of receipients for the message the command is in      ",
"      effect for.  'U' and 'V' function similarly.                   ",
"                                                                     ",
"   4. The default parameter provided by the proc BMAIL is '-H'.      ",
"      If you do not want the help, and are not providing any         ",
"      parameters, override the default parameter with                ",
"      \"EXEC BMAIL,PARM=''\".                                        ",
"                                                                     ",
"   5. When running under TSO, you can issue an end of file           ",
"      by typing \"EOF\" in all caps in the first column.             ",
"                                                                     ",
"   Sample JCL:                                                       ",
"                                                                     ",
"   1.  //STEP1  EXEC BMAIL                                           ",
"                                                                     ",
"       (Prints this help message and ends.)                          ",
"                                                                     ",
"   2.  //STEP1  EXEC BMAIL,PARM='-TMike.Porter -STest'               ",
"       MThis is the message.                                         ",
"       .                                                             ",
"       /*                                                            ",
"                                                                     ",
"       (Simple example.  Sends message with subject.  Message        ",
"        starts with 'M' command in SYSIN.  Note that the             ",
"        SYSIN card is generated by JES2.  A '//SYSIN DD *'           ",
"        statement could have appeared before the message test.)      ",
"                                                                     ",
"   3.  //STEP1  EXEC BMAIL,PARM=''                                   ",
"       TMike.Porter                                                  ",
"       STest                                                         ",
"       MThis is the message.                                         ",
"       .                                                             ",
"                                                                     ",
"       (Similar to previous example.  More commands provided in      ",
"        data rather than as parameters.  The \"PARM=''\" prevents    ",
"        the help message from being displayed.                       ",
"                                                                     ",
"   4.  //STEP1  EXEC BMAIL,PARM='-C'                                 ",
"       //SYSUT1 DD *                                                 ",
"       TMike.porter                                                  ",
"       STest                                                         ",
"       /*                                                            ",
"       //SYSIN  DD *                                                 ",
"       This is the message.                                          ",
"       /*                                                            ",
"                                                                     ",
"       (Example 3 shows the use of the SYSUT1 dataset to supply      ",
"        commands.)                                                   ",
"                                                                     ",
"   5.  //STEP1  EXEC BMAIL,PARM='-C -TMike.Porter -STest,'           ",
"       This is the message.                                          ",
"       /*                                                            ",
"                                                                     ",
"       (Note that in the above example, -C says use SYSUT1 for       ",
"        input and assume SYSIN has straight text.  However, SYSUT1   ",
"        is DUMMY by default, and we specify enough commands to mail  ",
"        the message in the parameters.)                              ",
"                                                                     ",
"   6.  //STEP1  EXEC BMAIL,PARM='-TMike.Porter, -SJob Ran'           ",
"                                                                     ",
"       (Note that this is a message of zero lines.)                  ",
"                                                                     ",
"   7.  //STEP1  EXEC BMAIL,PARM='-TMike.Porter, -SSystem IPL -2      ",
"       //SYSUT2 DD SYSOUT=M,DCB=RECFM=FBA                            ",
"                                                                     ",
"       (Note that this is a message of zero lines.  Writes           ",
"        RFC822/SNSTCP/TAOWRNET format mail message.  Privileged      ",
"        function for mail to be actually delivered.  SYSUT2          ",
"        must be an FBA or VBA dataset.  If not, the header           ",
"        will not pass TAOWRNET validation.                           ",
"                                                                     ",
"   Return Codes:                                                     ",
"                                                                     ",
"    0 - Program worked.                                              ",
"    4 - No 'To' addresses found, hence no delivery.                  ",
"    8 - One or more messages failed.                                 ",
"   16 - Command processing error.                                    ",
"      - Error reading input dataset.                                 ",
"      - Error writing output dataset.                                ",
"   20 - Out of memory.                                               ",
"" };                     /* END HELP */
 
#include "genincl.h"
#include <math.h>
#include <netdb.h>
#include <stdio.h>
#include "list.h"
#include "util.h"

#if defined(HAVE_OSDYNALLOC)
#include <os.h>
#endif
 
/*
    Define the command codes.
*/
 
#define TO_CMD     0
#define CC_CMD     1
#define BCC_CMD    2
#define SYSUT2_CMD 3
#define SUBJ_CMD   4
#define TOPIC_CMD  5
#define SYSUT1_CMD 6
#define MAIL_CMD   7
#define END_CMD    8
#define HELP_CMD   9
#if defined(ENABLE_WTO)
#define EMSG_CMD  10
#endif
#define POST_CMD  11
#define REPLY_CMD 12
#define UNKN_CMD  13

typedef int boolean;
 
/*
    Define a read line macro.
 
    f = file.
    b = char buffer.
    l = length.
    c = line count.
 
    A line length of zero is never returned, we always pad with 1
    byte in this case.  Trailing spaces are removed.
*/
 
#define READ( f, b, l, c )                                        \
{                                                                 \
    fgets( b, sizeof b, f );                                      \
    if (ferror( f )) {                                            \
        Stderrp( "TAU001E error reading input: %s\n",             \
            strerror( errno ) );                                  \
        exit( 16 );                                               \
    }                                                             \
    remend( b, " \n" );                                           \
    l          = strlen( b );                                     \
    c++;                                                          \
    if (l == 0)                                                   \
    {                                                             \
        *b = ' ';                                                 \
        *(b+1) = ' ';                                             \
        l = 2;                                                    \
    }                                                             \
}
 
 
/*
    Define pointers to  the main subject and topic strings.  The
    buffers consist of the default buffer, which is set on the
    command parameters, and an override buffer which is set by
    SYSIN.
*/
 
static int    get_sysut1;         /* If TRUE, get cmds from SYSUT1. */
static int    put_sysut2;         /* If TRUE, put mail on SYSUT2. */
static int    main_exit;          /* Main exit code */
static int    postmaster;         /* True if failures to postmaster */
 
static FILE * MailFile;           /* The output file */
 
#define POSTMASTER "postmaster"   /* Postmaster's address */
 
/*
    Internal routine prototypes.
*/
 
static int cmd_proc( const char * buff, char ** arg );
static int write_header( const PTobjlistHeader to,
                         const PTobjlistHeader cc,
                         const PTobjlistHeader bcc,
                         const PTobjlistHeader reply,
                         const char * subj,
                         const char * topic );
static int put( const char * buff, int len );
static int send_it( void );
static int output_date( void );
static void ListAList( PTobjlistHeader list, FILE * ofile,
    const char * descr1, const char * descr2, boolean comma );
#if defined(HAVE_OSDYNALLOC)
static FILE * dynopen( const char * Name, const char * Mode );
#endif
static char * AddHostName( char * Buff, const char * DefaultDomain,
    int verbose );
static void ParseMailboxes( char * InBuff, PTobjlistHeader List );
static int print_help( void );
 
/**
    End of globals.
**/
 
int
main( int argc, char ** argv )
 
/*
    Main processing routine.  Get input from program parameters,
    SYSUT1, if told to, and then process SYSIN.
*/
 
{
    FILE * sysut1;            /* Commands file */
    FILE * sysin;             /* Message file */
 
    int    ret_code;          /* General return code */
    int    i;                 /* General loop counter */
    int    line_cnt;          /* Line counter */
    int    mailing;           /* If true, processing mailing message */
 
    char  rbuff[ 32767 ];     /* File Input Buffer */
    char * buff;              /* Command Input Buffer */
    int    len;               /* Chars read */
    int    alen;              /* Length of argument */
    char * aptr;              /* Ptr to argument */
 
    char * def_subj;
    char * def_topic;
    char * ovr_subj;
    char * ovr_topic;
 
    PTobjlistHeader def_to;
    PTobjlistHeader ovr_to;
    PTobjlistHeader def_cc;
    PTobjlistHeader ovr_cc;
    PTobjlistHeader def_bcc;
    PTobjlistHeader ovr_bcc;
    PTobjlistHeader def_reply;
    PTobjlistHeader ovr_reply;
 
/*
    Initialize the various flags and buffers.
*/
 
    SavePgmName( argv[ 0 ] );
#if defined(ENABLE_WTO)
    SetWto( TRUE );
#endif
    get_sysut1   = FALSE;
    put_sysut2   = FALSE;
    main_exit    = 0;
 
    def_subj     = NULL;
    def_topic    = NULL;
    ovr_subj     = NULL;
    ovr_topic    = NULL;
    def_to       = ListCreate();
    ovr_to       = ListCreate();
    def_cc       = ListCreate();
    ovr_cc       = ListCreate();
    def_bcc      = ListCreate();
    ovr_bcc      = ListCreate();
    def_reply    = ListCreate();
    ovr_reply    = ListCreate();
 
/*
    Process the command line arguments.  A '-' starts a
    command.  If an argument does not have a '-', then
    concat it to the previous dashed command with a
    space to seperate it.
*/
 
    i      = 1;
    rbuff[ 0 ] = '\0';
    len        = 0;
 
/*
    If the current argument starts with a '-', then process
    the previous argument, if present.  If the current
    argument is past the end, then dispose of the previous
    one if present, and end.
 
    If the current argument does not start a command, concat
    it to the previous command.
*/
 
    buff = NULL;
    LOOP {
        if ((i >= argc) || (*argv[ i ] == '-')) {
            if (strlen( rbuff ) > 0) {
                ret_code = cmd_proc( rbuff, &buff );
                switch (ret_code) {
                    case TO_CMD:
                        ParseMailboxes( buff, def_to ); break;
                    case CC_CMD:
                        ParseMailboxes( buff, def_cc ); break;
                    case BCC_CMD:
                        ParseMailboxes( buff, def_bcc ); break;
                    case REPLY_CMD:
                        ParseMailboxes( buff, def_reply ); break;
                    case SUBJ_CMD:
                        empty( &def_subj );
                        def_subj=buff; buff=NULL;  break;
                    case TOPIC_CMD:
                        empty( &def_topic );
                        def_topic=buff; buff=NULL; break;
                    case SYSUT1_CMD: get_sysut1 = TRUE;      break;
                    case SYSUT2_CMD: put_sysut2 = TRUE;      break;
                    case HELP_CMD:   print_help();           break;
                    case POST_CMD:   postmaster = TRUE;      break;
#if defined(ENABLE_WTO)
                    case EMSG_CMD:   SetWto( FALSE );        break;
#endif
                    default:         main_exit = 16;         break;
                }
                *rbuff = 0;
                len    = 0;
                empty( &buff );
            }
        }
        if (i >= argc) break;              /* EXIT LOOP */
 
        aptr    = argv[ i ];               /* Get current arg */
        i++;
        alen    = strlen( aptr );          /* Its length */
        alen    = *aptr == '-' ? alen-1 : alen+1;  /* chg if flg */
        alen    = (alen < sizeof rbuff - len - 1 ) ?
			alen : sizeof rbuff - len - 1;
        if (alen == 0) continue;           /* Nothing left */
        if (*aptr != '-') {                /* If no dash, ins spc */
            rbuff[ len ] = ' ';
            rbuff[ len + 1 ] = 0;
        } else {
            aptr++;                        /* Remove dash */
        }
        strcat( rbuff, aptr );             /* Store argument */
        len   += alen;                     /* Save new length */
    }
    if (main_exit != 0) exit( main_exit );
 
/*
    If processing commands from SYSUT1, then start reading them.
    Allow SYSUT1 to be non-existant.
*/
 
    if (get_sysut1 == TRUE) {
#if defined(HAVE_QUIET)
        quiet( 1 );           /* Supress messages */
#endif
        errno      = 0;
        sysut1     = fopen( "SYSUT1", "r" );
#if defined(HAVE_QUIET)
        quiet( 0 );           /* Ok... */
#endif
        if (sysut1 == NULL) {
            if (errno != ENOENT) {
                Stderrp( "TAU002E Error reading SYSUT1: %s.\n",
                               strerror( errno ) );
                exit( 16 );
            }
        }
    } else {
        sysut1    = NULL;
    }
 
    buff = NULL;
    if (sysut1 != NULL) {
        line_cnt   = 0;
        LOOP {
            READ( sysut1, rbuff, len, line_cnt );
            if (feof( sysut1 )) break;
            ret_code = cmd_proc( rbuff, &buff );
            switch (ret_code) {
                case TO_CMD:
                    ParseMailboxes( buff, def_to ); break;
                case CC_CMD:
                    ParseMailboxes( buff, def_cc ); break;
                case BCC_CMD:
                    ParseMailboxes( buff, def_bcc ); break;
                case REPLY_CMD:
                    ParseMailboxes( buff, def_reply ); break;
                case SUBJ_CMD:
                    empty( &def_subj );
                    def_subj=buff; buff=NULL; break;
                case TOPIC_CMD:
                    empty( &def_topic );
                    def_topic=buff; buff=NULL; break;
                case SYSUT1_CMD: get_sysut1 = TRUE; break;
                case SYSUT2_CMD: put_sysut2 = TRUE; break;
                default:
                Stderrp( "TAU003E Bad command in SYSUT1 on "
                               "line %d.\n", line_cnt );
                                 main_exit = 16;                 break;
            }
            empty( &buff );
        }
        fclose( sysut1 );
        if (main_exit != 0) exit( main_exit );
    }
 
/*
    Copy the default arguments to the overlay area.
*/
 
    sdupx( def_subj, NULL, &ovr_subj );
    sdupx( def_topic, NULL, &ovr_topic );
    ovr_to    = ListCreate(); ListCopy( def_to, ovr_to );
    ovr_cc    = ListCreate(); ListCopy( def_cc, ovr_cc );
    ovr_bcc   = ListCreate(); ListCopy( def_bcc, ovr_bcc );
    ovr_reply = ListCreate(); ListCopy( def_reply, ovr_reply );
 
/*
    Process the SYSIN stream.  Allow commands if get_sysut1 is
    FALSE.  If get_sysut1 is TRUE, then data in SYSIN is mail.
*/
 
    if (get_sysut1 == TRUE) {             /* Already read SYSUT1, */
        write_header( ovr_to, ovr_cc, ovr_bcc, ovr_reply,
            ovr_subj, ovr_topic );
        mailing        = TRUE;
    } else {
        mailing        = FALSE;
    }
    line_cnt = 0;
 
#if defined(HAVE_QUIET)
    quiet( 1 );
#endif
    errno    = 0;
#if defined(ENABLE_MVS)
    sysin    = fopen( "SYSIN", "r" );
#else
    sysin    = stdin;
#endif
#if defined(HAVE_QUIET)
    quiet( 0 );
#endif
    if (sysin == NULL) {
        if (errno != ENOENT) {
            Stderrp( "TAU004E Error opening SYSIN: %s.\n",
                     strerror( errno ) );
            exit( 16 );
        }
    }
 
#if defined(ENABLE_MVS)
    Stdout( "TAU609I Starting to write output.\n" );
#else
    Stderr( "TAU609I Starting to write output.\n" );
#endif
 
    while (main_exit <= 4) {               /* While no bad errors */
        if (sysin == NULL) break;          /* SYSIN not available */
        READ( sysin, rbuff, len, line_cnt );
        if (feof( sysin )) break;          /* End of SYSIN */
 
        if (get_sysut1 == TRUE) {          /* Write a line, no cmds */
            if (rbuff[ 0 ] == '.') put( ".", 1 );
            rbuff[ len++ ] = '\n';
            put( rbuff, len );
            continue;
        } else if ((mailing == TRUE) && (*rbuff == ' ')) {
            if (rbuff[ 1 ] == '.') put( ".", 1 );
            rbuff[ len ] = '\n';
            put( rbuff + 1, len );         /* Cmd of ' ', put... */
            continue;
        } else if ((mailing == TRUE) && (*rbuff == '.')) {
            send_it( );                          /* Send the message */
            mailing  = FALSE;                    /* No longer mailing */
            ovr_to = ListDelete( ovr_to );
            ovr_cc = ListDelete( ovr_cc );
            ovr_bcc = ListDelete( ovr_bcc );
            ovr_reply = ListDelete( ovr_reply );
            sdupx( def_subj, NULL, &ovr_subj );
            sdupx( def_topic, NULL, &ovr_topic );
            ovr_to    = ListCreate(); ListCopy( def_to, ovr_to );
            ovr_cc    = ListCreate(); ListCopy( def_cc, ovr_cc );
            ovr_bcc   = ListCreate(); ListCopy( def_bcc, ovr_bcc );
            ovr_reply = ListCreate(); ListCopy( def_reply, ovr_reply );
            continue;
        } else if (mailing == TRUE) {        /* Command error */
            Stderrp( "TAU005E Command out of sequence "
                           "in SYSIN dataset, line = %d.\n",
                           line_cnt );
            main_exit = 16;
            mailing   = FALSE;
            continue;
        }
 
/*
    Have a command.  Check it out.  We know we are accepting
    commands and that we are not in the mailing state.
*/
 
        ret_code = cmd_proc( rbuff, &buff );
        switch (ret_code) {
            case TO_CMD:
                ParseMailboxes( buff, ovr_to ); break;
            case CC_CMD:
                ParseMailboxes( buff, ovr_cc ); break;
            case BCC_CMD:
                ParseMailboxes( buff, ovr_bcc ); break;
            case REPLY_CMD:
                ParseMailboxes( buff, ovr_reply ); break;
            case SUBJ_CMD:
                empty( &ovr_subj );
                ovr_subj=buff; buff=NULL;
                break;
            case TOPIC_CMD:
                empty( &ovr_topic );
                ovr_topic=buff; buff=NULL;
                break;
            case SYSUT1_CMD: get_sysut1 = TRUE;
                             write_header(ovr_to,
                                          ovr_cc,
                                          ovr_bcc,
                                          ovr_reply,
                                          ovr_subj,
                                          ovr_topic );
                             mailing = TRUE;
                break;
            case MAIL_CMD:   write_header(ovr_to,
                                          ovr_cc,
                                          ovr_bcc,
                                          ovr_reply,
                                          ovr_subj,
                                          ovr_topic );
                             rbuff[ len ] = '\n';
                             if (rbuff[ 1 ] == '.') put( ".", 1 );
                             put( rbuff+1, len );
                             mailing = TRUE;
                break;
            default:
                Stderrp( "TAU006E Bad command in SYSIN on "
                         "line %d.\n", line_cnt );
                main_exit = 16;
                break;
        }
        empty( &buff );
    }
 
#if defined(HAVE_QUIET)
    quiet( 1 );
#endif
    fclose( sysin );
#if defined(HAVE_QUIET)
    quiet( 0 );
#endif
 
    if (mailing == TRUE) {    /* Pick up end of file in all cases*/
        send_it( );
    }
    if (MailFile != NULL ) {
        put( "QUIT\n", 5 );
        fclose( MailFile );
    }
 
/*
    Free the lists.
*/
 
    ListDelete( ovr_to );
    ListDelete( ovr_cc );
    ListDelete( ovr_bcc );
    ListDelete( ovr_reply );
    ListDelete( def_to );
    ListDelete( def_cc );
    ListDelete( def_bcc );
    ListDelete( def_reply );
    empty( &def_subj );
    empty( &ovr_subj );
    empty( &def_topic );
    empty( &ovr_topic );
 
    return( main_exit );
}
 
/**
    End of main.
**/
 
static int cmd_proc( const char * buff, char ** arg )
 
/*
    This routine is used to process the commands.  If it gets a valid
    command, it will return its index and place its argument into
    arg.  Spaces at the front the command argument are removed when
    appropriate.
 
    Arguments:
 
    buff         -- Pointer to the input buffer.
    arg          -- Pointer to output argument buffer.
 
    Return Code:
 
    One of the command codes.
**/
 
{
    char    cmd;
    int     len;
 
/*
    Get the current command character code.
*/
 
    cmd   = *buff;
    len   = strlen( buff + 1 );
    *arg  = strbuff( len );
    memcpy( *arg, buff + 1, len + 1 );
 
    switch (cmd) {
        case 't':
        case 'T'      : remfrnt( *arg, " "); return( TO_CMD );
                        break;
 
        case 'u':
        case 'U'      : remfrnt( *arg, " "); return( CC_CMD );
                        break;
 
        case 'v':
        case 'V'      : remfrnt( *arg, " "); return( BCC_CMD );
                        break;
 
        case 'r':
        case 'R'      : remfrnt( *arg, " "); return( REPLY_CMD );
                        break;
 
        case 's':
        case 'S'      : remfrnt( *arg, " " ); return( SUBJ_CMD );
                        break;
 
        case 'o':
        case 'O'      : remfrnt( *arg, " " ); return( TOPIC_CMD );
                        break;
 
        case 'c':
        case 'C'      : return( SYSUT1_CMD );
                        break;
 
        case 'p':
        case 'P'      : return( POST_CMD );
                        break;
 
        case '2'      : return( SYSUT2_CMD );
                        break;
 
        case 'h':
        case 'H'      : return( HELP_CMD );
                        break;
 
        case 'm':
        case 'M'      : return( MAIL_CMD );
                        break;
 
#if defined(ENABLE_WTO)
        case 'e':
        case 'E'      : return( EMSG_CMD );
                        break;
#endif
 
        case '.'      : return( END_CMD );
                        break;
 
        default       : Stderrp( "TAU007E Bad Command = %s.\n", buff );
                        return( UNKN_CMD );
    }
}
 
/**
    End of cmd_proc.
**/
 
static int write_header( const PTobjlistHeader to,
                         const PTobjlistHeader cc,
                         const PTobjlistHeader bcc,
                         const PTobjlistHeader reply,
                         const char * subj,
                         const char * topic )
 
/*
    This routine is used to write header.
 
    Inputs:
 
    to           -- Base pointer of the TO list.
    cc           -- Base pointer of the CC list.
    bcc          -- Base pointer of the BCC list.
    reply        -- Base pointer of the reply list.
    subj         -- Subject string.
    topic        -- Topic string.
 
    Implicit Inputs and Outputs:
 
    put_sysut2   -- If true, then output is to DDNAME SYSUT2.
    MailFile     -- File pointer for output file.
*/
 
{
    char * Buff;
 
/*
    Insure there is at least one 'to' address.
*/
 
    if (ListCnt( to ) == 0) {
        Stderrp( "TAU008E No 'To' addresses have been found.\n" );
        exit( 4 );
    }
 
/*
    Start the message.
*/
 
    if (MailFile == NULL) {
        if (!put_sysut2) {
#if defined(HAVE_OSDYNALLOC)
            MailFile = dynopen( "DYN:SYSOUT=R,DEST=RJE198,"
                "LRECL=32756,RECFM=V,FREECLOSE,SPIN=UNALLOC", "w" );
#else
#if defined(ENABLE_MVS)
            MailFile =  fopen( "SYSUT2", "w" );
#else
            MailFile =  stdout;
#endif
#endif
        } else {
            MailFile =  fopen( "SYSUT2", "w" );
        }
        if (MailFile == NULL) {
            Stderrp( "TAU010E error opening output file: %s.\n",
                strerror( errno ));
            exit( 16 );
        }
        put( "HELO ", 5 );
 
        Buff = strbuff( 1 );
        Buff[ 0 ] = '\0';
        Buff = AddHostName( Buff, NULL, FALSE );
        put( Buff+1, strlen( Buff+1 ));
        put( "\n", 1 );
        empty( &Buff );
    }
 
/*
    Write out all the 'to's, 'cc's and 'bcc's.
*/
 
    Buff = strdup( getlogin( ) );
    Buff = AddHostName( Buff, NULL, FALSE );
    put( "MAIL FROM:<", 11 );
    put( Buff, strlen( Buff ) );
    put( ">\n", 2 );
    empty( &Buff );
 
    ListAList( to, MailFile, "RCPT TO:<%s>", NULL, FALSE );
    ListAList( cc, MailFile, "RCPT TO:<%s>", NULL, FALSE );
    ListAList( bcc, MailFile, "RCPT TO:<%s>", NULL, FALSE );
    put( "DATA\n", 5 );
    output_date();
    Buff = strdup( getlogin( ) );
    Buff = AddHostName( Buff, NULL, FALSE );
    put( "From: ", 6 );
    put( Buff, strlen( Buff ) );
    put( "\n", 1 );
    empty( &Buff );
    ListAList( to, MailFile, "To: %s", " %s", TRUE );
    ListAList( cc, MailFile, "Cc: %s", " %s", TRUE );
    ListAList( reply, MailFile, "Reply-To: %s", " %s", TRUE );
    ListAList( bcc, MailFile, "Bcc: %s", " %s", TRUE );
 
/*
    Output subject if present.
*/
 
    if (subj != NULL) {
        Stdout( "Subject is '%s'.\n", subj );
        put( "Subject: ", 9 );
        put( subj, strlen( subj ) );
        put( "\n", 1 );
    }
 
/*
    Find the last topic and output it.
*/
 
    if (topic != NULL) {
        Stdout( "Topic is '%s'.\n", topic );
        put( "Topic: ", 7 );
        put( topic, strlen( topic ) );
        put( "\n", 1 );
    }
 
/*
    Output a blank line.
*/
 
    put( " \n", 2 );
 
    return( 0 );
}
 
/**
    End of write_header.
**/
 
static int put( const char * buff, int len )
 
/*
    Special output routine.
*/
 
{
    fwrite( buff, 1, len, MailFile );
    if (ferror( MailFile )) {
        Stderrp( "TAU011E error writing output file: %s\n",
            strerror( errno ));
        exit( 16 );
    }
 
    return( 0 );
}
 
/**
    End of put.
**/
 
static int send_it( void )
 
/*
    This routine actually sends the mail.  Print messages related
    to the posting.
 
    Inputs:
 
    NONE.
 
    Implicit Inputs/Outputs:
 
    MailFile          -- Mail file pointer.
*/
 
{
#if defined(ENABLE_MVS)
    Stdout( "TAU674I message sent.\n" );
#else
    Stderr( "TAU674I message sent.\n" );
#endif
    put( ".\n", 2 );
    return( 0 );
}
 
/**
    End of send_it.
**/
 
static int output_date()
 
/*
    This routine outputs an RFC822 date.
*/
 
{
    char date[ 64 ];            /* RFC822 Data buffer */
    time_t    the_time;         /* Current time */
    struct tm l_tm_time;        /* Local time */
    struct tm u_tm_time;        /* Universal (greenwich) time */
    time_t    l_time;           /* Local time, binary value */
    time_t    u_time;           /* Universal time, binary value */
    double    diff_l_u_time;    /* Diff between univ. and local */
    int len;
 
    static const char * wkday[ ] =
        {"Sun", "Mon", "Tue", "Wed", "Thu", "Fri", "Sat" };
 
    static const char * months[ ] =
        {"Jan", "Feb", "Mar", "Apr", "May", "Jun",
         "Jul", "Aug", "Sep", "Oct", "Nov", "Dec" };
 
    time( &the_time );
    memcpy( &l_tm_time, localtime( &the_time ), sizeof l_tm_time );
    memcpy( &u_tm_time,    gmtime( &the_time ), sizeof u_tm_time );
 
    l_time        = mktime( &l_tm_time );
    u_time        = mktime( &u_tm_time );
 
/*
    Subtract universal time from local time to get the
    differential between the time zones in seconds.
    Convert to hours.
 
    (l_time - u_time)
*/
 
    diff_l_u_time = difftime( l_time, u_time );
    diff_l_u_time = floor( (diff_l_u_time / 3600.0 ) + .5);
 
    len = snprintf( date, sizeof date - 1,
                   "Date: %s, %d %s %d %2.2d:%2.2d:%2.2d %03.0f00\n",
                   wkday[ l_tm_time.tm_wday ],
                   l_tm_time.tm_mday,
                   months[ l_tm_time.tm_mon ],
                   l_tm_time.tm_year + 1900,
                   l_tm_time.tm_hour,
                   l_tm_time.tm_min,
                   l_tm_time.tm_sec,
                   diff_l_u_time );
 
    put( date, len );
 
    return( 0 );
}
 
/**
    End of output_date.
**/

static void
ListAList( list, ofile, descr1, descr2, comma )
    PTobjlistHeader list;
    FILE * ofile;
    const char * descr1;
    const char * descr2;
    boolean comma;
 
/*
    Lists out a list on the specified file.  The descr1 and descr2
    arguments must be 'fprintf' format.  They get one string
    argument.  If there is more to output, and comma is TRUE, then
    add a comma to the end of the line.
*/
 
{
    PTobjlistContext Context = NULL;
    char * c;
    const char * descr = descr1;
    int i;
 
    i = ListCnt( list );
    while (1 == 1) {
        ListNext( list, &Context, (void **) &c, NULL );
        if (Context == NULL) break;
        fprintf( ofile, descr, c );
        if (ferror( ofile )) break;
        if (comma && --i > 0) {
            putc( ',', ofile );
            if (ferror( ofile )) break;
        }
        putc( '\n', ofile );
        if (ferror( ofile )) break;
        if (descr2 != NULL) descr = descr2;
    }
    if (ferror( ofile )) {
        Stderrp( "error writing output: %s.\n",
            strerror( errno ) );
        exit( 16 );
    }
}
 
/**
    End of ListAList.
**/
 
#if defined(HAVE_OSDYNALLOC)
static FILE *
dynopen( Name, Mode )
    const char * Name;
    const char * Mode;
 
/*
    On OS/390, using SAS/C, this routine will check for the special
    file name that starts with "DYN:".  If it does, then a call to
    osdynalloc will be made to allocate the output file.  A DDNAME
    will be returned, and that DDNAME will be opened using using a
    normal fopen.
*/
 
{
    char MsgBuff[ 256 ];
    char DDName[ 13 ];
    char NameBuff[ 512 ];
    int  rc;
    int  MsgCount = 0;
    int  Reason   = 0;
    dyn_msgbuf (*Msgs)[];
 
/*
    If we are not doing dynamic allocation, just do a normal
    fopen.
*/
 
    if (strncmp( Name, "DYN:", 4 ) != 0) {
        return( fopen( Name, Mode ));
    }
 
/*
    Build a set of osdynalloc parameters.  First, take what the
    user requested, less the "DYN:" string.  Then add a keyword to
    return the DDNAME allocate and various keywords to return
    diagnostics.
*/
 
    strcpy( NameBuff, Name+4 );
    strcat( NameBuff, ",retddname=?,reason=?,msgcount=?,errmsgs=?" );
    rc = osdynalloc( DYN_ALLOC, NameBuff, MsgBuff, DDName+4, &Reason,
                     &MsgCount, &Msgs );
    if (rc != 0) {
        int i;
 
        Stderrp( "SAS/C osdynalloc failed, ret=%d, reason=%d (dec).\n",
            rc, Reason );
        if (rc < 0) {
            Stderrp( "Msg from SAS/C: %s.\n", MsgBuff );
        }
        for( i = 0; i < MsgCount; i++ ) {
            Stderrp( "SVC99(IEFDB476): %*.*s",
                (*Msgs)[ i ].length,
                (*Msgs)[ i ].length,
                (*Msgs)[ i ].text );
        }
        if (MsgCount > 0) free( Msgs );
        return( NULL );
    }
 
/*
    We now have a dynamically allocated DDNAME.  Make a file name
    up consisting of the name and do a normal FOPEN.
*/
 
    memcpy( DDName, "DDN:", 4 );
    return( fopen( DDName, Mode ));
}
#endif
 
/**
    End of dynopen.
**/
 
static char *
AddHostName( Buff, DefaultDomain, verbose )
    char * Buff;
    const char * DefaultDomain;
    int verbose;
 
/*
    This routine checks to see if a host name is part of the
    supplied email address in 'Buff'.  If not (missing '@'), then
    DefaultDomain is used, if not NULL.  If NULL, then gethostname
    is used.  If the resulting host name does not have any '.',
    then it is looked up using gethostbyname if the name was
    supplied by the user or by gethost if the name came from
    gethostname.  The end result is that we use the resolver to
    get an FQDN.
 
    Buff is assumed to point to dynamic memory.  If the name is
    changed, then Buff is copied and freed.  The pointer that holds
    the name, either Buff or new storage is returned.
*/
 
{
    char * dmn;                 /* Points to char after '@' */
    char * per;                 /* Is there a '.' in the domain name? */
    char * NBuff;               /* Ptr to new Buff */
    struct hostent * host;      /* Result from gethostbyname */
    char * HostName = NULL;     /* Result from gethostname */
 
    dmn = strchr( Buff, '@' );
    if (dmn != NULL) {
        dmn++;
        per = strchr( dmn, '.' );
        if (per != NULL) {
            return( Buff );
        }
    }
 
    if (dmn != NULL) {          /* Not an FQDN */
                                /* Asserting that per == NULL */
        if (verbose) {
            Stderr( "The email address '%s' does not appear to be \
complete.\n", Buff );
        }
 
        host = gethostbyname( dmn );
        if (host == NULL || host->h_name == NULL) {
            if (verbose) {
                Stderr( "Couldn't resolve '%s'.\n" );
            }
            return( Buff );
        } else if (verbose) {
            Stderr( "Resolved to '%s'.\n", host->h_name );
        }
        *(dmn - 1) = '\0';      /* Truncate to local part from '@' */
        HostName = strdupAndFree( host->h_name, HostName );
    } else if (DefaultDomain != NULL) {
        HostName = strdup( DefaultDomain );
    } else {                    /* No domain name, no default either */
        HostName = strbuff( 256 );
        if (gethostname( HostName, 256 ) == -1) {
            Stderrp( "gethostname failed: %s\n", strerror( errno ) );
            exit( 20 );
        }
        per = strchr( HostName, '.' );
 
        if (per == NULL) {
            if (verbose) {
                Stderr( "Hostname '%s' is not an FQDN - looking up.\n",
                    HostName );
            }
 
            host = gethostbyname( HostName );
            if (host != NULL && host->h_name != NULL) {
                if (verbose) {
                    Stderr( "Resolved to '%s'.\n", host->h_name );
                }
                HostName = strdupAndFree( host->h_name, HostName );
            } else {
                Stderr( "failed to resolve '%s', using it.\n", HostName );
            }
        }
    }           /* No host name was specified */
 
    NBuff = strbuff( strlen( Buff ) + 1 + strlen( HostName ) );
    strcpy( NBuff, Buff );
    strcat( NBuff, "@" );
    strcat( NBuff, HostName );
    free( Buff );
    empty( &HostName );
    return( NBuff );
}
 
/**
    End of AddHostName.
**/
 
static void
ParseMailboxes( InBuff, List )
    char * InBuff;
    PTobjlistHeader List;
 
/*
    This routine attempts to duplicate the parsing actions of the
    old TAO mail routines.  We break addresses on commas, remove
    leading spaces, treat the address as continuing until white
    space, then drop everything until the next comma.
 
    The resulting name is added to the list.
 
    Note that this parse has nothing to do with how network mail
    addresses should really be parsed.  We are emulating some old
    vendor supplied code here, not trying to write what really
    should be.
 
*/
 
{
    char * p = InBuff;    /* Pointer into input buffer */
    char * comma;         /* Location of the comma or &eos */
    char * next;          /* Start of next mailbox */
    char * end;           /* End of current mailbox string */
    char * mailbox;       /* Current mailbox */
    char eos = '\0';      /* Used as a dummy empty string */
 
    while( 1 ) {
        if (*p == '\0') break;
        while( isspace( (unsigned char) *p ) ) p++;    /* Leading white space */
        if (*p == '\0') break;
 
        comma = strchr( p, ',' );      /* Find the comma */
        if (comma == NULL)
            next = &eos;               /* Nope, no more mailboxes */
        else {
            *comma = '\0';             /* Possible end of mailbox */
            next = comma + 1;          /* Start of next mailbox */
        }
 
        end = p;                       /* Find true end of mailbox */
        while( !isspace( (unsigned char) *end ) &&     /* Skip til wtsp,eos */
               *end != '\0') end++;
        *end = '\0';                   /* End at start of whitespace */
 
        mailbox = strdup( p );         /* Duplicate string */
 
        mailbox = AddHostName( mailbox, NULL, FALSE );
        ListStrAppend( List, mailbox );
        free( mailbox );
 
        p = next;
    }
}
 
/**
    End of ParseMailboxes.
**/
 
static int print_help()
 
/*
    This routine is used to print array help.
*/
 
{
    const char **p;
 
    p    = help;
    while( strlen( *p ) > 0 )
        puts( *(p++) );
 
    return( 0 );
}
 
/**
    End of print_help.
**/
 
/**
    End of program.
**/
