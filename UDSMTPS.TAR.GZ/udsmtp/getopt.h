/* Declarations for getopt.
   Copyright (C) 1989, 1990, 1991, 1992, 1993 Free Software Foundation, Inc.

    Modified 10/25/95 by Michael J. Porter.  Modifications relate
    to removing global data in this module.  The resulting routines
    are not compatible with the standard 'getopt' routines.

   This program is free software; you can redistribute it and/or modify it
   under the terms of the GNU General Public License as published by the
   Free Software Foundation; either version 2, or (at your option) any
   later version.

   This program is distributed in the hope that it will be useful,
   but WITHOUT ANY WARRANTY; without even the implied warranty of
   MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.	 See the
   GNU General Public License for more details.

   You should have received a copy of the GNU General Public License
   along with this program; if not, write to the Free Software
   Foundation, 675 Mass Ave, Cambridge, MA 02139, USA.

    WARNING WARNING.....WARNING
    WARNING WARNING.....WARNING
    WARNING WARNING.....WARNING

    This code has been modifed to take a pointer to a structure
    'getopt_info'.  This allows these routines to be re-entrant.
    As a result, this code is not interchangable with other
    GNU getopt packages.
*/

#ifndef _GETOPT_H
#define _GETOPT_H 1

#ifdef	__cplusplus
extern "C" {
#endif

struct getopt_info {

/* For communication from `getopt' to the caller.
   When `getopt' finds an option that takes an argument,
   the argument value is returned here.
   Also, when `ordering' is RETURN_IN_ORDER,
   each non-option ARGV-element is returned here.  */
 
    char *optarg;
 
/* Index in ARGV of the next element to be scanned.
   This is used for communication to and from the caller
   and for communication between successive calls to `getopt'.
 
   On entry to `getopt', zero means this is the first call; initialize.
 
   When `getopt' returns EOF, this is the index of the first of the
   non-option elements that the caller should itself scan.
 
   Otherwise, `optind' communicates from one call to the next
   how much of ARGV has been scanned so far.  */
 
/* XXX 1003.2 says this must be 1 before any call.  */
    int optind;
 
/* The next char to be scanned in the option-element
   in which the last option character we returned was found.
   This allows us to pick up the scan where we left off.
 
   If this is zero, or a null string, it means resume the scan
   by advancing to the next ARGV-element.  */
 
    char *nextchar;
 
/* Callers store zero here to inhibit the error message
   for unrecognized options.  */
 
    int opterr;
 
/* Set to an option character which was unrecognized.
   This must be initialized on some systems to avoid linking in the
   system's own getopt implementation.	*/
 
    int optopt;

    enum
    {
      REQUIRE_ORDER, PERMUTE, RETURN_IN_ORDER
    } ordering;
 
/* Value of POSIXLY_CORRECT environment variable.  */
    char *posixly_correct;
 
/* Handle permutation of arguments.  */
 
/* Describe the part of ARGV that contains non-options that have
   been skipped.  `first_nonopt' is the index in ARGV of the first of them;
   `last_nonopt' is the index after the last of them.  */
 
    int first_nonopt;
    int last_nonopt;
};

/* Describe the long-named options requested by the application.
   The LONG_OPTIONS argument to getopt_long or getopt_long_only is a vector
   of `struct option' terminated by an element containing a name which is
   zero.

   The field `has_arg' is:
   no_argument		(or 0) if the option does not take an argument,
   required_argument	(or 1) if the option requires an argument,
   optional_argument	(or 2) if the option takes an optional argument.

   If the field `flag' is not NULL, it points to a variable that is set
   to the value given in the field `val' when the option is found, but
   left unchanged if the option is not found.

   To have a long-named option do something other than set an `int' to
   a compiled-in constant, such as set a value from `optarg', set the
   option's `flag' field to zero and its `val' field to a nonzero
   value (the equivalent single-letter option character, if there is
   one).  For long options that have a zero `flag' field, `getopt'
   returns the contents of the `val' field.  */

struct option
{
#if	__STDC__
  const char *name;
#else
  char *name;
#endif
  /* has_arg can't be an enum because some compilers complain about
     type mismatches in all the code that assumes it is an int.	 */
  int has_arg;
  int *flag;
  int val;
};

/* Names for the values of the `has_arg' field of `struct option'.  */

#define no_argument		0
#define required_argument	1
#define optional_argument	2

#if __STDC__
extern int my_getopt (struct getopt_info * info,
		   int argc, char *const *argv, const char *shortopts);
extern int my_getopt_long (struct getopt_info * info,
			int argc, char *const *argv, const char *shortopts,
			const struct option *longopts, int *longind);
extern int my_getopt_long_only (struct getopt_info * info,
			     int argc, char *const *argv,
			     const char *shortopts,
			     const struct option *longopts, int *longind);

/* Internal only.  Users should not call this directly.	 */
extern int my_getopt_internal (struct getopt_info * info,
			     int argc, char *const *argv,
			     const char *shortopts,
			     const struct option *longopts, int *longind,
			     int long_only);
#else /* not __STDC__ */
extern int my_getopt ();
extern int my_getopt_long ();
extern int my_getopt_long_only ();

extern int my__getopt_internal ();
#endif /* not __STDC__ */

#ifdef	__cplusplus
}
#endif

#endif /* _GETOPT_H */
