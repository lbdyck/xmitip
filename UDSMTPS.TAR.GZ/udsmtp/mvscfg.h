/* config.h.  Generated automatically by configure.  */
/* config.h.in.  Generated automatically from configure.in by autoheader.  */
/* $Id: mvscfg.h,v 1.3 1999/12/15 17:49:04 mike Exp $ */
 
/* Define to empty if the keyword does not work.  */
/* #undef const */
 
/* Define if you don't have vprintf but do have _doprnt.  */
/* #undef HAVE_DOPRNT */
 
/* Define if you have popen. */
/* #define HAVE_POPEN 1  */
 
/* Define if you have memxlt. */
#define HAVE_MEMXLT 1
 
/* Define if you have the vprintf function.  */
#define HAVE_VPRINTF 1
 
/* Define if you have the vsnprintf function.  */
#define HAVE_VSNPRINTF 1
 
/* Define as __inline if that's what the C compiler calls it.  */
#define inline __inline
 
/* Define to `unsigned' if <sys/types.h> doesn't define.  */
/* #undef size_t */
 
/* Define if you have the ANSI C header files.  */
#define STDC_HEADERS 1
 
/* Define if you have the <errno.h> header file. */
#define HAVE_ERRNO_H 1
 
/* Define if you have the <malloc.h> header file. */
#define HAVE_MALLOC_H 1
 
/* Define if you have the <stdlib.h> header file. */
#define HAVE_STDLIB_H 1
 
/* Define if you have the <math.h> header file. */
#define HAVE_MATH_H 1
 
/* Define if you have the <memory.h> header file. */
#define HAVE_MEMORY_H 1
 
/* Define if you have the <string.h> header file. */
#define HAVE_STRING_H 1
 
/* Define if you have the <strings.h> header file. */
/* (But not if you have string.h, generally) */
/* #undef HAVE_STRINGS_H */
 
/* Define if your <sys/time.h> declares struct tm.  */
/* #undef TM_IN_SYS_TIME */
 
/* Define if you have the memcpy function.  */
#define HAVE_MEMCPY 1
 
/* Define if you have the memmove function.  */
#define HAVE_MEMMOVE 1
 
/* Define if you have the memset function.  */
#define HAVE_MEMSET 1
 
/* Define if you have the strchr function.  */
#define HAVE_STRCHR 1
 
/* Define if you have the strdup function.  */
/* #define HAVE_STRDUP 1 *
 
/* Define if you have the strerror function.  */
#define HAVE_STRERROR 1
 
/* Define if you have the strftime function.  */
#define HAVE_STRFTIME 1
 
/* Define if you have the strspn function.  */
#define HAVE_STRSPN 1
 
/* Define if you have the strtod function.  */
#define HAVE_STRTOD 1
 
/* Define if you have the strtol function.  */
#define HAVE_STRTOL 1
 
/* Define if you have the strlwr function.  */
#define HAVE_STRLWR 1
 
/* Define if you have the gethostname function.  */
#define HAVE_GETHOSTNAME 1
 
/* Define if you have the tolower function.  */
#define HAVE_TOLOWER 1
 
/* Define if you have the access function.  */
#define HAVE_ACCESS 1
 
/* Define if you have the putenv function.  */
#define HAVE_PUTENV 1
 
/* Define if you have the <fcntl.h> header file.  */
#define HAVE_FCNTL_H 1
 
/* Define if you have the <sys/stat.h> header file.  */
#define HAVE_SYS_STAT_H 1
 
/* Define if you have the <sys/time.h> header file.  */
#define HAVE_SYS_TIME_H 1
 
/* Define if you have the <sys/types.h> header file.  */
#define HAVE_SYS_TYPES_H 1
 
/* Define if you have the <unistd.h> header file.  */
/* #define HAVE_UNISTD_H 1 */
 
/* Define if you have the <stdarg.h> header file.  */
#define HAVE_STDARG_H 1
 
/* Define if you have the <varargs.h> header file.  */
/* #undef HAVE_VARARGS_H */
 
/* Define if you have the <netdb.h> header file.  */
#define HAVE_NETDB_H 1

/* Define if you have SAS/C style storage pools. */
#define HAVE_I370_POOL_H 1

/* Define if you have storage pools that pool.c can use. */
#define HAVE_POOL 1

/* Define if you have the WTO service (OS/390, generally speaking) */
#define ENABLE_WTO 1

/* Define if you have the SAS/C osdynalloc routine available. */
#define HAVE_OSDYNALLOC 1

/* Define if you have the SAS/C quiet routine available. */
#define HAVE_QUIET 1

/* Define if you want normal MVS filename processing in bmail. */
#define ENABLE_MVS 1
