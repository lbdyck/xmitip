/**
    UDSMTP - Simple SMTP Transmission Agent.
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: udsmtp.h,v 1.16 2001/02/16 20:28:55 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    This file provides the public interface the conversion
    routines.
**/
 
#ifndef UDSMTP
#define UDSMTP 1

/*
    The comments are needed so that these numbers can be automatically
    extracted.	Tabs MUST be used.
*/

#define	UDSMTP_MAJOR	1	/* VVV */
#define	UDSMTP_MINOR	5	/* VVV */
#define	UDSMTP_PATCH	2	/* VVV */

typedef int boolean;

/*
    The result of parsing the input commands.
*/
 
struct cmdParse
{
    char * host;	/* Host to connect to */
    char * logfile;	/* Where to log messages */
    char * returnfile;  /* Where to output messages that are to be returned */
    char * retryfile;   /* Where to output messages that are to be retried */
    char * failfile;    /* Where to output messages that can't be returned */
    char * received;    /* Received from text */
    int    port;	/* TCP/IP port to use */
    int    delay;	/* Reconnect delay */
    int    s;		/* The socket */
    boolean trimblanks; /* If TRUE, remove all trailing blanks from input */
    boolean mx;         /* If TRUE, do MX record processing */
};
typedef struct cmdParse TCmdParse;
typedef TCmdParse * PTCmdParse;
 
#endif

/**
    End of Udsmtp.h
**/
