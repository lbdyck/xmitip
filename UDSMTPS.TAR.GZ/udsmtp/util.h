/**
    UDSMTP - Simple SMTP Client
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: util.h,v 1.5 1999/09/02 13:59:44 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    Pool routines.
**/
 
#ifndef UTIL

#include <time.h>

void SetFlushLog( int );
#if defined(__STDC__)
char * remfrnt( char * ptr, const char * c );
char * remend( char * ptr, const char * c );
char * cpyn( char * target, const char * src, int n );
char * catn( char * target, const char * src, int n );
#if !defined(HAVE_STRERROR)
char * strerror( int errnum );
#endif
void sdup( const char * src, char ** tgt );
int sdupx( const char * PreferedSrc, const char * AlternateSrc,
    char ** tgt );
void empty( char ** src );
char * strbuff( unsigned int len );
#if !defined(HAVE_STRDUP)
char * strdup( const char * c );
#endif
char * strdupAndFree( const char * s, char * p );
char * strdupcat( const char * s1, const char * s2, char * p );
#if !defined(HAVE_STRLWR)
    char * strlwr( char * c );
    char * strupr( char * c );
#endif
#if !defined(HAVE_MEMXLT)
    void * memxlt( void * data, const char * table, size_t len );
#endif
int trace( const char * fmt, ... );
int Stdout( const char * fmt, ... );
int Stderr( const char * fmt, ... );
int Stderrp( const char * fmt, ... );
int OpenLogFile( const char * name );
void CloseLogFile( void );
void FlushLogFile( void );
int Stdl( const char * fmt, ... );
int OpenReturnFile( const char * name );
void CloseReturnFile( void );
int Stdr( const char * fmt, ... );
int OpenRetryFile( const char * name );
void CloseRetryFile( void );
int Stdt( const char * fmt, ... );
int OpenFailFile( const char * name );
void CloseFailFile( void );
int Stdf( const char * fmt, ... );
void SavePgmName( const char * pgm );
const char * GetPgmName( void );
struct tm * GetLocalTime( struct tm * local_tm );
void TimeStamp( void );
char * Fmt822Date( time_t Time, char * Buff );
#if defined(ENABLE_WTO)
void SetWto( int );
int GetWto( void );
#endif
#else
void SetFlushLog();
char * remfrnt();
char * remend();
char * cpyn();
char * catn();
#if !defined(HAVE_STRERROR)
char * strerror();
#endif
void sdup();
int sdupx();
void empty();
char * strbuff();
#if !defined(HAVE_STRDUP)
char * strdup();
#endif
char * strdupAndFree();
char * strdupcat();
#if !defined(HAVE_STRLWR)
    char * strlwr();
    char * strupr();
#endif
#if !defined(HAVE_MEMXLT)
    void * memxlt();
#endif
int OpenLogFile();
void CloseLogFile();
void FlushLogFile();
int Stdl();
int OpenReturnFile();
void CloseReturnFile();
int Stdr( const char * fmt, ... );
int OpenRetryFile( const char * name );
void CloseRetryFile( void );
int Stdt( const char * fmt, ... );
int OpenFailFile( const char * name );
void CloseFailFile( void );
int Stdf( const char * fmt, ... );
void SavePgmName();
const char * GetPgmName();
struct tm * GetLocalTime();
char * Fmt822Date();
#if defined(ENABLE_WTO)
void SetWto();
int GetWto();
#endif
void TimeStamp();
int trace();
int Stdout();
int Stderrp();
#endif
#define UTIL
#endif

/**
    End of util.h
**/

