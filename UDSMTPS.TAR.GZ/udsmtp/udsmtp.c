/**
    UDSMTP - Simple SMTP Client
    Copyright (C) 1995, 1996 University of Delaware.

    $Id: udsmtp.c,v 1.19 2007/05/03 15:22:00 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    This module handles the basic startup tasks, followed by most
    other tasks.
**/
 
/* #define TRACING */
/* #define CVDEBUG 1 */
 
#include "genincl.h"
#include "getopt.h"
#include "list.h"
#include "udsmtp.h"
#include "args.h"
#include "util.h"
#include "pool.h"
#include "mx.h"

#include <sys/time.h>
#include <sys/types.h>
#include <sys/socket.h>
#include <netdb.h>
#include <netinet/in.h>
#include <arpa/inet.h>
#include <arpa/nameser.h>
#include <resolv.h>
#include <fcntl.h>
 
/*
    Maximum "Received:" lines.  More lines than this in an rfc 822
    header are considered to be a loop.
*/

#define MAX_HOP_CNT 50

/*
    Total # of header lines allowed.
*/

#define MAX_HEADER 10000

/*
    Counters for messages skipped and messages returned.
*/

int SkipCnt = 0;
int ReturnCnt = 0;
int RetryCnt = 0;
int FailCnt = 0;

/*
    Describe the disposition of the mail.
*/

enum eDispCode {DispMail, DispLooping, DispTooLong, DispMangled};
typedef enum eDispCode DispCode;

enum eTimeOuts {
    NetworkConnect,
    NetworkClose,
    NetworkRead,
    NetworkWrite };
typedef enum eTimeOuts tTimeOuts;

/* #define FORCE_TIMEOUTS 1 */
#if !defined(FORCE_TIMEOUTS)
    static int TimeOuts[] = {
	30,	/* Connect */
	30,	/* Close */
	300,	/* Read */
	300	/* Write */
    };
#else
    static int TimeOuts[] = {
	1,	/* Connect */
	1,	/* Close */
	1,	/* Read */
	1	/* Write */
    };
#endif

/*
    Define to test what happens when udsmtp can't talk SMTP to a
    host.  Will be inserted into the MX list.  Obviously, host
    should not talk smtp.
*/

/* #define DUMMY_HOST "orca.nss.udel.edu" */

static const char * TimeOutNames[] = {
    "network connect",
    "network close",
    "network read",
    "network write"
};

/*
    Define the number of writes that write 0 bytes we
    will tolerate and the delay between such writes.
*/

#define ZERO_WRITE_MAX 30
#define ZERO_WRITE_DELAY 1

/*
    Define the MVS standard input file.
*/

#if defined(I370)
static FILE * mvsstdin;
#endif

#if defined(__STDC__)
static boolean Select( int Socket, tTimeOuts TimeOut );
static void OpenInput( int argc, char * argv[], int LastArg );
static void AddReceived( PTCmdParse c, int (*WRtn)( const char * Buff, ... ));
static boolean NetConnect( PTCmdParse c, char * hostname );
static void NetClose( PTCmdParse c );
static int NetRead( PTCmdParse c, char * buff, int len );
static void SkipMessage( PTCmdParse c, boolean MessageAvailable );
static char * GetReturnAddress( char * MailFrom );
static void ReturnMessage( PTCmdParse c, PPTobjlistHeader HdrList,
    PPTobjlistHeader CnvList, boolean MessageAvailable );
static void RetryMessage( PTCmdParse c, PPTobjlistHeader HdrList,
    PPTobjlistHeader CnvList, boolean MessageAvailable );
static boolean CheckCode( PTCmdParse c, PPTobjlistHeader HdrList,
    PPTobjlistHeader CnvList, boolean MessageAvailable );
static boolean CheckStartCode( PTCmdParse c );
static void NetWrite( PTCmdParse c, char * p, int len, boolean flush );
static void NetWrite2( PTCmdParse c, char * p, int len );
static void NetRecWrite( PTCmdParse c, char * p, int len,
    PPTobjlistHeader List );
static void DoReset( PTCmdParse c, PPTobjlistHeader CnvList );
static void MXConnect( PTCmdParse c );
static void DumpMessage( PTCmdParse c, const char * Reason,
    PTobjlistHeader HdrList );
static void NetReadSendWait( PTCmdParse c );
static DispCode PreFetch( PTCmdParse c, char * TriggerLine, int tlen,
    PPTobjlistHeader pList, PPTobjlistHeader CnvList );
static boolean GetStdinLine( PTCmdParse c, char * InBuff, int maxlen,
	int * len );
static boolean GetLine( PTCmdParse c, PPTobjlistHeader HdrList,
    PPTobjlistContext Context, boolean * DoneHeaders,
    char * InBuff, int maxlen, int * len );
static void HandleFailure( PTCmdParse c,
    PPTobjlistHeader HdrList,
    PPTobjlistHeader CnvList,
    DispCode Disp );
static void TerminateClean( void );
#else
static boolean Select();
static void OpenInput();
static void AddReceived();
static boolean NetConnect();
static void NetClose();
static int NetRead();
static void SkipMessage();
static char * GetReturnAddress();
static void ReturnMessage();
static void RetryMessage();
static boolean CheckCode();
static boolean CheckStartCode();
static void NetWrite();
static void NetWrite2();
static void NetRecWrite();
static void DoReset();
static void MXConnect();
static void DumpMessage();
static void NetReadSendWait();
static DispCode PreFetch();
static boolean GetStdinLine();
static boolean GetLine();
static void HandleFailure();
static void TerminateClean();
#endif

static boolean CleanExit = FALSE;
static TCmdParse c;	    /* Command parse result */

/*
    This is the standard codepage 1047, used by most IBM TCP/IP
    related products to convert between EBCDIC and ASCII.  It is a
    reversable table - passing input through EBCDIC_ISO_8559_1 and
    then back through ISO_8859_1_EBCDIC will yield the original
    input.
*/

#if EBCDIC_COMPILER
static const unsigned char EBCDIC_ISO_8859_1[ 256 ]  = {
    0x00, 0x01, 0x02, 0x03, 0x9c, 0x09, 0x86, 0x7f,    /* 00 - 07 */
    0x97, 0x8d, 0x8e, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,    /* 08 - 0f */
    0x10, 0x11, 0x12, 0x13, 0x9d, 0x85, 0x08, 0x87,    /* 10 - 17 */
    0x18, 0x19, 0x92, 0x8f, 0x1c, 0x1d, 0x1e, 0x1f,    /* 18 - 1f */
    0x80, 0x81, 0x82, 0x83, 0x84, 0x0a, 0x17, 0x1b,    /* 20 - 27 */
    0x88, 0x89, 0x8a, 0x8b, 0x8c, 0x05, 0x06, 0x07,    /* 28 - 2f */
    0x90, 0x91, 0x16, 0x93, 0x94, 0x95, 0x96, 0x04,    /* 30 - 37 */
    0x98, 0x99, 0x9a, 0x9b, 0x14, 0x15, 0x9e, 0x1a,    /* 38 - 3f */
    0x20, 0xa0, 0xe2, 0xe4, 0xe0, 0xe1, 0xe3, 0xe5,    /* 40 - 47 */
    0xe7, 0xf1, 0xa2, 0x2e, 0x3c, 0x28, 0x2b, 0x7c,    /* 48 - 4f */
    0x26, 0xe9, 0xea, 0xeb, 0xe8, 0xed, 0xee, 0xef,    /* 50 - 57 */
    0xec, 0xdf, 0x21, 0x24, 0x2a, 0x29, 0x3b, 0x5e,    /* 58 - 5f */
    0x2d, 0x2f, 0xc2, 0xc4, 0xc0, 0xc1, 0xc3, 0xc5,    /* 60 - 67 */
    0xc7, 0xd1, 0xa6, 0x2c, 0x25, 0x5f, 0x3e, 0x3f,    /* 68 - 6f */
    0xf8, 0xc9, 0xca, 0xcb, 0xc8, 0xcd, 0xce, 0xcf,    /* 70 - 77 */
    0xcc, 0x60, 0x3a, 0x23, 0x40, 0x27, 0x3d, 0x22,    /* 78 - 7f */
    0xd8, 0x61, 0x62, 0x63, 0x64, 0x65, 0x66, 0x67,    /* 80 - 87 */
    0x68, 0x69, 0xab, 0xbb, 0xf0, 0xfd, 0xfe, 0xb1,    /* 88 - 8f */
    0xb0, 0x6a, 0x6b, 0x6c, 0x6d, 0x6e, 0x6f, 0x70,    /* 90 - 97 */
    0x71, 0x72, 0xaa, 0xba, 0xe6, 0xb8, 0xc6, 0xa4,    /* 98 - 9f */
    0xb5, 0x7e, 0x73, 0x74, 0x75, 0x76, 0x77, 0x78,    /* a0 - a7 */
    0x79, 0x7a, 0xa1, 0xbf, 0xd0, 0x5b, 0xde, 0xae,    /* a8 - af */
    0xac, 0xa3, 0xa5, 0xb7, 0xa9, 0xa7, 0xb6, 0xbc,    /* b0 - b7 */
    0xbd, 0xbe, 0xdd, 0xa8, 0xaf, 0x5d, 0xb4, 0xd7,    /* b8 - bf */
    0x7b, 0x41, 0x42, 0x43, 0x44, 0x45, 0x46, 0x47,    /* c0 - c7 */
    0x48, 0x49, 0xad, 0xf4, 0xf6, 0xf2, 0xf3, 0xf5,    /* c8 - cf */
    0x7d, 0x4a, 0x4b, 0x4c, 0x4d, 0x4e, 0x4f, 0x50,    /* d0 - d7 */
    0x51, 0x52, 0xb9, 0xfb, 0xfc, 0xf9, 0xfa, 0xff,    /* d8 - df */
    0x5c, 0xf7, 0x53, 0x54, 0x55, 0x56, 0x57, 0x58,    /* e0 - e7 */
    0x59, 0x5a, 0xb2, 0xd4, 0xd6, 0xd2, 0xd3, 0xd5,    /* e8 - ef */
    0x30, 0x31, 0x32, 0x33, 0x34, 0x35, 0x36, 0x37,    /* f0 - f7 */
    0x38, 0x39, 0xb3, 0xdb, 0xdc, 0xd9, 0xda, 0x9f     /* f8 - ff */
};

static const unsigned char ISO_8859_1_EBCDIC[ 256 ]  = {
    0x00, 0x01, 0x02, 0x03, 0x37, 0x2d, 0x2e, 0x2f,    /* 00 - 07 */
    0x16, 0x05, 0x25, 0x0b, 0x0c, 0x0d, 0x0e, 0x0f,    /* 08 - 0f */
    0x10, 0x11, 0x12, 0x13, 0x3c, 0x3d, 0x32, 0x26,    /* 10 - 17 */
    0x18, 0x19, 0x3f, 0x27, 0x1c, 0x1d, 0x1e, 0x1f,    /* 18 - 1f */
    0x40, 0x5a, 0x7f, 0x7b, 0x5b, 0x6c, 0x50, 0x7d,    /* 20 - 27 */
    0x4d, 0x5d, 0x5c, 0x4e, 0x6b, 0x60, 0x4b, 0x61,    /* 28 - 2f */
    0xf0, 0xf1, 0xf2, 0xf3, 0xf4, 0xf5, 0xf6, 0xf7,    /* 30 - 37 */
    0xf8, 0xf9, 0x7a, 0x5e, 0x4c, 0x7e, 0x6e, 0x6f,    /* 38 - 3f */
    0x7c, 0xc1, 0xc2, 0xc3, 0xc4, 0xc5, 0xc6, 0xc7,    /* 40 - 47 */
    0xc8, 0xc9, 0xd1, 0xd2, 0xd3, 0xd4, 0xd5, 0xd6,    /* 48 - 4f */
    0xd7, 0xd8, 0xd9, 0xe2, 0xe3, 0xe4, 0xe5, 0xe6,    /* 50 - 57 */
    0xe7, 0xe8, 0xe9, 0xad, 0xe0, 0xbd, 0x5f, 0x6d,    /* 58 - 5f */
    0x79, 0x81, 0x82, 0x83, 0x84, 0x85, 0x86, 0x87,    /* 60 - 67 */
    0x88, 0x89, 0x91, 0x92, 0x93, 0x94, 0x95, 0x96,    /* 68 - 6f */
    0x97, 0x98, 0x99, 0xa2, 0xa3, 0xa4, 0xa5, 0xa6,    /* 70 - 77 */
    0xa7, 0xa8, 0xa9, 0xc0, 0x4f, 0xd0, 0xa1, 0x07,    /* 78 - 7f */
    0x20, 0x21, 0x22, 0x23, 0x24, 0x15, 0x06, 0x17,    /* 80 - 87 */
    0x28, 0x29, 0x2a, 0x2b, 0x2c, 0x09, 0x0a, 0x1b,    /* 88 - 8f */
    0x30, 0x31, 0x1a, 0x33, 0x34, 0x35, 0x36, 0x08,    /* 90 - 97 */
    0x38, 0x39, 0x3a, 0x3b, 0x04, 0x14, 0x3e, 0xff,    /* 98 - 9f */
    0x41, 0xaa, 0x4a, 0xb1, 0x9f, 0xb2, 0x6a, 0xb5,    /* a0 - a7 */
    0xbb, 0xb4, 0x9a, 0x8a, 0xb0, 0xca, 0xaf, 0xbc,    /* a8 - af */
    0x90, 0x8f, 0xea, 0xfa, 0xbe, 0xa0, 0xb6, 0xb3,    /* b0 - b7 */
    0x9d, 0xda, 0x9b, 0x8b, 0xb7, 0xb8, 0xb9, 0xab,    /* b8 - bf */
    0x64, 0x65, 0x62, 0x66, 0x63, 0x67, 0x9e, 0x68,    /* c0 - c7 */
    0x74, 0x71, 0x72, 0x73, 0x78, 0x75, 0x76, 0x77,    /* c8 - cf */
    0xac, 0x69, 0xed, 0xee, 0xeb, 0xef, 0xec, 0xbf,    /* d0 - d7 */
    0x80, 0xfd, 0xfe, 0xfb, 0xfc, 0xba, 0xae, 0x59,    /* d8 - df */
    0x44, 0x45, 0x42, 0x46, 0x43, 0x47, 0x9c, 0x48,    /* e0 - e7 */
    0x54, 0x51, 0x52, 0x53, 0x58, 0x55, 0x56, 0x57,    /* e8 - ef */
    0x8c, 0x49, 0xcd, 0xce, 0xcb, 0xcf, 0xcc, 0xe1,    /* f0 - f7 */
    0x70, 0xdd, 0xde, 0xdb, 0xdc, 0x8d, 0x8e, 0xdf     /* f8 - ff */
};
#endif

#define ASCII_CR 13
#define ASCII_LF 10

#if EBCDIC_COMPILER
#define ASCII2EBC( p, l ) \
    { memxlt( p, (const char *) ISO_8859_1_EBCDIC, l ); }
#define EBC2ASCII( p, l ) \
    { memxlt( p, (const char *) EBCDIC_ISO_8859_1, l ); }
#else
#define ASCII2EBC( p, l )
#define EBC2ASCII( p, l )
#endif

/**
    End of Globals.
**/

static boolean
Select( Socket, TimeOut )
    int Socket;
    tTimeOuts TimeOut;

/*
    This routine issues a select for socket 'Socket'.  Type of
    select is determined by the type of timeout, 'TimeOut'.
    We use select and non-blocking I/O so we can create a
    timeout mechanism.  The option SO_KEEPALIVE could also
    do what we want, but it is not implemented on MVS.

    The basic problem we were having is often times a problem
    on the target system would cause the socket connection to
    hang.  This in turn would cause udsmtp to hang.  We want
    the connection to timeout so we can restart.
*/

{
    struct timeval TimeVal;
    fd_set SelectSet;
    int SocketCnt;

    memset( &SelectSet, 0, sizeof SelectSet );
    FD_SET( Socket, &SelectSet );

    memset( &TimeVal, 0, sizeof TimeVal );
    TimeVal.tv_sec = TimeOuts[ TimeOut ];
    TimeVal.tv_usec = 0;

    switch (TimeOut) {
	case NetworkWrite:
	case NetworkConnect:
	    SocketCnt = select( Socket+1, NULL, &SelectSet, NULL, &TimeVal );
	    break;

	case NetworkRead:
	    SocketCnt = select( Socket+1, &SelectSet, NULL, NULL, &TimeVal );
	    break;

	case NetworkClose:
	    SocketCnt = 1;
	    break;

	default:
	    Stderrp( "design error in Select call.\n" );
	    exit( 1 );
    }

    if (SocketCnt != 1) {
	if (errno == EINTR || SocketCnt == 0) {
	    Stdl( "**timeout detected (%s).\n",
		 TimeOutNames[ TimeOut ] );
	    Stderrp( "timeout detected (%s).\n",
		 TimeOutNames[ TimeOut ] );
	} else {
	    Stdl( "**error during select: '%s'.\n", strerror( errno ) );
	    Stderrp( "error during select: '%s'.\n", strerror( errno ) );
	}
	return( FALSE );
    } else {
	return( TRUE );
    }
}

/**
    End of Select.
**/

static void
MyAtExit( void )
{
    if (!CleanExit) {
#if EBCDIC_COMPILER
	Stderrp( "Try 'TSO %s --HELP' for some help.\n",
	    GetPgmName() );
#else
	Stderrp( "Try '%s --help' for some help.\n",
	    GetPgmName() );
#endif
    }
}

/**
    End of MyAtExit.
**/

void
SetCleanExit( void )
{
    CleanExit = TRUE;
}

/**
    End of SetCleanExit.
**/

static void
OpenInput( argc, argv, LastArg )
    int argc;
    char * argv[];
    int LastArg;

/*
    On MVS, we want to open the input as binary because we can use
    much better IO routines.

    Modifies mvsstdin.
*/

{
#if defined(I370)
    const char * DDname;

    if (LastArg < argc)
	DDname = argv[ LastArg ];
    else
	DDname = "DDN:SYSIN";
    mvsstdin = afopen( DDname, "rb", "seq", "" );
    if (mvsstdin == NULL) {
	Stderrp( "failed to open %s.\n", DDname );
	exit( 1 );
    }
#else
    if (LastArg < argc) {
	if (freopen( argv[ LastArg ], "rb", stdin ) == NULL) {
	    Stderrp( "error opening %s: %s.\n", argv[ LastArg ],
		strerror( errno ) );
	    exit( 1 );
	}
    }
#endif
}

/**
    End of OpenInput.
**/

static void
AddReceived( c, WRtn )
    PTCmdParse c;
    int (*WRtn)( const char * Fmt, ... );

/*
    This routine adds a received by line to the output.  This
    header line is never saved in the header list because we don't
    want it to appear in retry messages or failed messages.
*/

{
    char rbuff[ 256 ];
    char DBuff[ 128 ];
    int  rlen;

    if (c->received == NULL) return;

    rlen = sprintf( rbuff, "Received: from %s", c->received );
    if (WRtn == NULL) {
	NetWrite( c, rbuff, rlen, FALSE );
    } else {
	(*WRtn)( "%s\n", rbuff );
    }

    rlen = sprintf( rbuff, "    by udsmtp (V%d.%d.%d);",
	UDSMTP_MAJOR, UDSMTP_MINOR, UDSMTP_PATCH );
    if (WRtn == NULL) {
	NetWrite( c, rbuff, rlen, FALSE );
    } else {
	(*WRtn)( "%s\n", rbuff );
    }

    rlen = sprintf( rbuff, "    %s", 
	Fmt822Date( time( NULL ), DBuff ));
    if (WRtn == NULL) {
	NetWrite( c, rbuff, rlen, FALSE );
    } else {
	(*WRtn)( "%s\n", rbuff );
    }
}

/**
    End of AddReceived.
**/

static DispCode
PreFetch( c, TriggerLine, tlen, List, CnvList )
    PTCmdParse c;
    char * TriggerLine;
    int tlen;
    PPTobjlistHeader List;
    PPTobjlistHeader CnvList;

/*
    This routine is used to check the basics of the rfc822 header.
    To do this, we must prefetch the header and save it to a list.
    Some basic checks are made and a disposition code is returned.
    TriggerLine contains the triggering SMTP command (MAIL
    FROM:<...>) that caused the call to this routine.  It is added
    to the list as XMAIL FROM so that when the list is processed
    in GetLine, we don't end up back here.

             c  -- Basic parameters
    TriggerLine -- The line of input that caused this routine to
                   be called.  Should be MAIL FROM: ....
           tlen -- Length of TriggerLine.
           List -- The list that will receive the lines of text in the
                   header.
	CnvList -- This is a good time to clear out the list that
		   is used to record the SMTP conversion.  This
		   list is added to any error messages that we need
		   to create.

    Note:  it is possible that this routine isn't needed any
    longer.  We used to do more processing here.  However, I will
    retain the routine in case it is needed in the future.  Having
    an in memory copy of the envelope and header seems like a good
    thing, no?
*/

{
    char InBuff[ 4096 ];
    char Keyword[ 64 ];		/* Holds the keyword portion of a header ln */
				/* Note keyword is lowercase, no colon */
    int len;			/* Length of line read */
    int KeyLen;			/* Length of the keyword */
    int RcvedCnt = 0;		/* # of Received: lines */
    int HeaderCnt = 0;		/* Total lines, BSMTP+rfc822 */
    DispCode Disp = DispMail;	/* What to do with message */
    boolean InHeader = FALSE;	/* In rfc 822 header? */
    boolean Terminate = FALSE;

/*
    Create a new list that is used to hold the header lines.
*/

    if (*List != NULL) ListDelete( *List );
    if (*CnvList != NULL) ListDelete( *CnvList );
    *List = PoolListCreate();
    *CnvList = PoolListCreate();

/*
    Turn MAIL FROM: into XMAIL FROM: so when the list is processed,
    we don't end up back here.
*/

    InBuff[ 0 ] = 'X';
    memcpy( InBuff + 1, TriggerLine, tlen + 1 );
    remend( InBuff, " \t" );
    tlen = strlen( InBuff );
    ListStrlAppend( *List, InBuff, tlen );

/*
    Process the input until we either receive a QUIT command or get
    to the end of the header.  Or run out of input.
*/

    while (!Terminate) {
	if (!GetStdinLine( c, InBuff, sizeof InBuff, &len )) {
	    Disp = DispMangled;
	    break;
	}
	if (HeaderCnt++ > MAX_HEADER) {
	    if (Disp == DispMail)
		Disp = DispTooLong;
	    continue;
	}

	if (!InHeader) {
	    char tempbuff[ 5 ];

	    if (len == 4) {
		memcpy( tempbuff, InBuff, 4 );
		tempbuff[ 4 ] = '\0';
		strlwr( tempbuff );

		if (memcmp( tempbuff, "data", 4 ) == 0) {
		    InHeader = TRUE;
		} else if (memcmp( tempbuff, "quit", 4 ) == 0) {
		    Terminate = TRUE;
		}
	    }
	} else if (InHeader) {
	    char * colon;

	    if (InBuff[ 0 ] == ' ' || InBuff[ 0 ] == '\t') {
		KeyLen = 0;		/* Continued line */
	    } else {
		colon = strchr( InBuff, ':' );
		KeyLen = (colon == NULL) ? 0 : colon - InBuff;
		KeyLen = (KeyLen > sizeof Keyword - 1) ? 0 : KeyLen;
	    }

	    if (KeyLen > 0) {
		memcpy( Keyword, InBuff, KeyLen );
		Keyword[ KeyLen ] = '\0';
		strlwr( Keyword );
	    }

	    if (KeyLen == 8 && memcmp( "received", Keyword, 8 ) == 0) {
		RcvedCnt++;
		if (RcvedCnt > MAX_HOP_CNT) {
		    if (Disp == DispMail) Disp = DispLooping;
		    continue;
		}
	    } else if (len == 1 && InBuff[ 0 ] == '.') {
		Terminate = TRUE;
	    } else if (len == 0) {
		Terminate = TRUE;
	    }
	}

	ListAppend( *List, InBuff, len + 1 );
    }

    return( Disp );
}

/**
    End of PreFetch.
**/

static boolean
NetConnect( c, hostname )
    PTCmdParse c;
    char * hostname;

/*
    Opens a connection to the network.  Socket is located
    in c->s.
*/

{
    struct hostent * hp;            /* Name of host to connect to */
    struct sockaddr_in sin;         /* AF_INET socket address */
    struct linger Linger;	    /* Linger timeout for close */
    int Flag;
    int ConnectCode;
 
    memset( &sin, 0, sizeof sin );
    sin.sin_family          = AF_INET;
    sin.sin_port            = htons( c->port );
 
/*
    Check to see if the host name is in dotted form, else
    look up the name.
*/
 
    if ((sin.sin_addr.s_addr = inet_addr( hostname )) != -1)
    {
#if EBCDIC_COMPILER
        Stdl( "**(%s)\n", hostname );
#else
        Stdl( "**[%s]\n", hostname );
#endif
    }
    else 
    {
        hp      = gethostbyname( hostname );
        if (hp == NULL)
        {
	    Stderrp( "unable to locate host '%s'.\n", hostname );
            return( FALSE );
        }
#if EBCDIC_COMPILER
        Stdl( "**(%s)\n", hp->h_name );
#else
        Stdl( "**[%s]\n", hp->h_name );
#endif
        memcpy( &sin.sin_addr, hp->h_addr, hp->h_length );
        sin.sin_family          = hp->h_addrtype;
    }
 
    c->s = socket( AF_INET, SOCK_STREAM, 0);
    if (c->s == -1) {
	Stderrp( "socket call failed: %s.\n", strerror( errno ) );
	return( FALSE );
    }

/*
    Make non-blocking.  You are really supposed to do a GETFL, OR
    in what you want, then do a SETFL.  However, this does not
    appear to work with SAS/C  (GETFL=2, OR == 6, SETFL fails with 6.)
*/

#if !defined(I370)
    Flag = fcntl( c->s, F_GETFL, 0 );
    if(Flag == -1) {	/* fcntl failed... */
	Stderrp( "unable to get socket flags: %s.\n",
	    strerror( errno ) );
	exit( 1 );
    }
    Flag |= O_NONBLOCK;
#else
    Flag = O_NONBLOCK;
#endif
    if (fcntl( c->s, F_SETFL, Flag ) == -1) {
	Stderrp( "unable to mark socket non-blocking: %s.\n",
	    strerror( errno ) );
	exit( 1 );
    }

/*
    And set linger.
*/

    Linger.l_onoff = 1;
    Linger.l_linger = TimeOuts[ NetworkClose ];
    if (setsockopt( c->s, SOL_SOCKET, SO_LINGER,
	(const void *) &Linger, sizeof Linger )) {
	Stderrp( "unable to set SO_LINGER: %s.\n", strerror( errno ) );
	exit( 1 );
    }
 
    ConnectCode = connect( c->s, (struct sockaddr *) &sin, sizeof sin);
    if (ConnectCode == -1 && errno != EINPROGRESS) {
	Stderrp( "connect called failed: %s\n", strerror( errno ) );
	return( FALSE );
    }
    return( Select( c->s, NetworkConnect ) );
}

/**
    End of NetConnect.
**/

static void
NetClose( c )
    PTCmdParse c;

{
    int r;
    if (c->s <= 0) return;

    Select( c->s, NetworkClose );
    r = close( c->s );
    c->s = 0;
    if (r == -1) {
	Stderrp( "error during close: %s.\n", strerror( errno ) );
	exit( 1 );
    }
}

/**
    End of NetClose.
**/

static int
NetRead( c, buff, len )
    PTCmdParse c;
    char * buff;
    int len;

/*
    This routine reads from the network until ASCII CRLF is
    received.  On an EBCDIC machine, the data is converted to
    EBCDIC.  The trailing CRLF is removed.  We should never be in
    the case where the CRLF ends up in the middle of a packet
    because all SMTP responses are single line.  So, all we do is
    check to see if there is a CRLF at the end.  If not, and we
    have more space, keep reading.

    Returns the length of the data read or -1 on error.
*/

{
    int alen = len;	/* Actual size of read allowed */
    int plen = 0;	/* Previous bytes read */
    int rlen;           /* Number of bytes read */
    boolean Trunc = FALSE;

    LOOP {
	if (!Select( c->s, NetworkRead )) return( -1 );
	rlen = read( c->s, buff + plen, alen );
	if (rlen <= 0) {
	    Stdl( "error reading from network: %s\n",
	        strerror( errno ) );
	    Stderrp( "error reading from network: %s\n",
	        strerror( errno ) );
	    return( -1 );
	    break;
	} else if (plen + rlen >= 2 &&
	    buff[ plen + rlen - 1 ] == ASCII_LF &&
            buff[ plen + rlen - 2 ] == ASCII_CR) {
	    len = plen + rlen - 2;
	    buff[ len ] = '\0';
	    break;
        } else if (plen + rlen < len) {
	    plen += rlen;
	    alen -= rlen;
	} else {
	    len--;
	    buff[ len ] = '\0';
	    Trunc = TRUE;
	    break;
	}
    }
    ASCII2EBC( buff, len );
    if (Trunc) {
	Stdl( "**Truncation: '%s'.\n", buff );
    }
    return( len );
}

/**
    End of NetRead.
**/

static void
SkipMessage( c, MessageAvailable )
    PTCmdParse c;
    boolean MessageAvailable;

/*
    This routine simply reads from stdin until a single '.' is
    found.  If MessageAvailable is FALSE, then there is nothing to
    read, so do nothing.
*/

{
    char InBuff[ 4096 ];
    int len;

    if (!MessageAvailable) return;
    while( GetStdinLine( c, InBuff, sizeof InBuff, &len ) ) {
	if (len == 1 && InBuff[ 0 ] == '.') break;
    }
    SkipCnt++;
}

/**
    End of SkipMessage.
**/

static char *
GetReturnAddress( MailFrom )
    char * MailFrom;

/*
    This routine extracts the return address from a MAIL FROM:
    (or XMAIL FROM:) line and return dynamic storage with the
    return address stored there.  The '<>' that surround the
    address are removed.
*/

{
    char * colon;
    char * left;
    char * right;
    char * ReturnAddress;

    LOOP {
	colon = strchr( MailFrom, ':' );
	if (colon == NULL) break;
	left  = strchr( colon + 1, '<' );
	if (left == NULL) break;

	ReturnAddress = strdup( left + 1 );

	right = strchr( ReturnAddress, '>' );
	if (right == NULL) break;

	*right = '\0';
	return( ReturnAddress );
    }

    Stderrp( "malformed from address: '%s'.\n", MailFrom );
    exit( 1 );
    return( NULL );
}

/**
    End of GetReturnAddress.
**/

static void
ReturnMessage( c, HdrList, CnvList, MessageAvailable )
    PTCmdParse c;
    PPTobjlistHeader HdrList;
    PPTobjlistHeader CnvList;
    boolean MessageAvailable;

/*
    This routine is used to construct a return message.  If the
    HdrList is not NULL, then we can look for MAIL FROM (or XMAIL
    FROM), and send a failure message back.  The format of the
    message is rfc822/BSMTP.  If HdrList is NULL, then there isn't
    anything to do.  If the CnvList is not NULL, then copy the SMTP
    conversion into the message.  If MessageAvailable is not
    FALSE, then copy the message from stdin into the message as
    well.

    If the FROM address is the same as the address that we are
    using, then assume that we can't return the message to the
    sender and write everything to the failure file.

    If the CnvList is not NULL, then add an RSET to the list to
    make it clear to technical readers that the entire message was
    canceled.  This is not how most SMTP clients work.  Usually, if
    some addresses work and others don't, some are sent to.  Note
    that we really will do an RSET later!
*/


{
    char * p;				/* HdrList Ptr */
    char * ReturnAddress;		/* The return mailbox */
    char   hostname[ 256 ];		/* This host's name */
    char   OurSender[ 512 ];		/* The from address we use */
    int  len;				/* General length */
    boolean DelCont;                    /* If true, delete cont. lines */
    PTobjlistContext Context = NULL;
    PTobjlistContext StartOfHeaders = NULL;

    int (*WRtn)( const char * Fmt, ... );

    if (HdrList == NULL || *HdrList == NULL) return;	/* No header to check */
    Stdl( "**Returning message\n" );

    ReturnAddress = strdup( "postmaster" );

/*
    Scan the header list, looking for MAIL FROM or XMAIL
    FROM.  We can assume that it's there.  Stop looking when we run
    out of list or see 'DATA'.
*/

    gethostname( hostname, sizeof hostname - 1 );
    hostname[ sizeof hostname - 1 ] = '\0';

    sprintf( OurSender, "MAILER-DAEMON@%s", hostname );

    Context = NULL;
    LOOP {
	ListNext( *HdrList, &Context, (void *) &p, &len );
	if (Context == NULL) break;
	len--;

	if ((len > 9 && memcmp( p, "MAIL FROM", 9 ) == 0) ||
	           (len > 10 && memcmp( p, "XMAIL FROM", 10 ) == 0)) {
	    empty( &ReturnAddress );
	    ReturnAddress = GetReturnAddress( p );
	} else if (len == 4 && memcmp( p, "DATA", 4 ) == 0) {
	    break;
	}
    }

    if (strcmp( OurSender, ReturnAddress ) == 0) {
	WRtn = Stdf;
	FailCnt++;
    } else {
	WRtn = Stdr;
	ReturnCnt++;
    }

    WRtn( "MAIL FROM: <%s>\n", OurSender );
    WRtn( "RCPT TO: <%s>\n", ReturnAddress );
    Context = NULL;
    LOOP {
	ListNext( *HdrList, &Context, (void *) &p, &len );
	if (Context == NULL) break;
	len--;

	if ((len > 9 && memcmp( p, "MAIL FROM", 9 ) == 0) ||
	           (len > 10 && memcmp( p, "XMAIL FROM", 10 ) == 0)) {
		/* Skip... */
	} else if (len >= 8 && memcmp( p, "RCPT TO:", 8 ) == 0) {
		/* Skip... */
	} else if (len == 4 && memcmp( p, "DATA", 4 ) == 0) {
	    WRtn( "%s\n", p );
	    break;
	} else {
	    WRtn( "%s\n", p );
	}
    }

/*
    Now handle the header.  Generally, we want to create a new
    header, but lets keep the Received headers in the message.  We
    will use these to detect looping messages.  We will also want
    to copy the complete headers along with the message, so save
    a copy of the context.
*/

    WRtn( "Return-Path: <%s>\n", OurSender );
    AddReceived( c, WRtn );
    DelCont = TRUE;
    StartOfHeaders = Context;

    LOOP {
	char Keyword[ 64 ];
	int KeyLen;
        char * Colon;

	ListNext( *HdrList, &Context, (void *) &p, &len );
	if (Context == NULL) break;
	len--;

	if (len == 0) break;	/* End of header, really shouldn't happen */

	Colon = strchr( p, ':' );
	if (Colon != NULL) {
	    KeyLen = Colon - p;
	    if (KeyLen > sizeof Keyword - 1) {
		KeyLen = sizeof Keyword - 1;
	    }
	    memcpy( Keyword, p, KeyLen );
	    Keyword[ KeyLen ] = '\0';
	    strlwr( Keyword );

	    if (KeyLen == 8 && memcmp( Keyword, "received", 8 ) == 0) {
		WRtn( "%s\n", p );
		DelCont = FALSE;
	    } else {
		DelCont = TRUE;
	    }
	} else if (DelCont) {
	    continue;
	} else {
	    WRtn( "%s\n", p );
	}
    }
    WRtn( "From: %s\n", OurSender );
    WRtn( "To: %s\n", ReturnAddress );
    WRtn( "\n" );

    if (CnvList != NULL) {
	WRtn( " Error sending message, conversation was:\n" );
	WRtn( "\n" );
        Context = NULL;
	LOOP {
	    ListNext( *CnvList, &Context, (void *) &p, &len );
	    if (Context == NULL) break;
	    WRtn( " %s\n", p );
	}
	WRtn( " <=RSET\n" );
    }

    if (MessageAvailable) {
	char InBuff[ 4096 ];

	WRtn( "\n" );
	WRtn( " Original message:\n" );
	WRtn( "\n" );

	Context = StartOfHeaders;
	LOOP {
	    ListNext( *HdrList, &Context, (void *) &p, &len );
	    if (Context == NULL) {
		break;
	    } else {
		WRtn( " %s\n", p );
	    }
	}

	while( GetStdinLine( c, InBuff, sizeof InBuff, &len ) ) {
	    if (len == 1 && InBuff[ 0 ] == '.') break;
	    WRtn( " %s\n", InBuff );
	}
    } else {
	WRtn( "\n" );
	WRtn( " Original message no longer available.\n" );
    }
    WRtn( ".\n" );
}

/**
    End of ReturnMessage.
**/

static void
RetryMessage( c, HdrList, CnvList, MessageAvailable )
    PTCmdParse c;
    PPTobjlistHeader HdrList;
    PPTobjlistHeader CnvList;
    boolean MessageAvailable;

/*
    This routine just copies the message to the retry file.
*/


{
    PTobjlistContext Context = NULL;

    if (*HdrList == NULL) {	/* Must be a strange case */
	return;
    }

    Context = NULL;
    LOOP {
	char * p;

	ListStrNext( *HdrList, &Context, &p );
	if (Context == NULL) break;

	if (strlen ( p ) >= 11 && memcmp( p, "XMAIL FROM:", 11 ) == 0) {
	    p++;	/* Cvt XMAIL FROM to MAIL FROM */
	}
	Stdt( "%s\n", p );
    }

    if (MessageAvailable) {
	char InBuff[ 4096 ];
	int  len;

	while( GetStdinLine( c, InBuff, sizeof InBuff, &len ) ) {
	    if (len == 1 && InBuff[ 0 ] == '.') break;
	    Stdt( "%s\n", InBuff );
	}
    } else {
	Stdt( "\n" );
	Stdt( " Original message no longer available.\n" );
    }
    Stdt( ".\n" );
    RetryCnt++;
}

/**
    End of RetryMessage.
**/

static boolean
CheckCode( c, HdrList, CnvList, MessageAvailable )
    PTCmdParse c;
    PPTobjlistHeader HdrList;
    PPTobjlistHeader CnvList;
    boolean MessageAvailable;

/*
    This routine checks the return code and causes the message to
    be returned (code 5xx) or the message to be skipped and and a
    non-zero return code.  If the HdrList is NULL, then we have not
    read a header.  The only way this can happen is when
    non-message level commands (HELO, QUIT) fail for some reason.

    c -- Command parse.
    HdrList -- List containing the headers from the message.
    CnvLast -- A record of the SMTP conversation.
    MessageAvailable -- Is the message available in stdin to send
	back to the user, or did we already read it?
*/

{
    char ReadBuff[ 4096 ];
    int  len;

    len = NetRead( c, ReadBuff, sizeof ReadBuff );
    if (len == -1) {
	Stdl( "**terminating connection.\n" );
	Stderrp( "Terminating connection.\n" );
	TerminateClean();
	exit( 1 );
    }
    if (CnvList != NULL) {
	char * temp;

	temp = strdup( "=>" );
	temp = strdupcat( temp, ReadBuff, temp );
	ListStrlAppend( *CnvList, temp, len+2 );
	free( temp );
    }
    Stdl( "=>%s\n", ReadBuff );
    if (len < 4 ||
	(ReadBuff[ 3 ] != ' ' && ReadBuff[ 3 ] != '-' ) ||
	ReadBuff[ 0 ] < '1'  ||
	ReadBuff[ 0 ] > '5') {
	Stderrp( "previous message not a valid reply code.  Terminating.\n" );
	Stdl( "**previous message not a valid reply code.  Terminating.\n" );
	exit( 1 );
	return( FALSE );
    } else if (ReadBuff[ 0 ] == '1' ||
	       ReadBuff[ 0 ] == '2' ||
	       ReadBuff[ 0 ] == '3') {
	return( TRUE );
    } else if (ReadBuff[ 0 ] == '4' ||
	       ReadBuff[ 0 ] == '5') {
	Stdl( "**code signifies an error.\n" );
	Stderrp( "%s\n", ReadBuff );
	Stderrp( "code signifies an error.\n" );
	if (HdrList == NULL) {
	    Stdl( "**error not associated with a message, terminating.\n" );
	    Stderrp( "Error not associated with a message, terminating.\n" );
	    exit( 1 );
	} else if (ReadBuff[ 0 ] == '4') {
	    if (!MessageAvailable) {
		ReturnMessage( c, HdrList, CnvList, MessageAvailable );
	    } else if (c->retryfile != NULL) {
		RetryMessage( c, HdrList, CnvList, MessageAvailable );
	    } else {
		SkipMessage( c, MessageAvailable );
	    }
	} else if (ReadBuff[ 0 ] == '5') {
	    if (c->returnfile != NULL) {
		ReturnMessage( c, HdrList, CnvList, MessageAvailable );
	    }
	}
	if (*HdrList != NULL) *HdrList = ListDelete( *HdrList );
	if (*CnvList != NULL) *CnvList = ListDelete( *CnvList );
	return( FALSE );
    } else {
	Stderrp( "previous message not a valid reply code.  Terminating.\n" );
	Stdl( "previous message not a valid reply code.  Terminating.\n" );
	exit( 1 );
	return( FALSE );
    }
}

/**
    End of CheckCode.
**/

static boolean
CheckStartCode( c )
    PTCmdParse c;

/*
    Similar to CheckCode, but handles the start message specially.
    Basically, we don't exit on failures, but rather return.  This
    allows MXConnect to try a different server.

    c -- Command parse.
*/

{
    char ReadBuff[ 4096 ];
    int  len;

    len = NetRead( c, ReadBuff, sizeof ReadBuff );
    if (len == -1) return( FALSE );
    Stdl( "=>%s\n", ReadBuff );
    if (len < 4 ||
	(ReadBuff[ 3 ] != ' ' && ReadBuff[ 3 ] != '-' ) ||
	ReadBuff[ 0 ] < '1'  ||
	ReadBuff[ 0 ] > '5') {
	Stderrp( "previous message not a valid reply code.\n" );
	Stdl( "**previous message not a valid reply code.\n" );
	return( FALSE );
    } else if (ReadBuff[ 0 ] == '1' ||
	       ReadBuff[ 0 ] == '2' ||
	       ReadBuff[ 0 ] == '3') {
	return( TRUE );
    } else if (ReadBuff[ 0 ] == '4' ||
	       ReadBuff[ 0 ] == '5') {
	Stdl( "**previous message signifies an error.\n" );
	Stderrp( "%s\n", ReadBuff );
	Stderrp( "previous message signifies an error.\n" );
	return( FALSE );
    } else {
	Stderrp( "previous message not a valid reply code.\n" );
	Stdl( "previous message not a valid reply code.\n" );
	return( FALSE );
    }
}

/**
    End of CheckStartCode.
**/

static void
NetWrite( c, p, len, Flush )
    PTCmdParse c;
    char * p;
    int len;
    boolean Flush;

/*
    Writes data to the network.  If EBCDIC compiler, translates to
    ASCII, then writes.  Needs space to add in the CR,LF at the end
    of the line.  If flush is TRUE, does write, otherwise, may
    buffer.
*/

{
    int alen = len + 2;		/* Actual count left to send */

    static char WriteBuff[ 8192 ];	/* Write Buffer */
    static int WriteBuffLen = 0;	/* Current contents */

    EBC2ASCII( p, len );	/* Convert, if needed */
    p[ len ] = ASCII_CR;	/* Tack on CRLF */
    p[ len + 1 ] = ASCII_LF;
    p[ len + 2 ] = '\0';

/*
    If Flushing, and nothing in buffer, then just write
	from input buffer and save a copy.
    If Flushing, and something in buffer, and new data also
	fits, then copy input and save a write.
    If Flushing or data doesn't fit in buffer ever, then
	write buffer if there is something, followed by data.
	(no reason to pack WriteBuff, it won't save anything,
	 see above)
    else
	If New data doesn't fit into buffer,
	    Fill Buffer and write, moving data ptrs, len accordingly.
	Copy new data into buffer.
    end
*/

    if (Flush && WriteBuffLen == 0) {	/* Common case, simple cmd */
	NetWrite2( c, p, alen );
    } else if (Flush && ((WriteBuffLen + alen) < sizeof WriteBuff)) {
	memcpy( WriteBuff + WriteBuffLen, p, alen );
	NetWrite2( c, WriteBuff, WriteBuffLen + alen );
	WriteBuffLen = 0;
    } else if (Flush || alen > sizeof WriteBuff) {
	if (WriteBuffLen > 0) {
	    NetWrite2( c, WriteBuff, WriteBuffLen );
	    WriteBuffLen = 0;
	}
	NetWrite2( c, p, alen );
    } else {
	if (WriteBuffLen + alen > sizeof WriteBuff) {
	    int clen;

	    clen = sizeof WriteBuff - WriteBuffLen;
	    memcpy( WriteBuff + WriteBuffLen, p, clen );
	    p    += clen;
	    alen -= clen;

	    NetWrite2( c, WriteBuff, sizeof WriteBuff );
	    WriteBuffLen = 0;
	}
	memcpy( WriteBuff + WriteBuffLen, p, alen );
	WriteBuffLen += alen;
    }
}

/**
    End of NetWrite.
**/

static void
NetWrite2( c, p, len )
    PTCmdParse c;
    char * p;
    int len;

/*
    Non-buffered write.  Should only be called by NetWrite.
*/

{
    int plen = 0;
    int ZeroCnt = 0;	/* Times write returned, writing 0 bytes */

    while( len > 0 ) {
	int wlen;

	if (!Select( c->s, NetworkWrite )) {
	    Stdl( "**previous error causes termination.\n" );
	    Stderrp( "Previous error causes termination.\n" );
	    TerminateClean();
	    exit( 1 );
	}
	wlen = write( c->s, p + plen, len );
	if (wlen < 0) {
	    Stdl( "error writing to network: %s\n", strerror( errno ) );
	    Stderrp( "error writing to network: %s\n", strerror( errno ) );
	    Stdl( "**previous error causes termination.\n" );
	    Stderrp( "Previous error causes termination.\n" );
	    exit( 1 );
	} else if (wlen == 0) {
	    ZeroCnt++;
	    if (ZeroCnt >= ZERO_WRITE_MAX) {
		Stderrp( "error writing to network.  %d calls to 'write' \
all returned 0 bytes written.\n", ZeroCnt );
		Stdl( "**error writing to network.  %d calls to 'write' \
all returned 0 bytes written.\n", ZeroCnt );
		Stdl( "**previous error causes termination.\n" );
		Stderrp( "Previous error causes termination.\n" );
		exit( 1 );
	    } else {
		sleep( ZERO_WRITE_DELAY );
	    }
	} else {	/* Partial or full write */
	    ZeroCnt = 0;
	    plen += wlen;
	    len  -= wlen;
	}
    }
}

/**
    End of NetWrite2.
**/

static void
NetRecWrite( c, p, len, List )
    PTCmdParse c;
    char * p;
    int len;
    PPTobjlistHeader List;

/*
    Saves what we are writing to the conversation list and calls
    NetWrite.  Only used for writing commands and the like.  Output
    is not buffered.
*/

{
    char CnvBuff[ 256 ];

    strcpy( CnvBuff, "<=" );
    catn( CnvBuff, p, sizeof CnvBuff - 1 );
    if (*List == NULL) {
	*List = PoolListCreate();
    }
    ListAppend( *List, CnvBuff, strlen( CnvBuff ) + 1 );

    NetWrite( c, p, len, TRUE );
}

/**
    End of NetRecWrite.
**/

static void
DoReset( c, CnvList )
    PTCmdParse c;
    PPTobjlistHeader CnvList;

/*
    Send an RSET command.  Can't send the constant because on
    EBCDIC systems, we translate this string to ASCII.
*/

{
    char rset[ 5 ];

    strcpy( rset, "RSET" );
    NetRecWrite( c, rset, 4, CnvList );
    CheckCode( c, NULL, NULL, FALSE );
}

/**
    End of DoReset.
**/

static void
MXConnect( c )
    PTCmdParse c;

/*
    Get a list of host names, possibly including host names given
    by MX records for the given domain name.  Then try to connect
    to them, in order, until one works.  GetMX returned the list of
    hosts in the proper order without the preference value
    attached.  Note "until works".  This routine will not return
    until we have a connection, or else it calls exit in case of a
    non-recoverable error.  Note that if c->mx is FALSE, then we
    don't actually do an MX record lookup, we just move the
    hostname to the list and try for that host.
*/

{
    PTobjlistHeader MXList = NULL;
    PTobjlistContext Context = NULL;
    boolean PrintSuccess = FALSE;

    LOOP {
	char * hostname;

	if (MXList == NULL) {
	    if (c->mx) {
		Stdl( "++obtaining MX records for host '%s'.\n", c->host );
	    }

	    MXList = GetMX( c->host, c->mx );
#if defined(DUMMY_HOST)
	    ListStrInsert( MXList, DUMMY_HOST );
#endif
	    if (c->mx) {
		Stdl(
		"++%d MX records (or using original host name) for '%s'.\n",
		ListCnt( MXList ), c->host );
	    } else {
		Stdl( "++MX record lookup skipped (--nomx), using: '%s'.\n",
		    c->host );
	    }
	    Context = NULL;
	}

	ListStrNext( MXList, &Context, &hostname );
	if (Context == NULL) {
	    if (c->mx) {
		Stdl( 
	"++tried all MX records, sleeping %d secs before retrying.\n",
		    c->delay );
	    } else {
		Stdl( "++sleeping %d secs before retrying.\n",
		    c->delay );
	    }
	    FlushLogFile();
	    MXList = ListDelete( MXList );
	    sleep( c->delay );
	} else {
	    Stdl( "++trying to connect to '%s', port %d.\n", hostname,
		  c->port );
	    FlushLogFile();
	    if (NetConnect( c, hostname ) && CheckStartCode( c )) {
		if (PrintSuccess) {
		    Stderrp( "After failures, finally connected to '%s'.\n",
			     hostname );
		}
		MXList = ListDelete( MXList );		/* SUCCESS */
		break;
	    } else {
		Stderrp( "Failed to connect to '%s'.\n", hostname );
		NetClose( c );
		PrintSuccess = TRUE;
	    }
	}
    }
}

/**
    End of MXConnect.
**/

static void
DumpMessage( c, Reason, HdrList )
    PTCmdParse c;
    const char * Reason;
    PTobjlistHeader HdrList;

/*
    Outputs an error message to the log file, and makes sure that
    we have seen the end of the message.  We are assuming that the
    input file is BSMTP, that we have a message, and that it does
    end with a '.'.

    This should only be called in very special cases where we
    suspect a completely bogus message has entered the system.
    Perhaps by someone doing their own typing on port 25.
*/

{
    char * p;
    char InBuff[ 4096 ];
    int  len;
    boolean AlreadyRead = FALSE;
    PTobjlistContext Context = NULL;

    Stdl( "**Unable to send the message, skipping: %s\n", Reason );
    if (HdrList != NULL) {
	int LineCnt = 0;

	Stdl( "**Up to first 100 lines of header are:\n" );
	Context = NULL;
	LOOP {
	    ListNext( HdrList, &Context, (void *) &p, &len );
	    len--;
	    if (Context == NULL) break;
	    Stdl( "**%3.3d: (%.3d) %-.80s\n", ++LineCnt, len, p );
	    if (LineCnt == 100) break;
	}
    }
    FlushLogFile();

    if (HdrList != NULL) {
	Context = NULL;
	ListLast( HdrList, &Context, (void *) &p, &len );
	len--;
	if (len == 1 && *p == '.') {
	    AlreadyRead = TRUE;
	}
    }

    if (!AlreadyRead) {
	while( GetStdinLine( c, InBuff, sizeof InBuff, &len ) ) {
	    if (len == 1 && InBuff[ 0 ] == '.') break;
	}
    }
}

/**
    End of DumpMessage.
**/

static void
HandleFailure( c, HdrList, CnvList, Disp )
    PTCmdParse c;
    PPTobjlistHeader HdrList;
    PPTobjlistHeader CnvList;
    DispCode Disp;

/*
    Turns the failure code into a text string and calls
    DumpMessage.
*/

{
    switch (Disp) {
        case DispLooping:
	    DumpMessage( c, "Too many hops", *HdrList );
	    break;
	case DispTooLong:
	    DumpMessage( c, "Bad or too long headers", *HdrList );
	    break;
	case DispMangled:
	    DumpMessage( c, "Seriously wrong BSMTP envl.  Truncated?",
		*HdrList );
	    break;
	default:
	    Stderrp( "Failed to handle disposition=%d.\n", Disp );
	    exit( 1 );
    }

    *HdrList = ListDelete( *HdrList );
    *CnvList = ListDelete( *CnvList );
}

/**
    End of HandleFailure.
**/

static boolean
GetStdinLine( c, InBuff, maxlen, len )
    PTCmdParse c;
    char * InBuff;
    int maxlen;
    int * len;

/*
    Reads from stdin.  Returns a '\0' terminated line.  On MVS, 0
    length lines don't exist, so we truncate a line with a single
    space to be zero length.  If c->trimblanks is TRUE, then
    remove all trailing blanks.
*/

{
    int tlen;

#ifdef I370
    tlen = afread( InBuff, 1, maxlen - 1, mvsstdin );
    if (feof( mvsstdin )) {
	return( FALSE );
    } else if (ferror( mvsstdin )) {
	Stderrp( "error reading input: %s\n", strerror( errno ) );
	exit( 16 );
    } else if (tlen == 1 && InBuff[ 0 ] == ' ') {
	tlen = 0;
    }
#else
    fgets( InBuff, maxlen, stdin );
    if (feof( stdin )) {
	return( FALSE );
    } else if (ferror( stdin )) {
	Stderrp( "error reading input: %s\n", strerror( errno ) );
	exit( 1 );
    } else {
	tlen = strlen( InBuff ) - 1;	/* Drop '\n' */
    }
#endif

    if (c->trimblanks) {
	while( tlen > 0 && InBuff[ tlen - 1 ] == ' ') tlen--;
    }
    InBuff[ tlen ] = '\0';
    *len = tlen;
    return( TRUE );
}

/**
    End of GetStdinLine.
**/

static boolean
GetLine( c, HdrList, Context, DoneHeaders, InBuff, maxlen, len )
    PTCmdParse c;
    PPTobjlistHeader HdrList;
    PPTobjlistContext Context;
    boolean * DoneHeaders;
    char * InBuff;
    int maxlen;
    int * len;

/*
    Reads a line from the header list, if it exists, or reads
    from stdin.  Data returned is '\0' terminated.
*/

{
    if (HdrList != NULL && *HdrList != NULL && !*DoneHeaders) {
	void * p;

	ListNext( *HdrList, Context, &p, len );
	if (*Context == NULL) {
	    *DoneHeaders = TRUE;
			/* Will now read a line from stdin */
	} else {
	    memcpy( InBuff, p, *len );
	    (*len)--;
	    return( TRUE );
	}
    }
    return( GetStdinLine( c, InBuff, maxlen, len ) );
}

/**
    End of GetLine.
**/

static void
NetReadSendWait( c )
    PTCmdParse c;

/*
    This routine is used to read a line of data from stdin.  The
    command is checked, and if valid, sent.  We usually then wait
    for a response, but in the case of sending data, we keep
    sending.

    We do need to basically check the message.  For instance, we
    want to make sure the message isn't looping and doesn't have a
    giant or invalid rfc822 header.  The only way to do this is to
    pre-read the input, save it in a list and if it's OK, send
    it.  So, we read from stdin unless there is a list, in which
    case we read the list.

    We start building the list when a mail transaction starts.  A
    mail transaction starts when the [B]SMTP command MAIL FROM:  is
    found.  All lines up until the end of the rfc822 header are
    added to the list.  PreFetch handles this.
*/

{
    char InBuff[ 4096 ];
    int len;
    boolean DoData = FALSE;
    int DataCnt = 0;
    int TotalDataCnt = 0;
    int MsgCnt = 0;

    PTobjlistHeader HdrList = NULL;
    PTobjlistHeader CnvList = NULL;	/* SMTP conv. list */
    PTobjlistContext Context = NULL;	/* For reading 'List' */
    boolean DoneHeaders = FALSE;

    LOOP {
/*
    Reads from HdrList if not empty or stdin.
*/

	if (!GetLine( c, &HdrList, &Context, &DoneHeaders, 
		      InBuff, sizeof InBuff - 2, &len )) {
	    break;
	}

	if (DoData) {	/* Sending data - no response, except when '.' */
	    if (len == 1 && InBuff[ 0 ] == '.') {	/* End of data */
		Stdl( "**wrote %d bytes of data.\n", DataCnt );
		TotalDataCnt += DataCnt;
		NetRecWrite( c, InBuff, len, &CnvList );
		if (!CheckCode( c, &HdrList, &CnvList, FALSE )) {
		    DoData = FALSE;
		    continue;
		}
		TimeStamp();
		FlushLogFile();
		DoData = FALSE;
		MsgCnt++;
	    } else {				/* Sending data */
		NetWrite( c, InBuff, len, FALSE );	/* Buffered */
		DataCnt += len;
	    }
	} else if (len >= 5 && memcmp( InBuff, "TICK ", 5 ) == 0) {

/*
    Ignores old TICK <...> lines.  These are output by some older
    mail clients on OS/390.
*/

	    continue;
	} else if (len >= 10 && memcmp( InBuff, "MAIL FROM:", 10 ) == 0) {
	    DispCode Disp;

/*  Fetches the headers, makes HdrList. Does basic checks on header.  */
/*  Changes MAIL FROM to XMAIL FROM so we don't loop. */

	    Disp = PreFetch( c, InBuff, len, &HdrList, &CnvList );
	    Context = NULL;
	    DoneHeaders = FALSE;
	    if (Disp != DispMail) {
		HandleFailure( c, &HdrList, &CnvList, Disp );
		continue;
	    }
	} else if (len >= 11 && memcmp( InBuff, "XMAIL FROM:", 11 ) == 0) {
	    Stdl( "<=%s\n", InBuff+1 );
	    NetRecWrite( c, InBuff+1, len-1, &CnvList );
	    if (!CheckCode( c, &HdrList, &CnvList, TRUE )) {
	  	DoReset( c, &CnvList );
		continue;
	    }
	} else if (len >= 8 && memcmp( InBuff, "RCPT TO:", 8 ) == 0) {
	    Stdl( "<=%s\n", InBuff );
	    NetRecWrite( c, InBuff, len, &CnvList );
	    if (!CheckCode( c, &HdrList, &CnvList, TRUE )) {
	  	DoReset( c, &CnvList );
		continue;
	    }
	} else if (len == 4 && memcmp( InBuff, "DATA", 4 ) == 0) {
	    Stdl( "<=%s\n", InBuff );
	    NetRecWrite( c, InBuff, len, &CnvList );
	    if (!CheckCode( c, &HdrList, &CnvList, TRUE )) {
		DoReset( c, &CnvList );
		continue;
	    }
	    DataCnt = 0;
	    DoData  = TRUE;
	    AddReceived( c, NULL );	/* Add optional Received: */
	} else if (len == 4 && memcmp( InBuff, "QUIT", 4 ) == 0) {
	    Stdl( "<=%s\n", InBuff );
	    NetWrite( c, InBuff, len, TRUE );
	    CheckCode( c, NULL, NULL, FALSE );
	    Stdl( "++%d total bytes of data transfered this session.\n",
		TotalDataCnt );
	    Stdl( "++%d message%stransfered this session.\n",
		    MsgCnt, (MsgCnt > 1 || MsgCnt == 0) ? "s " : " " );
	    if (ReturnCnt > 0) {
		Stdl( "++%d message%sreturned to the sender this session.\n",
		    ReturnCnt, (ReturnCnt > 1) ? "s " : " " );
	    }
	    if (RetryCnt > 0) {
		Stdl( "++%d message%sdue to be retried from this session.\n",
		    RetryCnt, (RetryCnt > 1) ? "s " : " " );
	    }
	    if (FailCnt > 0) {
		Stdl( "++%d message%sfailed from this session.\n",
		    FailCnt, (FailCnt > 1) ? "s " : " " );
	    }
	    if (SkipCnt > 0) {
		Stdl( "++%d message%sreturned to the sender this session.\n",
		    SkipCnt, (SkipCnt > 1) ? "s " : " " );
	    }
	    break;
        } else {
	    Stdl( "<=%s\n", InBuff );
	    NetRecWrite( c, InBuff, len, &CnvList );
	    if (!CheckCode( c, &HdrList, &CnvList, TRUE )) {
		continue;
	    }
        }
    }
}

/**
    End of NetReadSendWait.
**/

static void
TerminateClean( void )

/*
    Closes all files and cleans up.  Can and should be called when
    SIGABRT or SIGALRM are detected, as well as normal shutdown.
*/

{ 
    NetClose( &c );
    CleanExit = TRUE;
    TimeStamp();
    if (c.logfile != NULL) CloseLogFile();
    if (c.returnfile != NULL) CloseReturnFile();
    if (c.retryfile != NULL) CloseRetryFile();
    if (c.failfile != NULL) CloseFailFile();
    FreeArgs( &c );
}

/**
    End of TerminateClean.
**/

int
main( argc, argv )
    int argc;
    char * argv[];
 
/*
    Main.  Process the args...
*/
 
{
    int   LastArg;	    /* Index of last argument */

    SavePgmName( argv[ 0 ] );

    atexit( MyAtExit );

    InitArgs( &c, argc, (void *) argv );
    if (!args( argc, argv, &c, TRUE, &LastArg )) {
	return( 1 );
    }

    FinalArgs( &c );
    OpenInput( argc, argv, LastArg );
    if (c.logfile != NULL) OpenLogFile( c.logfile );
    if (c.returnfile != NULL) OpenReturnFile( c.returnfile );
    if (c.retryfile != NULL) OpenRetryFile( c.retryfile );
    if (c.failfile != NULL) OpenFailFile( c.failfile );
    Stdl( "++start of session.\n" );

    TimeStamp();

    MXConnect( &c );		/* Connect using MX record hostnames */
    NetReadSendWait( &c );	/* Start processing */

    TerminateClean();
    return( 0 );
}
 
/**
    End of main.c
**/
