/**
    List - General list routines module.

    NOTE: visit problem of allocator returning NULL.  Easy in
    ListCreate.  ListInsert, for instance, would need to return a
    value of the object added.  Perhaps.  Or maybe a
    success/failure code.

    $Id: list.c,v 1.32 2005/04/12 23:17:18 mike Exp $

    Copyright (C) 1995-1999 University of Delaware.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    List management routines.

    An object to be placed in a list must always start with a null
    terminated string if any routines that use string comparisons
    are going to be used.  Other fields can follow.  Objects that
    are inserted have dynamic storage allocated for them and are
    copied.  The caller need not do the dynamic allocation.

    List headers consists of some management information and a
    dummy node.  The next and back pointers always point to this
    dummy node when the list is initialized.  This makes adding and
    deleting items much easier than using NULL pointers since there
    are no special cases to take into account.  Thanks to whoever
    wrote the 'list.h' doubly linked list implementation in the
    Linux kernel for making this apparent.  These routines used to
    use a head/tail, with NULLs for the list header, and the code was
    considerably more complex.

    To determine when the list has been processed fully, just
    compare your current list object pointer to &List->objlist.
    If the addresses are the same, you are back to the
    beginning/end of the list.

    $Id: list.c,v 1.32 2005/04/12 23:17:18 mike Exp $

    Changes:

    6/25/99

    Added as seperate module in CVS.  Log ended.  See CVS.
**/

/* #define TRACING 1 */
/* #define LISTDEBUG 1 */
 
#if defined(HAVE_CONFIG_H)
#   include "genincl.h"
#else
#   include <stdlib.h>
#   include <string.h>
#   include <stdio.h>
#   ifdef TRACING
#       include "trace.h"
#   endif
#endif

#include <assert.h>
#include <limits.h>
#include <time.h>

#if !defined(TRUE)
#define TRUE (1 == 1)
#endif

#if !defined(FALSE)
#define FALSE (1 == 0)
#endif

#include "list.h"

typedef struct objlist Tobjlist;
typedef Tobjlist * PTobjlist;

/*
    The swap routines depend on the order of next and prev,
    and also expect these to have to same alignment as an array
    of PTobjlist.
*/

struct objlist {
    PTobjlist next;
    PTobjlist prev;
    void * object;
    int len;
};

typedef int (*PTComparator)( const void *, size_t,
			     const void *, size_t, void * );
typedef int (*PTComparatorShort)( const void *, const void * );

/*
    The list header.  The next and prev pointers, objlist->next,
    oblist->prev are initialized to point back to this object.
    Note that we depend on objlist being at the beginning of
    objlistHeader.  This way, the list header and a normal list
    node, which is of type Tobjlist, can be considered the same
    when manipulating the next and prev pointers.

    cnt - is a count of objects in the list - not counting the
          header itself.
    last - pointer to the last object we found or inserted.
    AllocatorParam - general parameter passed to the allocator rtn.
    Allocator, Deallocator - Routines for allocating and deallocating
          memory.
    Comparator - Routine for doing compares
    ComparatorShort - Routine for doing compares.  Uses a shorter argument
    		      list.  Somewhat faster on QSort, which is the only
		      place it is currently used.  I suggest you supply
		      both a long and short comparator, if you are
		      going to use the short form in some cases.
    ComparatorInfo - general parameter passed to the comparator rtn.
*/

struct objlistHeader {
    Tobjlist objlist;
    unsigned int cnt;
    PTobjlist last;
    void * AllocatorParam;
    void * (*Allocator)( int len, enum ListFlags, void * p );
    int    (*Deallocator)( void * o, int len, enum ListFlags, void * p );
    PTComparator Comparator;
    PTComparatorShort ComparatorShort;
    void * ComparatorInfo;
};

/*
    The following structure is used for the info field when
    doing sorted list management.
*/

#if defined(LIST_SORTED_FEATURES)
struct SortInfo {
    PTComparator Comparator;
    void * ComparatorInfo;
};
typedef struct SortInfo TSortInfo;
typedef TSortInfo * PTSortInfo;
#endif

/*
    Dummy structure to prevent compiler warnings.  PTobjlistContext
    is defined as a struct objlistContext *, but never actually
    used as such.  Any contexts are cast to PTobjlist before being
    used.  We'll set the structure size to be Tobjlist in case we
    want to use pointer arithmetic or something.
*/

struct objlistContext {
    Tobjlist objlist;
};

/*
    Debugging code...
*/

#ifdef LISTDEBUG
#define HEAD_CHECK( ptr, rtnname )	\
    if (ptr == NULL) {			\
	fprintf( stderr, "List header is null in %s.\n", #rtnname ); \
	exit( LISTDEBUG_ERROR );	\
    }
#else
#define HEAD_CHECK( ptr, rtnname )
#endif

/*
    Some compilers are able to use the old style function
    headers as function prototypes, others aren't.  So,
    we define the functions here even though they are often
    not used until after their definition.
*/

#if defined(__STDC__)
static void * MALLOC( int len, enum ListFlags, void * p );
static int FREE( void * O, int len, enum ListFlags, void * p );
static void Insert( PTobjlist After, PTobjlist p );
static void * AllocAndCopyObject( PTobjlistHeader H, const void * O, int len );
static int Cmemcmp( const void * p1, size_t l1,
    const void * p2, size_t l2, void * info );
static int CSorting( const void * p1, size_t l1,
    const void * p2, size_t l2, void * info );
static void InternalListInsert( PTobjlistHeader H, PTobjlist After,
    const void * O, int len );
static PTobjlist InternalFind( PTobjlistHeader H, const void * O, int len );
static PTobjlist InternalStrFind( PTobjlistHeader H, const void * O, int len );
static void swap( PTobjlist * pe1, PTobjlist * pe2 );
static void swap3a( PTobjlist * pe1, PTobjlist * pe2, PTobjlist * e3 );
static void swap3b( PTobjlist * pe1, PTobjlist * pe2, PTobjlist * e3 );
static void QSortShort( PTobjlistHeader Hdr );
static void QSort( PTobjlistHeader Hdr );
#else
static void * MALLOC();
static int FREE();
static void Insert();
static void * AllocAndCopyObject();
static int Cmemcmp();
static int CSorting();
static void InternalListInsert();
static PTobjlist InternalFind();
static PTobjlist InternalStrFind();
static void QSortShort();
static void QSort();
#endif

/**
    End of Globals.
**/

static void *
MALLOC( len, lf, p )
    int len;
    enum ListFlags lf;
    void * p;

/*
    Standard memory allocation with error check and report.
    Program exits if no storage.
*/

{
    void * Ptr = malloc( len );

    if (Ptr == NULL) {
	fprintf( stderr,
"Unable to allocate %d bytes of storage for a list related object.\n",
			 len );
	exit( 1 );
	return( NULL );
    } else {
	return( Ptr );
    }
}

/**
    End of MALLOC.
**/

static int
FREE( o, len, lf, p )
    void * o;
    int len;
    enum ListFlags lf;
    void * p;

/* Standard memory deallocation.  */

{ 
    if (lf == ListMemList) {
        return( FALSE );
    } else {
	free( o );
	return( TRUE );
    }
}

/**
    End of FREE.
**/

static inline void
Insert( After, p )
    PTobjlist After;
    PTobjlist p;

/**
    Insert item into list, making list entry 'After' be after the
    new object.  WARNING...read that carefully.  It is counter-
    intuitive!!!
**/

{
        p->next	  = After;		/* New entry's next ptr */
        p->prev   = After->prev;	/* New entry's prev ptr */

        After->prev->next = p;	/* Make old prev entry next ptr to new */
        After->prev	  = p;	/* Backlink for after entry */
}

/**
    End of Insert.
**/

static void *
AllocAndCopyObject( H, O, len )
    PTobjlistHeader H;
    const void * O;
    int len;
{
    void * Ptr = (H->Allocator)( len, ListMemObject, H->AllocatorParam );
    memcpy( Ptr, O, len );
    return( Ptr );
}

/**
    End of Allocators.
**/

/*
    Start of comparators.  Cmemcmp acts similar to memcmp.  If the
    lengths are not the same, then shorter of the two lengths is
    used.  Cstrcmp acts similar to strcmp - neither length is
    used.
*/

static int
Cmemcmp( p1, l1, p2, l2, info )
    const void * p1;
    size_t l1;
    const void * p2;
    size_t l2;
    void * info;

{
    unsigned char * c1 = (unsigned char *) p1;
    unsigned char * c2 = (unsigned char *) p2;
    size_t len;
    int cmpc;

/*
    The extra tests shouldn't matter that much because the first
    test catches longer keys off the bat.  The extra tests are
    useful if you happen to be sorting a lot of short keys.
*/

    len = (l1 < l2) ? l1 : l2;

    if (len >=2) {
	if (c1[0] > c2[0])
	    return( 1 );
	else if (c1[0] < c2[0])
	    return( -1 );
	else if (c1[1] > c2[1])
	    return( 1 );
	else if (c1[1] < c2[1])
	    return( -1 );
    } else if (l1 == 0) {
	return( (l2 > 0) ? 1 : 0 );
    } else if (l2 == 0) {
	return( (l1 > 0) ? -1 : 0 );
    } else {		/* l1!=0, l2!=0, l1<2, l2<2: l1 == l2 == 1 */
	return( (c1[0] < c2[0]) ? -1 : (c1[0] == c2[0]) ? 0 : 1 );
    }

    cmpc = memcmp( p1, p2, len );
    if (cmpc != 0) {
	return( cmpc );
    } else {
	return( (l1 < l2) ? -1 : (l1 == l2) ? 0 : 1 );
    }
}

#if defined(LIST_SORTED_FEATURES)
static int
CSorting( p1, l1, p2, l2, info )
    const void * p1;
    size_t l1;
    const void * p2;
    size_t l2;
    void * info;

/*
    Special version used for sorted lists.  Assumes that the list
    will be sorted ascending, and that the list object is passed
    in p1.  Causes a match if the objects are the same or if the
    list object is greater than the object we are dealing with.
    The associated list is passed in Info.
*/

{
    int cmpc;
    PTSortInfo S = (PTSortInfo) info;

    cmpc = (S->Comparator)( p1, l1, p2, l2, S->ComparatorInfo );

    return( (cmpc >= 0) ? 0 : cmpc );
}
#endif

/* */

PTobjlistHeader
ListCreateWithAllocator( Allocator, Deallocator, AllocatorParam )
    void * Allocator( int len, enum ListFlags, void * p );
    int    Deallocator( void * o, int len, enum ListFlags, void * p );
    void * AllocatorParam;

/*
    Creates a list with a user specified allocator.
*/

{
    PTobjlistHeader H = (Allocator)( sizeof( TobjlistHeader ),
			    ListMemHeader, AllocatorParam );
    H->objlist.next = &H->objlist;
    H->objlist.prev = &H->objlist;
    H->objlist.object = (char *) "<headerobj>";
    H->objlist.len    = 0;
    H->cnt  = 0;
    H->last = NULL;
    H->Allocator = Allocator;
    H->Deallocator = Deallocator;
    H->AllocatorParam = AllocatorParam;
    H->Comparator = Cmemcmp;
    H->ComparatorShort = NULL;
    H->ComparatorInfo = NULL;
    return( H );
}

PTobjlistHeader
ListCreate( )
{ return( ListCreateWithAllocator( MALLOC, FREE, NULL ) ); }

/**
    End of ListCreate.
**/

PTListComparator
ListGetComparator( H )
    PTobjlistHeader H;
{
    HEAD_CHECK( H, ListGetComparator );
    return( H->Comparator );
}

PTListComparatorShort
ListGetComparatorShort( H )
    PTobjlistHeader H;
{
    HEAD_CHECK( H, ListGetComparatorShort );
    return( H->ComparatorShort );
}

PTListComparator
ListSetComparator( H, C )
    PTobjlistHeader H;
    PTListComparator C;
{
    PTListComparator tmp;

    HEAD_CHECK( H, ListSetComparator );
    tmp = H->Comparator;
    H->Comparator = C;
    return( tmp );
}

PTListComparatorShort
ListSetComparatorShort( H, C )
    PTobjlistHeader H;
    PTListComparatorShort C;
{
    PTListComparatorShort tmp;

    HEAD_CHECK( H, ListSetComparatorShort );
    tmp = H->ComparatorShort;
    H->ComparatorShort = C;
    return( tmp );
}

void *
ListGetComparatorInfo( H )
    PTobjlistHeader H;
{
    HEAD_CHECK( H, ListGetComparatorInfo );
    return( H->ComparatorInfo );
}

void *
ListSetComparatorInfo( H, I )
    PTobjlistHeader H;
    void * I;
{
    void * tmp;

    HEAD_CHECK( H, ListSetComparatorInfo );
    tmp = H->ComparatorInfo;
    H->ComparatorInfo = I;
    return( tmp );
}

/**
    End of ListComparator related routines.
**/


PTobjlistHeader
ListDelete( H )
    PTobjlistHeader H;

/*
    Deletes an entire list.  The return value should be assigned to
    the location that held the ptr to the list.  The return value
    is always NULL.
*/

{
    PTobjlist p;
#ifdef LISTDEBUG
    int cnt;

    HEAD_CHECK( H, ListDelete );
    cnt = H->cnt;
#endif

/*
    If the deallocator is not present, or if it returns TRUE
    for ListMemList, then assume the list will be/was deleted
    externally/in one call.
*/

    if (H->Deallocator == NULL ||
        (H->Deallocator)( H, sizeof( TobjlistHeader ), ListMemList,
		H->AllocatorParam )) {
	return( NULL );
    }

    p = H->objlist.next;

    while( p != &H->objlist ) {
	PTobjlist next;

#ifdef LISTDEBUG
	cnt--;
	if (cnt < 0) {
	    fprintf( stderr,
"The list header count does not agree with the pointers.\n" );
	    fprintf( stderr, "Count = %d, tripping object='%s'.\n",
		     H->cnt, 
		     (p->object == NULL) ? "" : (char *) p->object );
	    exit( LISTDEBUG_ERROR );
	}
#endif
	if (p->object != NULL) {
	    (H->Deallocator)( p->object, p->len, ListMemObject,
		H->AllocatorParam );
	}
	next = p->next;
        (H->Deallocator)( p, sizeof( struct objlist ), ListMemNode,
		H->AllocatorParam );
	p = next;
    }

    (H->Deallocator)( H, sizeof( TobjlistHeader ), ListMemHeader,
	H->AllocatorParam );
    return( NULL );
}

/**
    End of ListDelete.
**/

PTobjlistContext
ListGetContext( H )
    PTobjlistHeader H;

/*
    Return the context (last object touched).
*/

{
#ifdef LISTDEBUG
    HEAD_CHECK( H, ListGetContext );
    if (H->last == NULL && H->cnt != 0) {
	fprintf( stderr, "In ListGetContext, cnt=%d, last=NULL.\n", H->cnt );
	exit( LISTDEBUG_ERROR );
    }
#endif
    return( (PTobjlistContext) H->last );
}

/**
    End of ListGetContext.
**/

void
ListGetObject( H, Context, RO, rlen )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    void ** RO;
    int * rlen;

/*
    Return the object associated with the context.
*/

{
    PTobjlist ListObject = (PTobjlist) *Context;

#ifdef LISTDEBUG
    HEAD_CHECK( H, ListGetObject );
    if (*Context == NULL) {
	fprintf( stderr, "List context is null in ListGetObject.\n" );
	exit( LISTDEBUG_ERROR );
    }
#endif
    *RO = ListObject->object;
    if (rlen != NULL) *rlen = ListObject->len;
}

void
ListStrlGetObject( H, Context, RO, rlen )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** RO;
    int * rlen;

{
    ListGetObject( H, Context, (void **) RO, rlen );
    (*rlen)--;
}

void
ListStrGetObject( H, Context, RO )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** RO;

{
    ListGetObject( H, Context, (void **) RO, NULL );
}

void
ListGetObjectN( Context, RO, rlen )
    PPTobjlistContext Context;
    void ** RO;
    int * rlen;

/*
    Return the object associated with the context.
*/

{
    PTobjlist ListObject = (PTobjlist) *Context;

    *RO = ListObject->object;
    if (rlen != NULL) *rlen = ListObject->len;
}

void
ListStrlGetObjectN( Context, RO, rlen )
    PPTobjlistContext Context;
    char ** RO;
    int * rlen;

{
    ListGetObjectN( Context, (void **) RO, rlen );
    (*rlen)--;
}

void
ListStrGetObjectN( Context, RO )
    PPTobjlistContext Context;
    char ** RO;

{
    ListGetObjectN( Context, (void **) RO, NULL );
}

/**
    End of ListGetObject...[N].
**/

static void
InternalListInsert( H, After, O, len )
    PTobjlistHeader H;
    PTobjlist After;
    const void * O;
    int len;

/*
    Insert item into list, making list entry 'After' be after the
    new object.  Note that since the list header servers as dummy
    node, we don't have to account for it specially.  To insert at
    the head of the list, pass H->objlist.next for After.  To
    insert at the tail, pass &H->objlist for After.  To insert in
    the middle of the list, just pass the object we want to insert
    before.  Note that if we searching or something, and at list
    end, which is a pointer to &H->objlist, we just insert there,
    and the object ends up at the end.
*/

{
    PTobjlist new;

/*
    The following works because we initialize the list so
    that the header points to itself.  So, we don't have to
    take into account NULL ptrs - there aren't any.
*/

    new	    	= (PTobjlist) (H->Allocator)( sizeof( Tobjlist ), ListMemNode,
					      H->AllocatorParam);
    new->object = AllocAndCopyObject( H, O, len );
    new->len    = len;

    Insert( After, new );

    H->last= new;	/* Ptr to last used entry */
    H->cnt++;		/* And count it */
}

void
ListInsert( H, O, len )
    PTobjlistHeader H;
    const void * O;
    int len;
{
    InternalListInsert( H, H->objlist.next, O, len );	/* Ins at head */
}

void
ListStrlInsert( H, O, len )
    PTobjlistHeader H;
    const char * O;
    int len;
{
    ListInsert( H, (void *) O, len + 1 );
}

void
ListStrInsert( H, O )
    PTobjlistHeader H;
    const char * O;
{
    ListInsert( H, (void *) O, strlen( O ) + 1 );
}

/**
    End of ListInsert.
**/

void
ListAppend( H, O, len )
    PTobjlistHeader H;
    const void * O;
    int len;
{
    InternalListInsert( H, &H->objlist, O, len );	/* Ins at end */
}

void
ListStrlAppend( H, O, len )
    PTobjlistHeader H;
    const char * O;
    int len;
{
    ListAppend( H, (void *) O, len + 1 );
}

void
ListStrAppend( H, O )
    PTobjlistHeader H;
    const char * O;
{
    ListAppend( H, (void *) O, strlen( O ) + 1 );
}

/**
    End of ListAppend.
**/

static PTobjlist
InternalFind( H, O, len )
    PTobjlistHeader H;
    const void * O;
    int len;

/*
    This routine will locate the value 'O' by doing a compare on
    the objects in the list.  Returns a pointer to the list object
    or NULL.  Special purposes Comparators can make this routine do
    interesting things.  See CSorted, for instance.
*/

{
    PTobjlist p;

#ifdef LISTDEBUG
    int Cnt;

    Cnt = H->cnt;
#endif

    p = H->objlist.next;

    while( p != &H->objlist ) {
#ifdef LISTDEBUG
	Cnt--;
	if (Cnt < 0) {
	    fprintf( stderr, "Error in list ptrs versus list count \
found while running ListFind.\n" );
	    fprintf( stderr, "There are only supposed to be %d items\
, but there are more.\n", H->cnt );
	    fprintf( stderr, "Error locating '%s'.\n", (char *) O );
	    exit( LISTDEBUG_ERROR );
	}
#endif

	if ((H->Comparator)( p->object, p->len,
			     O, len, H->ComparatorInfo ) == 0) {
	    H->last = p;
	    return( p );
	} else {
	    p = p->next;
	}
    }

    return( NULL );
}

/** **/

static PTobjlist
InternalStrFind( H, O, len )
    PTobjlistHeader H;
    const void * O;
    int len;

/*
    Similar to InternalFind, but the object length used in the
    comparison is the string length of the string that is assumed
    to exist at the start of the object.
*/

{
    PTobjlist p;

#ifdef LISTDEBUG
    int Cnt;

    Cnt = H->cnt;
#endif

    p = H->objlist.next;

    while( p != &H->objlist ) {
#ifdef LISTDEBUG
	Cnt--;
	if (Cnt < 0) {
	    fprintf( stderr, "Error in list ptrs versus list count \
found while running ListFind.\n" );
	    fprintf( stderr, "There are only supposed to be %d items\
, but there are more.\n", H->cnt );
	    fprintf( stderr, "Error locating '%s'.\n", (char *) O );
	    exit( LISTDEBUG_ERROR );
	}
#endif

	if ((H->Comparator)( p->object, strlen( p->object ) + 1,
			     O, len, H->ComparatorInfo ) == 0) {
	    H->last = p;
	    return( p );
	} else {
	    p = p->next;
	}
    }

    return( NULL );
}

/** **/


#if defined(LIST_SORTED_FEATURES)
void
ListInsertSorted( H, O, len )
    PTobjlistHeader H;
    const void * O;
    int len;

/*
    Insert into the list in a sorted fashion.  Assumes that 'O'
    points to a null terminated string, but there can be a total of
    len bytes, where len > strlen( O ).
*/

{
    TSortInfo S;
    PTobjlist p;

    HEAD_CHECK( H, ListInsertSorted );

    S.Comparator	= H->Comparator;
    S.ComparatorInfo	= H->ComparatorInfo;
    H->Comparator	= CSorting;
    H->ComparatorInfo	= &S;
    p			= InternalStrFind( H, O, strlen(O)+1 );
    if (p == NULL) p = &H->objlist;
    InternalListInsert( H, p, O, len );
    H->Comparator	= S.Comparator;
    H->ComparatorInfo	= S.ComparatorInfo;
}

void
ListStrlInsertSorted( H, O, len )
    PTobjlistHeader H;
    const char * O;
    int len;

/*
    Here, the string length is assumed to be the object length.
*/

{
    ListInsertSorted( H, O, len+1 );
}

void
ListStrInsertSorted( H, O )
    PTobjlistHeader H;
    const char * O;
{
    ListInsertSorted( H, O, strlen( O ) + 1 );
}

/**
    End of ListStrInsertSorted.
**/

static void
swap( pe1, pe2 )
    PTobjlist * pe1;
    PTobjlist * pe2;

/**
    Swap to nodes in a list.  Handle case when they are next to
    each other.  This case needs to be handled specially because
    there is no list between pe1 and pe2 to change, and besides,
    it's faster anyhow.

    At one time, this code was a 'macro' in qsort.h.  Some speed
    tests showed this code to be at least as fast when put into a
    subroutine, possibly faster.  Not to mention that the binary
    is going to be significantly smaller as a result.

    Warning: this code depends on the list header having the next
    and prev pointers in that order and aligned and at the top
    of the node.

    The compiler does seem to inline this code anyhow.  However,
    it is seemingly able to make better use of it rather than
    having to deal with a bunch of repeated source that was
    generated by a macro expansion.
**/

{
    PTobjlist e1 = *pe1;
    PTobjlist e2 = *pe2;

    e1->prev->next	= e2;
    e2->next->prev	= e1;

    if (e1->next == e2) {
	e2->prev	= e1->prev;
	e1->prev	= e2;

	e1->next	= e2->next;
	e2->next	= e1;
    } else {
	PTobjlist swap_temp[ 2 ];

	e1->next->prev	= e2;		/* Fix list inbetween e1...e2 */
	e2->prev->next	= e1;

	memcpy( swap_temp, e1, sizeof swap_temp );
	memcpy( e1, e2, sizeof swap_temp );
	memcpy( e2, swap_temp, sizeof swap_temp );
    }

    *pe1	= e2;
    *pe2	= e1;
}

/**
    End of swap.
**/

static void
swap3a( pe1, pe2, pe3 )
    PTobjlist * pe1;
    PTobjlist * pe2;
    PTobjlist * pe3;

/**
    Assumes nodes in h, n, t order, re-arranges to n, t, h.
    We have to look for cases when two nodes ajoin.  We can also
    exploit this case and make faster links.

    See comments in swap3b for notes on the odd way to move the
    nodes when none are next to each other.
**/

{
    PTobjlist e1 = *pe1;
    PTobjlist e2 = *pe2;
    PTobjlist e3 = *pe3;

    e1->prev->next	= e2;
    e3->next->prev	= e1;

    if (e1->next == e2) {
	e2->prev	= e1->prev;
	e1->next	= e3->next;

	if (e2->next == e3) {
	    e2->next	= e3;
	    e3->prev	= e2;
	    e3->next	= e1;
	    e1->prev	= e3;
	} else {
	    e2->next->prev	= e3;
	    e3->next		= e2->next;
	    e2->next		= e3;
	    e3->prev->next	= e1;
	    e1->prev		= e3->prev;
	    e3->prev		= e2;
	}
    } else if (e2->next == e3) {
	e1->next->prev	= e2;
	e2->next	= e1->next;
	e1->next	= e3->next;

	e2->prev->next	= e3;
	e3->prev	= e2->prev;
	e2->prev	= e1->prev;
	e3->next	= e1;
	e1->prev	= e3;
    } else {
#if 0
	PTobjlist swap_temp;

	e2->prev->next	= e1;

	swap_temp	= e2->prev;
	e2->prev	= e1->prev;
	e1->prev	= swap_temp;

	e1->next->prev	= e3;

	swap_temp	= e1->next;
	e1->next	= e3->next;
	e3->next	= swap_temp;
#else

/*
    Standard swap; doesn't move interior lists.  See comments
    in swap3b.
*/

	PTobjlist swap_temp[ 2 ];

	e1->next->prev	= e2;

	e2->prev->next	= e3;
	e2->next->prev	= e3;

	e3->prev->next	= e1;

	memcpy( swap_temp, e1, sizeof swap_temp );
	memcpy( e1, e3, sizeof swap_temp );
	memcpy( e3, e2, sizeof swap_temp );
	memcpy( e2, swap_temp, sizeof swap_temp );
#endif
    }

    *pe1	= e2;
    *pe2	= e3;
    *pe3	= e1;
}

/**
    End of swap3a.
**/

static void
swap3b( pe1, pe2, pe3 )
    PTobjlist * pe1;
    PTobjlist * pe2;
    PTobjlist * pe3;

/*
    Assumes nodes in h, n, t order, re-arranges to t, h, n.
    We have to look for cases when two nodes ajoin.  We can also
    exploit this case and make faster links.

    Very similar to swap3a.

    The case where none of the 3 nodes are next to each other is
    handled specially.  Turns out we really don't care if the
    lists inbetween the nodes get moved so long as the nodes are
    in order at the end.  So, we can move fewer pointers this
    way.

    The upper case letters are nodes.  When they appear under
    E1...E3, they are the values of the next and prev pointers
    for E1...E3.  Implicit is that we are only interested in
    A->next, B->prev, C->next, etc.

               E1            E2           E3
       -------+-+-----------+-+----------+-+-----
          A   |B|   B   C   |D|   D  E   |F|   F
              |A|           |C|          |E|

               E3            E1           E2
       -------+-+-----------+-+----------+-+-----
          A   |D|   D   E   |B|   B  C   |F|   F
              |A|           |E|          |C|

   So, we have to change A->next, e3->next, e3->prev, D->prev,
   E->next, e1->prev, e2->next, and F->prev.  This is 8 pointers,
   intead of 12.  Note that the B..C, D..E lists swap sides,
   but this isn't important.
*/

{
    PTobjlist e1 = *pe1;
    PTobjlist e2 = *pe2;
    PTobjlist e3 = *pe3;

    e1->prev->next	= e3;
    e3->next->prev	= e2;

    if (e1->next == e2) {
	if (e2->next == e3) {
	    e3->prev	= e1->prev;
	    e2->next	= e3->next;

	    e3->next	= e1;
	    e2->prev	= e1;
	    e1->prev	= e3;
	    e1->next	= e2;
	} else {
	    e2->next->prev	= e1;
	    e3->prev->next	= e2;

	    e1->next	= e2->next;

	    memcpy( e2, e3, sizeof( void * [2] ));

	    e3->prev	= e1->prev;

	    e3->next	= e1;
	    e1->prev	= e3;
	}
    } else if (e2->next == e3) {
	e1->next->prev	= e3;
	e2->prev->next	= e1;

	e2->next	= e3->next;

	memcpy( e3, e1, sizeof( void * [2] ));

	e1->prev	= e2->prev;

	e1->next	= e2;
	e2->prev	= e1;
    } else {
#if 0
	PTobjlist swap_temp;

	e2->next->prev	= e3;
	e3->prev->next	= e1;

	swap_temp	= e3->next;
	e3->next	= e2->next;
	e2->next	= swap_temp;

	swap_temp	= e3->prev;
	e3->prev	= e1->prev;
	e1->prev	= swap_temp;
#else

/*
    Conventional swap.  Leaves B..C and D..E where they were,
    so to speak.
*/

	PTobjlist swap_temp[ 2 ];

	e1->next->prev	= e3;
	e2->prev->next	= e1;

	e2->next->prev	= e1;
	e3->prev->next	= e2;

	memcpy( swap_temp, e1, sizeof swap_temp );
	memcpy( e1, e2, sizeof swap_temp );
	memcpy( e2, e3, sizeof swap_temp );
	memcpy( e3, swap_temp, sizeof swap_temp );
#endif
    }

    *pe3	= e2;
    *pe2	= e1;
    *pe1	= e3;
}

/**
    End of swap3b.
**/

/**
    Instantiate the qsort routines, both short and long comparator
    versions.
**/

#define PTCOMPARATOR PTComparatorShort
#define CMPARGS( o1, l1, o2, l2, ci ) ( o1, o2 )
#define SHORTCMP 1

static void
QSortShort( Hdr )
    PTobjlistHeader Hdr;

#include "qsort.h"
#undef PTCOMPARATOR
#undef CMPARGS
#undef SHORTCMP

#define PTCOMPARATOR PTComparator
#define CMPARGS( o1, l1, o2, l2, ci ) ( o1, l1, o2, l2, ci )

static void
QSort( Hdr )
    PTobjlistHeader Hdr;

#include "qsort.h"
#undef PTCOMPARATOR
#undef CMPARGS

/**
    End of QSort.
**/

void
ListQSort( H )
    PTobjlistHeader H;

{

/*
    Enter proper QSort routine.
*/

    if (H->cnt > 1) {
	if (H->ComparatorShort != NULL) {
	    QSortShort( H );
	} else {
	    QSort( H );
	}
    }
}

#endif

/**
    End of ListQSort.
**/

void
ListUpdate( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    const void * O;
    int len;

/*
    This routine is used to update the current object.	It does
    not make sure the list remains sorted.
*/

{
    PTobjlist c = (PTobjlist) *Context;
    void * OldObject;
    int OldLen;

    OldObject = c->object;
    OldLen = c->len;

    HEAD_CHECK( H, ListUpdate );
    c->object = AllocAndCopyObject( H, O, len );
    c->len    = len;

    if (OldObject != NULL && H->Deallocator != NULL) {
	(H->Deallocator)( OldObject, OldLen, ListMemObject, H->AllocatorParam );
    }
}

void
ListStrlUpdate( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    const char * O;
    int len;

{
    ListUpdate( H, Context, (void *) O, len + 1 );
}

void
ListStrUpdate( H, Context, O )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    const char * O;

{
    ListUpdate( H, Context, (void *) O, strlen( O ) + 1 );
}

/**
    End of ListUpdate.
**/

/**
    ListFirst and Last.	 Simply set a NULL context value and
    call either ListNext or ListPrev.
**/

int
ListFirst( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    void ** O;
    int * len;
{
    PTobjlistContext iContext = NULL;

    ListNext( H, &iContext, O, len );
    if (Context != NULL) *Context = iContext;
    return( iContext != NULL );
}

int
ListStrlFirst( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** O;
    int * len;

{
    if (ListFirst( H, Context, (void **) O, len )) {
	(*len)--;
	return( TRUE );
    } else {
	return( FALSE );
    }
}

int
ListStrFirst( H, Context, O )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** O;

{
    return( ListFirst( H, Context, (void **) O, NULL ) );
}

int
ListLast( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    void ** O;
    int * len;
{
    PTobjlistContext iContext = NULL;

    ListPrev( H, &iContext, O, len );
    if (Context != NULL) *Context = iContext;
    return( iContext != NULL );
}

int
ListStrlLast( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** O;
    int * len;
{
    if (ListLast( H, Context, (void **) O, len )) {
	(*len)--;
	return( TRUE );
    } else {
	return( FALSE );
    }
}

int
ListStrLast( H, Context, O )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** O;
{
    return( ListLast( H, Context, (void **) O, NULL ) );
}

/**
    End of ListFirst/Last.
**/

int
ListNext( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    void ** O;
    int * len;

/*
    Lists a list head to tail.	Set Context to NULL prior to
    the first call, and supply the same location on successive
    calls.  The object ptr will be NULL at list end and the
    Context ptr will be initialized back to NULL as well.
    If len is NULL, then no length is returned.
*/

{
    PTobjlist c = (PTobjlist) *Context;

    HEAD_CHECK( H, ListNext );

    if (c == NULL) c = &H->objlist;
    c = c->next;

    if (c == &H->objlist) {
	*Context = NULL;
	H->last  = NULL;
	*O	 = NULL;
	return( FALSE );
    } else {
	*O	 = c->object;
	*Context = (PTobjlistContext) c;
	H->last  = c;
	if (len != NULL) *len = c->len;
	return( TRUE );
    }
}

int
ListPrev( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    void ** O;
    int * len;

/*
    Almost the same as ListNext.
*/

{
    PTobjlist c = (PTobjlist) *Context;

    HEAD_CHECK( H, ListPrev );

    if (c == NULL) c = &H->objlist;
    c = c->prev;

    if (c == &H->objlist) {
	*O	 = NULL;
	*Context = NULL;
	H->last  = NULL;
	return( FALSE );
    } else {
	*O	 = c->object;
	*Context = (PTobjlistContext) c;
	H->last  = c;
	if (len != NULL) *len = c->len;
	return( TRUE );
    }
}

int
ListStrlNext( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** O;
    int * len;
{
    if (ListNext( H, Context, (void **) O, len )) {
	(*len)--;
	return( TRUE );
    } else {
	return( FALSE );
    }
}

int
ListStrNext( H, Context, O )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** O;
{
    return( ListNext( H, Context, (void **) O, NULL ) );
}

int
ListStrlPrev( H, Context, O, len )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** O;
    int * len;
{
    if (ListPrev( H, Context, (void **) O, len )) {
	(*len)--;
	return( TRUE );
    } else {
	return( FALSE );
    }
}

int
ListStrPrev( H, Context, O )
    PTobjlistHeader H;
    PPTobjlistContext Context;
    char ** O;
{
    return( ListPrev( H, Context, (void **) O, NULL ) );
}

/**
    End of ListNext/ListPrev related code.
**/

int
ListFind( H, O, len, RO, rlen )
    PTobjlistHeader H;
    const void * O;
    int len;
    void ** RO;
    int * rlen;

/*
    This routine will locate the object and return a pointer to the
    actual object found if the return value is TRUE.  If FALSE, the
    object was not located.
*/

{
    PTobjlist p;

    HEAD_CHECK( H, ListFind );

    p = InternalFind( H, O, len );
    if (p != NULL) {
	if (RO != NULL) *RO = p->object;
	if (rlen != NULL) *rlen = p->len;
	return( TRUE );
    } else {
	if (RO != NULL) *RO = NULL;
	return( FALSE );
    }
}

/**
    End of ListFind.
**/

int
ListStrlFind( H, O, len, RO, RL )
    PTobjlistHeader H;
    const char * O;
    int len;
    char ** RO;
    int * RL;

/*
    Calls InternalFind and returns the object if located, else FALSE
    and a NULL ptr.
*/

{
    PTobjlist p;

    HEAD_CHECK( H, ListStrlFind );

    p = InternalStrFind( H, O, len + 1 );
    if (p != NULL) {
	if (RO != NULL) *RO = p->object;
	if (RL != NULL) *RL = p->len;
	return( TRUE );
    } else {
	if (RO != NULL) *RO = NULL;
	return( FALSE );
    }
}

int
ListStrFind( H, O, RO )
    PTobjlistHeader H;
    const char * O;
    char ** RO;
{
    int RL;

    return( ListStrlFind( H, O, strlen( O ), RO, &RL ) );
}

/**
    End of ListStrFind.
**/

void
ListRemove( H, Context )
    PTobjlistHeader H;
    PPTobjlistContext Context;

/*
    Removes an object from the list.  Context must be valid (non
    NULL).  Context moves to the next object after the one
    deleted.  Setting Context to the context returned by ListFirst
    and calling ListRemove until context is NULL will result in an
    empty list.
*/

{
    PTobjlist p = (PTobjlist) *Context;

#ifdef LISTDEBUG
    HEAD_CHECK( H, ListRemove );
    if (Context == NULL || *Context == NULL) {
	fprintf( stderr, "Invalid context passed to ListRemove.\n" );
	exit( LISTDEBUG_ERROR );
    }
#endif

    H->cnt--;
    p->prev->next	= p->next;
    p->next->prev	= p->prev;

    H->last = (p == &H->objlist) ? NULL : p->next;

    if (H->Deallocator != NULL) {
	(H->Deallocator)( p->object, p->len, ListMemObject,
	    H->AllocatorParam );
	(H->Deallocator)( p, sizeof( Tobjlist ), ListMemNode,
	    H->AllocatorParam );
    }

    *Context = (PTobjlistContext) H->last;
}

/**
    End of ListRemove.
**/

PTobjlistHeader
ListStrUnion( SubList, MainList )
    PTobjlistHeader SubList;
    PTobjlistHeader MainList;

/*
    Processes each entry in a SubList.  If the entry in the SubList
    is not located in the mainlist, then the entry is appended to
    the MainList.  The SubList is detroyed at the end.  The return
    from this routine, always NULL, should be assigned to SubList.

    Contexts from the SubList are no longer valid.

    Watch out, this is an O(m * n) routine.
*/

{
    PTobjlist SubListN;
    PTobjlist MainListN;
    PTobjlist LastMain;

    int Append;

#ifdef LISTDEBUG
    int SubCnt;
    int MainCnt;
    int Deleted = 0;
    int Appended = 0;
    int InnerCounter = 0;

    if (SubList == NULL) {
	fprintf( stderr,
	"List header Sublist is null in ListStrAccumulate.\n" );
	exit( LISTDEBUG_ERROR );
    }
    if (MainList == NULL) {
	fprintf( stderr,
	"List header Mainlist is null in ListStrAccumulate.\n" );
	exit( LISTDEBUG_ERROR );
    }

    SubCnt  = SubList->cnt;
    MainCnt = MainList->cnt;
#endif

/*
    Process the sublist.  Only check the original entries in
    MainList, we assume there were no duplicates in SubList.
*/

    SubListN  = SubList->objlist.next;
    LastMain  = MainList->objlist.prev;

    while( SubListN != &SubList->objlist ) {
#if LISTDEBUG
	InnerCounter = 0;
#endif
	MainListN = MainList->objlist.next;
	Append = TRUE;

	while( MainListN != &MainList->objlist ) {
	    int cmpc;

	    cmpc = (MainList->Comparator)( SubListN->object, SubListN->len,
					   MainListN->object, MainListN->len,
					   MainList->ComparatorInfo );

	    if (cmpc == 0) {
		Append = FALSE;
		break;
	    }
#if LISTDEBUG
	    InnerCounter++;
#endif
	    if (MainListN == LastMain) {
		break;
	    } else {
		MainListN = MainListN->next;
	    }
	}

	if (Append) {		/* Not found, append to tail */
#ifdef LISTDEBUG
            if (InnerCounter != MainCnt) {
		fprintf( stderr, "InnerCounter = %d, MainCnt = %d.  Whoops.\n",
		    InnerCounter, MainCnt );
		exit( LISTDEBUG_ERROR );
	    }
	    Appended++;
#endif
	    ListAppend( MainList, SubListN->object, SubListN->len );
	}
#ifdef LISTDEBUG
	else {
	    Deleted++;
	}
#endif
	SubListN = SubListN->next;
    }

#ifdef LISTDEBUG
    if (SubCnt + MainCnt - Deleted != MainList->cnt) {
	fprintf( stderr, "SubCnt = %d, MainCnt = %d, Deleted = %d, \
MainList->cnt = %d.  Woops.\n",
	SubCnt, MainCnt, Deleted, MainList->cnt );
	exit( LISTDEBUG_ERROR );
    }
    if (Appended + Deleted != SubCnt) {
	fprintf( stderr, "Appended = %d, Deleted = %d.  Whoops.\n",
	    Appended, Deleted );
	exit( LISTDEBUG_ERROR );
    }
#endif

    ListDelete( SubList );

    return( NULL );
}

PTobjlistHeader
ListStrAccumulate( SubList, MainList )
    PTobjlistHeader SubList;
    PTobjlistHeader MainList;
{
    return( ListStrUnion( SubList, MainList ) );
}

/**
    End of ListStrUnion.
**/

void
ListCopy( From, To )
    PTobjlistHeader From;
    PTobjlistHeader To;

/*
    This function copies a list and all it's objects.  This
    is a real copy (assuming the objects don't have pointers
    to objects that can't be shared).
*/

{
    PTobjlist FromN;
#ifdef LISTDEBUG
    int Total;

    if (From == NULL) {
	fprintf( stderr, "List header From is null in ListCopy.\n" );
	exit( LISTDEBUG_ERROR );
    }
    if (To == NULL) {
	fprintf( stderr, "List header To is null in ListCopy.\n" );
	exit( LISTDEBUG_ERROR );
    }
    Total = To->cnt + From->cnt;
#endif

    FromN = From->objlist.next;
    while( FromN != &From->objlist ) {
        ListAppend( To, FromN->object, FromN->len );
	FromN = FromN->next;
    }

#ifdef LISTDEBUG
    if (To->cnt != Total) {
	fprintf( stderr, "Total of from and to does not equal to after\
 copy (Should be %d, is %d.)\n",
	Total, To->cnt );
	exit( LISTDEBUG_ERROR );
    }
#endif
}

/**
    End of ListCopy.
**/

unsigned int
ListCnt( H )
    PTobjlistHeader H;
{ 
    HEAD_CHECK( H, ListCnt );
    return( H->cnt );
}

/** **/

void
ListInfo( HeaderSize, NodeSize )
    unsigned int * HeaderSize;
    unsigned int * NodeSize;
{
    *HeaderSize = sizeof( TobjlistHeader );
    *NodeSize   = sizeof( Tobjlist );
}

/**
    End of ListInfo.
**/

#if defined(LIST_ARRAY_FEATURES)
PTobjlistContextArray
ListArrayContext( H )
    PTobjlistHeader H;

/*
    Returns an array of contexts to all objects in the list.
    If there are no objects, then the returned pointer is NULL.
*/

{
    PTobjlistContextArray ca;
    PTobjlist p;
    int i;

#ifdef LISTDEBUG
    int Cnt = 0;

    HEAD_CHECK( H, ListArrayContext );
#endif

    if (H->cnt == 0) {
	return( NULL );
    }

    ca =
    (PTobjlistContextArray) (H->Allocator)( H->cnt * sizeof( TobjlistContext ),
	ListMemContextArray, H->AllocatorParam );

    p = H->objlist.next;
    i = 0;

    while( p != &H->objlist ) {

#ifdef LISTDEBUG
	Cnt++;
#endif

	(*ca)[ i++ ] = (PTobjlistContext) p;
	p = p->next;
    }

#ifdef LISTDEBUG
    if (Cnt != H->cnt) {
	fprintf( stderr, "List size problem in ListArrayContext (%d,%d).\n",
	    Cnt, H->cnt );
	exit( LISTDEBUG_ERROR );
    }
#endif

    return( ca );
}
#endif

/**
    End of ListArrayContext.
**/

#if defined(LIST_ARRAY_FEATURES)
PTobjectArray
ListArray( H )
    PTobjlistHeader H;

/*
    Returns an array of pointers to objects in the list.  If there
    are no objects, then the returned pointer is NULL.
*/

{
    PTobjectArray oa;
    PTobjlist p;
    int i;

#ifdef LISTDEBUG
    int Cnt = 0;

    HEAD_CHECK( H, ListArray );
#endif

    if (H->cnt == 0) {
	return( NULL );
    }

    oa =
    (PTobjectArray) (H->Allocator)( H->cnt * sizeof( void * ),
	ListMemContextArray, H->AllocatorParam );

    p = H->objlist.next;
    i = 0;

    while( p != &H->objlist ) {

#ifdef LISTDEBUG
	Cnt++;
#endif

	(*oa)[ i++ ] = p->object;
	p = p->next;
    }

#ifdef LISTDEBUG
    if (Cnt != H->cnt) {
	fprintf( stderr, "List size problem in ListArray (%d,%d).\n",
	    Cnt, H->cnt );
	exit( LISTDEBUG_ERROR );
    }
#endif

    return( oa );
}
#endif

/**
    End of ListArray.
**/

#if defined(LIST_ARRAY_FEATURES)
PTobjlistHeader
ListArrayUpdate( H, oa )
    PTobjlistHeader H;
    PTobjectArray oa;


/*
    Updates all objects in the list using the PTobjectArray oa.
    Copies each object pointer in the array into the list.  This
    provides a simple way to sort the list.  Generate the array
    using ListArray, sort the array using qsort and an appropriate
    comparitor, then restore the array to the list.

    WARNING: length information is lost in this process.
*/

{
    PTobjlist p;
    int i;

#ifdef LISTDEBUG
    int Cnt = 0;

    HEAD_CHECK( H, ListArrayUpdate );
#endif

    if (H->cnt == 0) {
	return( NULL );
    }

    p = H->objlist.next;
    i = 0;

    while( p != &H->objlist ) {

#ifdef LISTDEBUG
	Cnt++;
#endif

	p->object = (*oa)[ i++ ];
	p->len    = 0;
	p	  = p->next;
    }

#ifdef LISTDEBUG
    if (Cnt != H->cnt) {
	fprintf( stderr,
		"List size problem in ListArrayUpdate (%d,%d).\n",
		Cnt, H->cnt );
	exit( LISTDEBUG_ERROR );
    }
#endif

    return( H );
}
#endif

/**
    End of ListArrayUpdate.
**/

#if defined(GET_VERSION)
int main( argc, argv )
    int argc;
    char * argv[];

{
    printf( "%d.%d.%d\n", LIST_MAJOR, LIST_MINOR, LIST_PATCH );
    return( 0 );
}
#endif

/**
    End of List.c.
**/
