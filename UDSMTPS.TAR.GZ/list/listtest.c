#include <stdio.h>
#include <string.h>
#include <time.h>
#define LISTDEBUG 1
#include "list.c"

/*
    $Id: listtest.c,v 1.7 2005/04/20 21:19:36 mike Exp $
*/

int qstrcmp( const void * p1, const void * p2 )
{
    return( strcmp( *((char **) p1), *((char **) p2) ) );
}

int qcstrcmp( const void * p1, const void * p2 )
{
	char * o1;
	char * o2;

	ListStrGetObjectN( (PPTobjlistContext) p1, &o1 );
	ListStrGetObjectN( (PPTobjlistContext) p2, &o2 );
	return( strcmp( o1, o2 ) );
}

static int check_sorted( H, cnt )
	PTobjlistHeader H;
        int cnt;
{
    PTobjlist p;
    char * curr;
    char * prev = NULL;

    p = H->objlist.next;

    printf( "----------\n" );

    while( p != &H->objlist ) {
	curr = (char *) p->object;
	if (prev != NULL) {
	    printf( "%s, %s.\n", prev, curr );
	    if (strcmp( prev, curr ) == 1) {
		return( 1 );
	    }
	}

	prev = curr;
	p    = p->next;
	cnt--;
    }

   if (cnt != 0) {
	printf( "Count is %d, should be 0.\n", cnt );
        return(1);
    }
   printf( "----------\n" );

    return( 0 );
}

int main( int argc, char * argv[] )
{
    PTobjlistHeader H;
    PTobjlistHeader SubList;
    PTobjlistContext Context;
    PTobjectArray oa;
    PTobjlistContextArray ca;
    char * p;
    int i;

    H = ListCreate();
    ListStrInsert( H, "a" );
    ListStrInsert( H, "b" );
    ListStrInsert( H, "c" );
    ListStrAppend( H, "d" );

    Context = NULL;
    printf( "Should print c b a d: " );
    while( 1 ) {
	ListStrNext( H, &Context, &p );
	if (Context == NULL) break;
	printf( "%s ", p );
    }
    printf( "\n" );
    printf( "Should print d a b c: " );
    Context = NULL;
    while( 1 ) {
	ListStrPrev( H, &Context, &p );
	if (Context == NULL) break;
	printf( "%s ", p );
    }
    printf( "\n" );

    H = ListDelete( H );

    H = ListCreate();
    ListStrInsertSorted( H, "b" );
    ListStrInsertSorted( H, "c" );
    ListStrInsertSorted( H, "a" );
    ListStrInsertSorted( H, "aa" );
    if (check_sorted( H, 4 )) {
	fprintf( stderr, "Failed sort test 1.\n" );
	exit( 1 );
    }

    printf( "Should print c b aa a: " );
    Context = NULL;
    while( 1 ) {
	ListStrPrev( H, &Context, &p );
	if (Context == NULL) break;
	printf( "%s ", p );
    }
    printf( "\n" );
    printf( "Should print 4: %d\n", ListCnt( H ) );

    H = ListDelete( H );

    H = ListCreate();
    SubList = ListCreate();

    ListStrInsert( H, "a" );
    ListStrInsert( H, "b" );
    ListStrInsert( H, "c" );
    ListStrInsert( SubList, "b" );
    ListStrInsert( SubList, "c" );
    ListStrInsert( SubList, "d" );

    ListStrAccumulate( SubList, H );

    printf( "Should print c b a d: " );
    Context = NULL;
    while( 1 ) {
	ListStrNext( H, &Context, &p );
	if (Context == NULL) break;
	printf( "%s ", p );
    }
    printf( "\n" );
    printf( "Should print 4: %d\n", ListCnt( H ) );

    ListStrFind( H, "c", &p );
    printf( "Should print c: %s\n", p );
    Context = ListGetContext( H );
    ListRemove( H, &Context );

    printf( "Should print b a d: " );
    Context = NULL;
    while( 1 ) {
	ListStrNext( H, &Context, &p );
	if (Context == NULL) break;
	printf( "%s ", p );
    }
    printf( "\n" );
    printf( "Should print 3: %d\n", ListCnt( H ) );

    Context = NULL;
    while( 1 ) {
	ListStrNext( H, &Context, &p );
	if (Context == NULL) break;
	ListRemove( H, &Context );
    }
    printf( "Should print 0: %d\n", ListCnt( H ) );
    H = ListDelete( H );

    H = ListCreate();
    ListStrInsert( H, "b" );
    ListStrInsert( H, "c" );
    ListStrInsert( H, "a" );
    ListStrInsert( H, "aa" );

    oa = ListArray( H );

    printf( "Should print aa a c b: " );
    for( i = 0; i < ListCnt( H ); i++ ) {
	printf( "%s ", (char *) (*oa)[ i ] );
    }
    printf( "\n" );

    qsort( oa, ListCnt( H ), sizeof( void * ), qstrcmp );
    printf( "Should print a aa b c: " );
    for( i = 0; i < ListCnt( H ); i++ ) {
	printf( "%s ", (char *) (*oa)[ i ] );
    }
    printf( "\n" );

    ListArrayUpdate( H, oa );
    printf( "Should print a aa b c: " );
    Context = NULL;
    while( 1 ) {
	ListStrNext( H, &Context, &p );
	if (Context == NULL) break;
	printf( "%s ", p );
    }
    printf( "\n" );

    free( oa );
    H = ListDelete( H );

    H = ListCreate();
    ListStrInsert( H, "b" );
    ListStrInsert( H, "c" );
    ListStrInsert( H, "a" );
    ListStrInsert( H, "aa" );

    ca = ListArrayContext( H );

    printf( "Should print aa a c b: " );
    for( i = 0; i < ListCnt( H ); i++ ) {
	char * p;

	ListStrGetObject( H, &((*ca)[ i ]), &p );
	printf( "%s ", p );
    }
    printf( "\n" );

    qsort( ca, ListCnt( H ), sizeof( PTobjlistContext ), qcstrcmp );
    printf( "Should print a aa b c: " );
    for( i = 0; i < ListCnt( H ); i++ ) {
	char * p;

	ListStrGetObjectN( &((*ca)[ i ]), &p );
	printf( "%s ", p );
    }
    printf( "\n" );
    free( ca );

    {
	int i;
	static const char * Words[] = {
	"Yup", "a", "letter", "The", "whole", "correspondence",
	"all", "four", "letters", "total", "back", "and", "forth",
	"started", "because", "Uncle", "Paul", "once", "mentioned",
	"that", "if", "we", "got", "interesting", "stamps", "then",
	"we", "could", "send", "them", "to", "her", "since", "her",
	"conventschool", "sells", "them", "as", "a", "fundraising",
	"activity", "So", "last", "year", "I", "sent", "her",
	"a", "bunch", "of", "stamps", "that", "I", "had",
	"received", "and", "saved", "as", "well", "as", "our",
	"annual", "letter", "and", "an", "introductory", "letter",
	"telling", "her", "who", "we", "were", "She", "wrote",
	"back", "asking", "about", "my", "background", "etc", "so",
	"I", "wrote", "her", "a", "couple", "pages", "and", "sent",
	"it", "sometime", "in", "the", "middle", "of", "the",
	"year", "She", "just", "replied", "with", "a", "card",
	"and", "a", "letter", "that", "included", "that", "info",
	"I", "just", "sent", "you", "I", "will", "be",
	"sending", "her", "our", "annual", "letter", "with",
	"some", "more", "stamps", "today", "or", "tomorrow", "and",
	"will", "ask", "if", "she", "has", "any", "more",
	"details", "about", "the", "Bolduc", "history", "Your",
	"mom", "does", "not", "know", "much", "since", "she",
	"mentioned", "that", "to", "me", "last", "night", "and",
	"so", "Sr", "Louise", "andor", "Fr", "Richard", "her",
	"brother", "andor", "Uncle", "Paul", "may", "be", "the",
	"only", "sources", "so", "if", "you", "are", "serious",
	"about", "maybe", "doing", "a", "little", "research",
	"you", "may", "want", "to", "hurry", "up", "since", "none",
	"of", "them", "are", "spring", "chickens" };

	H = ListCreate();

	for( i=0; i < sizeof( Words ) / sizeof( Words[0] ); i++ ) {
	    ListStrInsertSorted( H, Words[ i ] );
	}

	if (check_sorted( H, i )) {
	    fprintf( stderr, "Failed sort test 2.\n" );
	    exit( 1 );
	}
	printf( "Should print %d: %d\n", (int) (sizeof( Words ) / sizeof( Words[0] )),
	    (int) ListCnt( H ) );
    }

    {
	int i;
	int j;
	static const char * Words[] = {
	"c", "B", "A",
	"Yup", "a", "letter", "The", "whole", "correspondence",
	"all", "four", "letters", "total", "back", "and", "forth",
	"started", "because", "Uncle", "Paul", "once", "mentioned",
	"that", "if", "we", "got", "interesting", "stamps", "then",
	"we", "could", "send", "them", "to", "her", "since", "her",
	"conventschool", "sells", "them", "as", "a", "fundraising",
	"activity", "So", "last", "year", "I", "sent", "her",
	"a", "bunch", "of", "stamps", "that", "I", "had",
	"received", "and", "saved", "as", "well", "as", "our",
	"annual", "letter", "and", "an", "introductory", "letter",
	"telling", "her", "who", "we", "were", "She", "wrote",
	"back", "asking", "about", "my", "background", "etc", "so",
	"I", "wrote", "her", "a", "couple", "pages", "and", "sent",
	"it", "sometime", "in", "the", "middle", "of", "the",
	"year", "She", "just", "replied", "with", "a", "card",
	"and", "a", "letter", "that", "included", "that", "info",
	"I", "just", "sent", "you", "I", "will", "be",
	"sending", "her", "our", "annual", "letter", "with",
	"some", "more", "stamps", "today", "or", "tomorrow", "and",
	"will", "ask", "if", "she", "has", "any", "more",
	"details", "about", "the", "Bolduc", "history", "Your",
	"mom", "does", "not", "know", "much", "since", "she",
	"mentioned", "that", "to", "me", "last", "night", "and",
	"so", "Sr", "Louise", "andor", "Fr", "Richard", "her",
	"brother", "andor", "Uncle", "Paul", "may", "be", "the",
	"only", "sources", "so", "if", "you", "are", "serious",
	"about", "maybe", "doing", "a", "little", "research",
	"you", "may", "want", "to", "hurry", "up", "since", "none",
	"of", "them", "are", "spring", "chickens" };

	for( j = 0; j < sizeof( Words ) / sizeof( Words[0] ); j++ ) {
	    H = ListCreate();

	    for( i=0; i < j; i++ ) {
		ListStrAppend( H, Words[ i ] );
	    }

	    ListQSort( H );

	    if (check_sorted( H, j )) {
		fprintf( stderr, "Failed sort test 3.\n" );
		exit( 1 );
	    }

	    if (ListCnt( H ) != j) {
		fprintf( stderr, "Count of H should be %d, not %d.\n",
		    j, ListCnt( H ) );
		exit( 1 );
	    }

	    H = ListDelete( H );
	}
    }

    return( 0 );
}
