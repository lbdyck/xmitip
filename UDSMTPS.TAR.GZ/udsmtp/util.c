/**
    UDSMTP - Simple SMTP Client
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: util.c,v 1.6 1999/12/15 19:34:33 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    This module contains some general routines.
**/
 
#include "genincl.h"

#include <time.h>
#if defined(HAVE_SYS_TIME_H)
#   include <sys/time.h>
#endif

#if defined(I370)
#   include <lcio.h>
#   include <os.h>
#endif

#include <netdb.h>

#if defined(ENABLE_WTO)
#include "wto.h"
#endif

#include "trace.h"
#include "util.h"

/*
    Some compilers are able to use the old style function
    headers as function prototypes, others aren't.  So,
    we define the functions here even though they are often
    not used until after their definition.
*/

#if defined(__STDC__)
#endif

static char SavedPgmName[ 256 ] = "<unknown>";

static FILE * LogFile = NULL;
static FILE * ReturnFile = NULL;
static FILE * RetryFile = NULL;
static FILE * FailFile = NULL;
static time_t LastErrorTime = (time_t) 0;
static char ReturnFileName[ 256 ];
static char RetryFileName[ 256 ];
static char FailFileName[ 256 ];

static int flushlog = FALSE;
static int NoHello = TRUE;
static int NoRetryHello = TRUE;
static int NoFailHello = TRUE;

#if defined(ENABLE_WTO)
static int wtoflag = FALSE;
static void wto( const char * inbuff, int len, char msgtype );
#endif

static FILE * dynopen( const char * Name, const char * Mode );

/*
    On MVS, call a system routine to ensure we are flushed.
*/

#if defined(I370)
#define fflush( F ) afflush( F, 0 );
#endif

#if defined(__STDC__)
static void WriteFile( void * buff, int len, FILE * file, 
    const char * FileText );
#else
static void WriteFile();
#endif

/**
    End of Global Definitions.
**/
 
void
SetFlushLog( Flag )
    int Flag;
{
    flushlog = Flag;
}

/**
    End of SetFlushLog.
**/

char *
remfrnt( ptr, c )
    char * ptr;
    const char * c;
 
/*
    Removes characters in 'c' from the front of the string 'ptr'.
    Modifies the string pointed to by ptr directly.  'ptr'
    must be null terminated, and is returned null terminated.
*/
 
{
    int sl;
 
    sl = strspn( ptr, c );
    if (sl > 0)
    {					    /* + 1 for the \0 */
	memmove( ptr, ptr + sl, strlen( ptr ) - sl + 1 );
    }
    return( ptr );
}
 
/**
    End of remfrnt.
**/
 
char *
remend( ptr, c )
    char * ptr;
    const char * c;
 
/*
    This routine removes all characters in 'c' from the end
    of 'ptr'.  The string ptr is modified directly by changing
    the end of string marker.
*/
 
{
#ifdef I370
    *(ptr +  strrspn( ptr, c ) ) = '\0';
#else
    char * p;
 
    p	 = strlen( ptr ) + ptr - 1;
    if (p < ptr) return( ptr );	      /* Happens when ptr = "" */
 
    do
    {
	if (strchr( c, *p ) == 0) break;
    } while( (p--) > ptr );
    *(++p) = 0;			/* Null terminate string */
#endif
 
    return( ptr );
}
 
/**
    End of remend.
**/
 
char *
cpyn( target, src, n )
    char * target;
    const char * src;
    int n;
 
/*
    Copy n characters to target, then null terminate.
    Don't use strncpy because by ANSI, strncpy must 0 all
    characters not used.  Whoever speced strncpy was rather
    anal.

    'n' is string length, not buffer length.  n == sizeof Buff - 1.
*/
 
{
    int len;

    len = strlen( src );
    if (len > n) len = n;
    memcpy( target, src, len );
    target[ len ] = '\0';
    return( target );
}
 
/**
    End of cpyn.
**/
 
char *
catn( target, src, n )
    char * target;
    const char * src;
    int n;
 
/*
    Cat characters to target, limited to n chars, then null terminate.
    When called as:

    char target[ n ];
    catn( target, src, n - 1 );

    The target won't overflow.
*/
 
{
    int tlen  = strlen( target );
    int slen  = strlen( src );

    if (tlen + slen > n) {
	if (n - tlen > 0)
	    strncat( target, src, n - tlen );
	target[ n ] = '\0';
    } else
	strcat( target, src );
    return( target );
}
 
/**
    End of catn.
**/
 
#if !defined(HAVE_STRERROR)
extern char * sys_errlist[];
extern int sys_nerr;

char *
strerror(errnum)
    int errnum;
{
    if (errnum >= 0 && errnum < sys_nerr) {
	return( sys_errlist[ errnum ] );
    } else {
	return( NULL ); /* Not nice, but POSIX... */
    }
}
#endif

/**
    End of strerror.
**/

void
sdup( src, tgt )
    const char * src;
    char ** tgt;

/*
    More concise strdupAndFree.
*/

{ *tgt = strdupAndFree( src, *tgt ); }

/**
    End of sdup.
**/

int
sdupx( PreferedSrc, AlternateSrc, tgt )
    const char * PreferedSrc;
    const char * AlternateSrc;
    char ** tgt;

/*
    Copies the PreferedSrc if available, else the AlternateSrc
    if available, else empties the ptr and returns FALSE.
    Returns TRUE if the ptr has something in it.
*/

{
    if (PreferedSrc != NULL) {
	*tgt = strdupAndFree( PreferedSrc, *tgt );
        return( TRUE );
    } else if (AlternateSrc != NULL) {
	*tgt = strdupAndFree( AlternateSrc, *tgt );
        return( TRUE );
    } else {
        empty( tgt );
        return( FALSE );
    }
}

/** **/

void
empty( src )
    char ** src;

/*
    A common operation is to free memory if the ptr is not
    NULL.  This does that.  It also NULLs the ptr.
*/

{ if (*src != NULL) {free( *src ); *src = NULL; } }

/**
    End of empty.
**/

char *
strbuff( len )
    unsigned int len;

/*
    Allocates a string buffer.	The trailing '\0' is not
    be included in the 'len', it is automatically added.
    The buffer is initialized such that strlen( p ) == 0;
*/

{
    char * p = malloc( len + 1 );
    if (p == NULL)
    {
	Stderrp( "Unable to allocate a %d byte string buffer.\n",
	    len + 1 );
	exit( 1 );
    }
    else
	*p = '\0';
    return( p );
}

/**
    End of strbuff.
**/

#if !defined(HAVE_STRDUP)
char *
strdup( c )
    const char * c;
 
{
    int len  = strlen( c );
    char * p = strbuff( len );
    memcpy( p, c, len + 1 );
    return( p );
}
#endif
 
/**
    End of strdup.
**/

char *
strdupAndFree( s, p )
    const char * s;
    char * p;

/*
    If p is not NULL, then free it.  Then, strdup.
*/

{
    if (p != NULL) free( p );
    return( strdup( s ) );
}

/**
    strdupAndFree.
**/

char *
strdupcat( s1, s2, p )
    const char * s1;
    const char * s2;
    char * p;

/*
    Cat the strings, free any old strings.
*/

{
    int len1 = strlen( s1 );
    int len2 = strlen( s2 );
    char * c = strbuff( len1 + len2 );

    memcpy( c, s1, len1 );
    memcpy( c + len1, s2, len2 + 1 );
    if (p != NULL) free( p );
    return( c );
}

/**
    End of strdupcat.
**/

#if !defined(HAVE_STRLWR)
char *
strlwr( c )
    char * c;

{
    char * p = c;

    while( *p != '\0') { *p = tolower( *p ); p++; }
    return( c );
}

char *
strupr( c )
    char * c;
{
    char * p = c;

    while( *p != '\0') { *p = toupper( *p ); p++; }
    return( c );
}
#endif

/**
    End of strlwr/strupr.
**/

#if !defined(HAVE_MEMXLT)
void *
memxlt(data, table, len)
    void * data;
    const char * table;
    size_t len;

/**
    Provide a definition of the memxlt() function.

    Could probably do this with an in-line TRT, but
    this is straight-forward enough for now.
**/

{
    unsigned char * cdata = (unsigned char *) data;

    int i;
    for(i=0; i < len; i++) {
	cdata[i] = table[cdata[i]];
    }
    return data;
}
#endif

/**
    End of memxlt.
**/
 
static void
WriteFile( buff, len, file, FileText )
    void * buff;
    int len;
    FILE * file;
    const char * FileText;

/*
    General write routine.  FileText is used for error messages.
*/

{
    int wlen;

    LOOP {
	wlen = fwrite( buff, 1, len, file );
	if (ferror( file ) || wlen <= 0) {
	    int cerrno = errno;

	    Stdl( "**error writing to %s: %s.\n",
		FileText, strerror( cerrno ) );
	    Stderrp( "Error in writing to %s: %s.\n",
		FileText, strerror( cerrno ) );
	    exit( 1 );
	} else if (wlen < len) {
	    len -= wlen;
	    buff = (char *) buff + wlen;
	} else {
	    break;
	}
    }
}

/**
    End of WriteFile.
**/

#ifdef __STDC__
int
trace( const char * fmt, ... )
#else
#if defined(HAVE_STDARG_H)
int
trace( fmt )
    const char * fmt;
#else
int
trace( va_alist ) va_dcl
#endif
#endif
 
/*
    This routine is used to print all program trace messages.
*/
 
{
    va_list args;
    char    buff[ 512 ];
    int     len;
 
#if defined(HAVE_STDARG_H)
    va_start( args, fmt );
#else
    const char * fmt;

    va_start( args );
    fmt = va_arg( args, const char * );
#endif

#if defined(HAVE_VSNPRINTF)
    len = vsnprintf( buff, sizeof buff - 1, fmt, args );
    buff[ sizeof buff - 1 ] = '\0';
#else
    len = vsprintf( buff, fmt, args );
#endif
    va_end( args );
 
    WriteFile( buff, len, stdout, "trace file" );
 
    return( 0 );
}
 
/**
    End of trace.
**/
 
#ifdef __STDC__
int
Stdout( const char * fmt, ... )
#else
#if defined(HAVE_STDARG_H)
int
Stdout( fmt )
    const char * fmt;
#else
int
Stdout( va_alist ) va_dcl
#endif
#endif
 
/*
    This routine is used to write to stdout using an printf like
    interface.
*/
 
{
    va_list args;
    char buff[ 512 ];
    int len;
 
#if defined(HAVE_STDARG_H)
    va_start( args, fmt );
#else
    const char * fmt;

    va_start( args );
    fmt = va_arg( args, const char * );
#endif

#if defined(HAVE_VSNPRINTF)
    len = vsnprintf( buff, sizeof buff - 1, fmt, args );
    buff[ sizeof buff - 1 ] = '\0';
#else
    len = vsprintf( buff, fmt, args );
#endif
    va_end( args );
#if defined(ENABLE_WTO)
    if (wtoflag) {
	wto( buff, len, 'I' );
    } else {
	WriteFile( buff, len, stdout, "standard out" );
    }
#else
    WriteFile( buff, len, stdout, "standard out" );
#endif
 
    return( len );
}
 
/**
    End of Stdout.
**/
 
#ifdef __STDC__
int
Stderr( const char * fmt, ... )
#else
#if defined(HAVE_STDARG_H)
int
Stderr( fmt )
    const char * fmt;
#else
int
Stderr( va_alist ) va_dcl
#endif
#endif
 
/*
    This routine is used to write to stderr using an fprintf like
    interface.  Adds a timestamp if more than one second has
    elapsed since the last error message was written.
*/
 
{
    va_list args;
    char buff[ 512 ];
    int len;
 
#if defined(HAVE_STDARG_H)
    va_start( args, fmt );
#else
    const char * fmt;

    va_start( args );
    fmt = va_arg( args, char * );
#endif

#if defined(ENABLE_WTO)
    if (!wtoflag && difftime( LastErrorTime, time( NULL )) > 1.0) {
#else
    if (difftime( LastErrorTime, time( NULL )) > 1.0) {
#endif
	char buff[ 128 ];
	struct tm LocalTm;

	len = strftime( buff, sizeof buff, "**%Y/%m/%d (%j) %H:%M:%S\n",
	    GetLocalTime( &LocalTm ) );
	WriteFile( buff, len, stderr, "standard error" );
	
	LastErrorTime = time( NULL );
    }

#if defined(HAVE_VSNPRINTF)
    len = vsnprintf( buff, sizeof buff - 1, fmt, args );
    buff[ sizeof buff - 1 ] = '\0';
#else
    len = vsprintf( buff, fmt, args );
#endif
    va_end( args );
#if defined(ENABLE_WTO)
    if (wtoflag) {
	wto( buff, len, 'E' );
    } else {
	WriteFile( buff, len, stderr, "standard error" );
    }
#else
    WriteFile( buff, len, stderr, "standard error" );
#endif
 
    return( len );
}
 
/**
    End of Stderr.
**/
 
#ifdef __STDC__
int
Stderrp( const char * fmt, ... )
#else
#if defined(HAVE_STDARG_H)
int
Stderrp( fmt )
    const char * fmt;
#else
int
Stderrp( va_alist ) va_dcl
#endif
#endif
 
/*
    This routine is used to write to stderr using an fprintf like
    interface.  The program name is tacked on to the front.  Make
    sure you call SavePgmName first.  Adds a time stamp if more
    than one second has elapsed since the last error message.
*/
 
{
    va_list args;
    char buff[ 512 ];
    int plen;
    int len;
 
#if defined(HAVE_STDARG_H)
    va_start( args, fmt );
#else
    const char * fmt;

    va_start( args );
    fmt = va_arg( args, const char * );
#endif

#if defined(ENABLE_WTO)
    if (!wtoflag && difftime( LastErrorTime, time( NULL )) > 1.0) {
#else
    if (difftime( LastErrorTime, time( NULL )) > 1.0) {
#endif
	char buff[ 128 ];
	struct tm LocalTm;

	len = strftime( buff, sizeof buff, "**%Y/%m/%d (%j) %H:%M:%S\n",
			GetLocalTime( &LocalTm ) );
	WriteFile( buff, len, stderr, "standard error" );
	
	LastErrorTime = time( NULL );
    }


#if defined(ENABLE_WTO)
    if (wtoflag) {
	plen = 0;
    } else
#endif
    {
	strcpy( buff, SavedPgmName );
	strcat( buff, ": " );
	plen = strlen( buff );
    }

#if defined(HAVE_VSNPRINTF)
    len = vsnprintf( buff + plen, sizeof buff - 1 - plen, fmt, args );
#else
    len = vsprintf( buff, fmt, args );
#endif
    buff[ sizeof buff - 1 ] = '\0';
    va_end( args );

    len += plen;
#if defined(ENABLE_WTO)
    if (wtoflag) {
	wto( buff, len, 'E' );
    } else {
	WriteFile( buff, len, stderr, "standard error" );
    }
#else
    WriteFile( buff, len, stderr, "standard error" );
#endif
 
    return( plen + len );
}
 
/**
    End of Stderrp.
**/

int
OpenLogFile( name )
    const char * name;

/*
    Opens the logfile in append mode.  Result left in 'LogFile'.
*/

{
    if (strcmp( name, "-" ) == 0) {
	LogFile = stdout;
	return( TRUE );
    }

#ifdef I370
    quiet( TRUE );
#endif
    LogFile = dynopen( name, "a" );
#ifdef I370
    quiet( FALSE );
#endif
    if (LogFile == NULL) {
	Stderrp( "failed to open logfile '%s' for append: %s.\n",
	    name, strerror( errno ) );
	return( FALSE );
    } else {
	return( TRUE );
    }
}

void
CloseLogFile( void ) {
    if (LogFile != NULL && LogFile != stdout) fclose( LogFile );
    LogFile = NULL;
}

void
FlushLogFile( void ) {
    if (LogFile != NULL) fflush( LogFile );
}

/**
    End of Open/Flush/CloseLogfile.
**/

int
OpenReturnFile( name )
    const char * name;

/*
    Saves the Return file name.  We now delay the open until
    Stdr is actually called.
*/

{
    cpyn( ReturnFileName, name, sizeof ReturnFileName - 1 );

    return( TRUE );
}

void
CloseReturnFile( void ) {
    if (ReturnFile != NULL && !NoHello) {
	Stdr( "QUIT\n" );
    }
    if (ReturnFile != NULL && ReturnFile != stdout) {
	fclose( ReturnFile );
    }
    ReturnFile = NULL;
}

/**
    End of Open/CloseReturnFile.
**/

int
OpenRetryFile( name )
    const char * name;

/*
    Saves the Retry file name.  We now delay the open until
    Stdt is actually called.
*/

{
    cpyn( RetryFileName, name, sizeof RetryFileName - 1 );

    return( TRUE );
}

void
CloseRetryFile( void ) {
    if (RetryFile != NULL && !NoRetryHello) {
	Stdt( "QUIT\n" );
    }
    if (RetryFile != NULL && RetryFile != stdout) {
	fclose( RetryFile );
    }
    RetryFile = NULL;
}

/**
    End of Open/CloseRetryFile.
**/

int
OpenFailFile( name )
    const char * name;

/*
    Saves the Fail file name.  We now delay the open until
    Stdf is actually called.
*/

{
    cpyn( FailFileName, name, sizeof FailFileName - 1 );

    return( TRUE );
}

void
CloseFailFile( void ) {
    if (FailFile != NULL && !NoFailHello) {
	Stdf( "QUIT\n" );
    }
    if (FailFile != NULL && FailFile != stdout) {
	fclose( FailFile );
    }
    FailFile = NULL;
}

/**
    End of Open/CloseFailFile.
**/

#ifdef __STDC__
int
Stdl( const char * fmt, ... )
#else
#if defined(HAVE_STDARG_H)
int
Stdl( fmt )
    const char * fmt;
#else
int
Stdl( va_alist ) va_dcl
#endif
#endif
 
/*
    This routine is used to write to logfile using an fprintf like
    interface.
*/
 
{
    va_list args;
    char buff[ 512 ];
    time_t Time;
    struct tm * LocalTime;
    char * bp;
    int    tlen;
    int	   len;
 
#if defined(ENABLE_WTO)
    if (LogFile == NULL && !wtoflag) return( 0 );
#else
    if (LogFile == NULL) return( 0 );
#endif
    Time = time( &Time );
    LocalTime = localtime( &Time );
    tlen = strftime( buff, sizeof buff, "%H:%M:%S ", LocalTime );
    bp  = buff + tlen;
    len = sizeof buff - tlen;

#if defined(HAVE_STDARG_H)
    va_start( args, fmt );
#else
    const char * fmt;

    va_start( args );
    fmt = va_arg( args, const char * );
#endif

#if defined(HAVE_VSNPRINTF)
    len = vsnprintf( bp, len - 1, fmt, args );
#else
    len = vsprintf( bp, fmt, args );
#endif
    va_end( args );

#if defined(ENABLE_WTO)
    if (wtoflag) {
	wto( buff, tlen+len, 'I' );
    } else {
	WriteFile( buff, tlen+len, LogFile, "log file" );
	if (flushlog) FlushLogFile();
    }
#else
    WriteFile( buff, tlen+len, LogFile, "log file" );
    if (flushlog) FlushLogFile();
#endif
    return( len );
}
 
/**
    End of Stdl.
**/

#ifdef __STDC__
int
Stdr( const char * fmt, ... )
#else
#if defined(HAVE_STDARG_H)
int
Stdr( fmt )
    const char * fmt;
#else
int
Stdr( va_alist ) va_dcl
#endif
#endif
 
/*
    This routine is used to write to ReturnFile using an fprintf like
    interface.  Opens the file if it has not been opened yet.

    On OS/390, does not write zero length records - a space is added.
*/
 
{
    va_list args;
    char buff[ 512 ];
    int len;
 
#if defined(HAVE_STDARG_H)
    va_start( args, fmt );
#else
    const char * fmt;

    va_start( args );
    fmt = va_arg( args, const char * );
#endif

    if (ReturnFileName[ 0 ] == '\0') {
	return( 0 );
    } else if (ReturnFile == NULL) {
	if (strcmp( ReturnFileName, "-" ) == 0) {
	    ReturnFile = stdout;
	} else {
#ifdef I370
	    quiet( TRUE );
#endif
	    ReturnFile = dynopen( ReturnFileName, "a" );
#ifdef I370
	    quiet( FALSE );
#endif
	    if (ReturnFile == NULL) {
		Stderrp(
		"failed to open return file '%s' for write: %s.\n",
		    ReturnFileName, strerror( errno ) );
		exit( 1 );
	    }
	}
    }

    if (NoHello) {
	char hostname[ 512 ];

	NoHello = FALSE;
	gethostname( hostname, sizeof hostname - 1 );
	hostname[ sizeof hostname - 1 ] = '\0';
	Stdr( "HELO %s\n", hostname );
    }

#if defined(HAVE_VSNPRINTF)
    len = vsnprintf( buff, sizeof buff - 1, fmt, args );
    buff[ sizeof buff - 1 ] = '\0';
#else
    len = vsprintf( buff, fmt, args );
#endif
    va_end( args );

#if defined(I370)
    if (len == 1 && buff[ 0 ] == '\n') {
	len = 2;
	buff[ 1 ] = buff[ 0 ];
	buff[ 0 ] = ' ';
    }
#endif

    WriteFile( buff, len, ReturnFile, "return file" );
    return( len );
}
 
/**
    End of Stdr.
**/

#ifdef __STDC__
int
Stdt( const char * fmt, ... )
#else
#if defined(HAVE_STDARG_H)
int
Stdt( fmt )
    const char * fmt;
#else
int
Stdt( va_alist ) va_dcl
#endif
#endif
 
/*
    This routine is used to write to RetryFile using an fprintf like
    interface.  Opens the file if it has not been opened yet.

    On OS/390, does not write zero length records - a space is added.
*/
 
{
    va_list args;
    char buff[ 512 ];
    int len;
 
#if defined(HAVE_STDARG_H)
    va_start( args, fmt );
#else
    const char * fmt;

    va_start( args );
    fmt = va_arg( args, const char * );
#endif

    if (RetryFileName[ 0 ] == '\0') {
	return( 0 );
    } else if (RetryFile == NULL) {
	if (strcmp( RetryFileName, "-" ) == 0) {
	    RetryFile = stdout;
	} else {
#ifdef I370
	    quiet( TRUE );
#endif
	    RetryFile = dynopen( RetryFileName, "a" );
#ifdef I370
	    quiet( FALSE );
#endif
	    if (RetryFile == NULL) {
		Stderrp(
		"failed to open retry file '%s' for write: %s.\n",
		    RetryFileName, strerror( errno ) );
		exit( 1 );
	    }
	}
    }

    if (NoRetryHello) {
	char hostname[ 512 ];

	NoRetryHello = FALSE;
	gethostname( hostname, sizeof hostname - 1 );
	hostname[ sizeof hostname - 1 ] = '\0';
	Stdt( "HELO %s\n", hostname );
    }

#if defined(HAVE_VSNPRINTF)
    len = vsnprintf( buff, sizeof buff - 1, fmt, args );
    buff[ sizeof buff - 1 ] = '\0';
#else
    len = vsprintf( buff, fmt, args );
#endif
    va_end( args );

#if defined(I370)
    if (len == 1 && buff[ 0 ] == '\n') {
	len = 2;
	buff[ 1 ] = buff[ 0 ];
	buff[ 0 ] = ' ';
    }
#endif

    WriteFile( buff, len, RetryFile, "retry file" );
    return( len );
}
 
/**
    End of Stdt.
**/

#ifdef __STDC__
int
Stdf( const char * fmt, ... )
#else
#if defined(HAVE_STDARG_H)
int
Stdf( fmt )
    const char * fmt;
#else
int
Stdf( va_alist ) va_dcl
#endif
#endif
 
/*
    This routine is used to write to FailFile using an fprintf like
    interface.  Opens the file if it has not been opened yet.

    On OS/390, does not write zero length records - a space is added.
*/
 
{
    va_list args;
    char buff[ 512 ];
    int len;
 
#if defined(HAVE_STDARG_H)
    va_start( args, fmt );
#else
    const char * fmt;

    va_start( args );
    fmt = va_arg( args, const char * );
#endif

    if (FailFileName[ 0 ] == '\0') {
	return( 0 );
    } else if (FailFile == NULL) {
	if (strcmp( FailFileName, "-" ) == 0) {
	    FailFile = stdout;
	} else {
#ifdef I370
	    quiet( TRUE );
#endif
	    FailFile = dynopen( FailFileName, "a" );
#ifdef I370
	    quiet( FALSE );
#endif
	    if (FailFile == NULL) {
		Stderrp(
		"failed to open fail file '%s' for write: %s.\n",
		    FailFileName, strerror( errno ) );
		exit( 1 );
	    }
	}
    }

    if (NoFailHello) {
	char hostname[ 512 ];

	NoFailHello = FALSE;
	gethostname( hostname, sizeof hostname - 1 );
	hostname[ sizeof hostname - 1 ] = '\0';
	Stdf( "HELO %s\n", hostname );
    }

#if defined(HAVE_VSNPRINTF)
    len = vsnprintf( buff, sizeof buff - 1, fmt, args );
    buff[ sizeof buff - 1 ] = '\0';
#else
    len = vsprintf( buff, fmt, args );
#endif
    va_end( args );

#if defined(I370)
    if (len == 1 && buff[ 0 ] == '\n') {
	len = 2;
	buff[ 1 ] = buff[ 0 ];
	buff[ 0 ] = ' ';
    }
#endif

    WriteFile( buff, len, FailFile, "fail file" );
    return( len );
}
 
/**
    End of Stdf.
**/

void
SavePgmName( pgm )
    const char * pgm;
{
    int len;

    len = strlen( pgm );
    if (len > sizeof SavedPgmName - 1) len = sizeof SavedPgmName - 1;
    memcpy( SavedPgmName, pgm, len );
    SavedPgmName[ len ] = '\0';
}

/**
    End of SavePgmName.
**/
 

const char *
GetPgmName( void )
{
    return( SavedPgmName );
}

/**
    End of GetPgmName.
**/

struct tm *
GetLocalTime( local_tm )
    struct tm * local_tm;

/*
    Gets the local time in a safe way.
*/

{
    time_t now;
 
    time(&now);
    memcpy( local_tm, localtime( &now ), sizeof( struct tm ) );
    return( local_tm );
}

/**
    End of GetLocalTime.
**/

void
TimeStamp( void )
{
    char buff[ 128 ];
    struct tm LocalTm;

    strftime( buff, sizeof buff, "**%Y/%m/%d (%j) %H:%M:%S\n",
	GetLocalTime( &LocalTm ) );
    Stdl( buff );
}

/**
    End of TimeStamp.
**/

char *
Fmt822Date( Time, Buff )
    time_t Time;
    char * Buff;

/*
    Formats RFC822Date according to RFC822.  Attempts to figure out
    what the local time offset from GMT is.  The time value passed
    should therefore be in GMT and the locale or operating system
    must know what the offset from GMT is.

    Wed, 19 May 1999 09:43:34 -0400 (EDT)

    This is an example.  It does not seem to conform exactly to
    RFC822, but it is what is produced by either Pine or sendmail.
    I'm probably just reading the RFC wrong, or else the RFC has
    been updated.
*/

{
    struct tm LocalTime;	/* Input time converted to local time */
    struct tm GMTime;		/* Input time converted to UTC */
    time_t LocalTime_t;		/* Local time back to a time value */
    time_t GMTime_t;		/* UTC back to a time value */
    double Offset;		/* Offset LocalTime_t - GMTime_t */
    int    Offseth;		/* Offset converted to hours */
    int    Offsetm;		/* And minutes (usually zero) */
    char   SBuff[ 128 ];	/* strftime output */
    char   ZBuff[ 10 ];		/* Zone name, if we can get it */
    const char * Neg;		/* Char to output if Offset is negative */

/*
    Get local time and UTC and compute the difference.
*/

    memcpy( &LocalTime, localtime( &Time ), sizeof LocalTime );
    memcpy( &GMTime, gmtime( &Time ), sizeof GMTime );

    LocalTime_t = mktime( &LocalTime );
    GMTime_t    = mktime( &GMTime );

    Offset = difftime( LocalTime_t, GMTime_t );
    if (Offset < 0) {
	Offset *= -1.0;
	Neg = "-";
    } else {
	Neg = "";
    }
    Offseth = Offset / 3600;
    Offsetm = (int) (Offset / 60) % Offseth;

/*    Wed, 19 May 1999 09:43:34 -0400 */

    strftime( SBuff, sizeof SBuff - 1,
	"%a, %d %b %Y %H:%M:%S %%s%%02d%%02d", &LocalTime );
    sprintf( Buff, SBuff, Neg, Offseth, Offsetm );

/*
    Include zone name if we can determine it.
*/

    if (strftime( ZBuff, sizeof ZBuff - 1, "%Z", &LocalTime ) > 0) {
	strcat( Buff, " (" );
	strcat( Buff, ZBuff );
	strcat( Buff, ")" );
    }
    return( Buff );
}

/**
    End of Fmt822Date.
**/

#if defined(ENABLE_WTO)
void SetWto( int flag )
{ wtoflag = flag; }

int GetWto( void )
{ return( wtoflag ); }

static void
wto( const char * inbuff, int len, char msgtype )
 
/*
    This routine uses the WTO service on MVS to log messages.  Note
    that this routine is only available if ENABLE_WTO has been
    defined.

    If the first 3 characters of the message are TAU, then we
    assume that a TAU message identifier has already been prefixed
    to the message.  Otherwise, we add SMTP001I.  TAU messages are
    issued by bmail.
*/
 
{
    char  buff[ 79 ];
    const char * p = inbuff;
    int  clen;

    if (len > 0 && inbuff[ len - 1 ] == '\n') len--;
    while( len > 0 ) {
	if (len > 3 && memcmp( inbuff, "TAU", 3 ) != 0) {
	    memcpy( buff, "SMTP001", 7 );
	    buff[ 7 ] = msgtype;
	    buff[ 8 ] = ' ';
	    buff[ 9 ] = '\0';

	    clen = (len > sizeof buff - 10) ? sizeof buff - 10 : len;
	    memcpy( buff + 9, p, clen );
	    buff[ 9 + clen ] = '\0';
	} else {
	    clen = (len > sizeof buff - 1) ? sizeof buff - 1 : len;
	    memcpy( buff, p, clen );
	    buff[ clen ] = '\0';
	}
 
	p   += clen;
	len -= clen;

	WTO_WTP( buff );
    }
 
 
    return;
}

#endif

/**
    End of Set/GetWto.
**/

static FILE *
dynopen( Name, Mode )
    const char * Name;
    const char * Mode;

/*
    On OS/390, using SAS/C, this routine will check for the special
    file name that starts with "DYN:".  If it does, then a call to
    osdynalloc will be made to allocate the output file.  A DDNAME
    will be returned, and that DDNAME will be opened using using a
    normal fopen.

    If not running on OS/390 using SAS/C, a normal fopen will be
    done.
*/

{
#if !defined(I370)
    return( fopen( Name, Mode ));
#else
    char MsgBuff[ 256 ];
    char DDName[ 13 ];
    char NameBuff[ 512 ];
    int  rc;
    int  MsgCount = 0;
    int  Reason   = 0;
    dyn_msgbuf (*Msgs)[];

/*
    If we are not doing dynamic allocation, just do a normal
    fopen.
*/

    if (strncmp( Name, "DYN:", 4 ) != 0) {
        return( fopen( Name, Mode ));
    }

/*
    Build a set of osdynalloc parameters.  First, take what the
    user requested, less the "DYN:" string.  Then add a keyword to
    return the DDNAME allocate and various keywords to return
    diagnostics.
*/

    strcpy( NameBuff, Name+4 );
    strcat( NameBuff, ",retddname=?,reason=?,msgcount=?,errmsgs=?" );
    rc = osdynalloc( DYN_ALLOC, NameBuff, MsgBuff, DDName+4, &Reason,
                     &MsgCount, &Msgs );
    if (rc != 0) {
        int i;

        Stderrp( "SAS/C osdynalloc failed, ret=%d, reason=%d (dec).\n",
            rc, Reason );
        if (rc < 0) {
            Stderrp( "Msg from SAS/C: %s.\n", MsgBuff );
        }
        for( i = 0; i < MsgCount; i++ ) {
            Stderrp( "SVC99(IEFDB476): %*.*s",
                (*Msgs)[ i ].length,
                (*Msgs)[ i ].length,
                (*Msgs)[ i ].text );
        }
        if (MsgCount > 0) free( Msgs );
        return( NULL );
    }

/*
    We now have a dynamically allocated DDNAME.  Make a file name
    up consisting of the name and do a normal FOPEN.
*/

    memcpy( DDName, "DDN:", 4 );
    return( fopen( DDName, Mode ));
#endif
}

/**
    End of dynopen.
**/

/**
    End of util.c
**/
