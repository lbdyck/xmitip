/**
    UDSMTP - Simple SMTP Client
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: pool.c,v 1.1.1.1 1999/03/15 16:25:15 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    This module contains the routines used to do memory pool
    management.  The advantage of pooled storage management is
    simplicity of management and speed.  Basically, we malloc large
    blocks and then dole out chunks.  We only delete the large
    blocks as a group, and so there is no bookkeeping overhead for
    the small pieces that are given out (There is pool allocate
    function, but no pool free function, only pool delete, which
    deletes the entire pool.)
**/
 
#include "genincl.h"
#include "list.h"
#include "pool.h"
#include "util.h"

#include "trace.h"

/*
    Lists consist of a header, nodes that are used to string
    objects together and the objects themselves.  Everything gets
    dumped into the same pool.

    Define the initial number of bytes in a pool and how many
    should be added when a pool cell runs out.
*/

#define POOL_INITIAL (10 * 1024)
#define POOL_EXTEND  (10 * 1024)

/*
    If 'Last' is not NULL, then space should be allocated from the
    pool cell pointed to by Last.  Otherwise, take space from the
    main cell.  When a cell fills up, allocate a new one, and
    insert behind the main cell.
*/

typedef struct Pool tPool;
struct Pool {
    struct Pool * Last;
    unsigned int  Len;
    unsigned int  Used;
    unsigned int  Extend;
    void * Buffer;
};

/*
    Some compilers are able to use the old style function
    headers as function prototypes, others aren't.  So,
    we define the functions here even though they are often
    not used until after their definition.
*/

#if defined(__STDC__)
static tPool * Pool( unsigned int InitSize, unsigned int ExtendSize );
static void  * Palloc( tPool * Poolp, int Len );
static void Pdel( tPool * Pool );
static void * PoolAllocator( int len, enum ListFlags Flags, void * p );
static int PoolDeallocator( void * o, int len, enum ListFlags Flags, void * p );
#else
static tPool * Pool();
static void  * Palloc();
static void Pdel();
static void * PoolAllocator();
static int PoolDeallocator();
#endif

/**
    End of Global Definitions.
**/

static tPool *
Pool( InitSize, ExtendSize )
    unsigned int InitSize;
    unsigned int ExtendSize;

/*
    Creates a pool.
*/

{
    tPool * Pool;

    Pool = malloc( sizeof( tPool ) );
    if (Pool == NULL) {
	Stderrp( "unable to malloc a tPool.\n" );
	exit( 1 );
    }
    memset( Pool, 0, sizeof( tPool ) );

    Pool->Used = 0;
    Pool->Len  = InitSize;
    Pool->Extend = ExtendSize;
    Pool->Last   = NULL;

    Pool->Buffer = malloc( Pool->Len );
    if (Pool->Buffer == NULL) {
	Stderrp( "unable to allocate %d bytes for pool buffer.\n",
	    Pool->Len );
	exit( 1 );
    }
    return( Pool );
}

/**
    End of Pool.
**/

static void  *
Palloc( PoolPtr, Len )
    tPool * PoolPtr;
    int Len;

/*
    Allocates space in the pool, extending if needed.
*/

{
    tPool * cPool;
    void * p;

    if (PoolPtr->Last != NULL)
	cPool = PoolPtr->Last;
    else
        cPool = PoolPtr;

    if (cPool->Used + Len > cPool->Len) {
	tPool * NewPool;

	if (Len > PoolPtr->Extend) {
	    PoolPtr->Extend = Len * 5;
        }
        NewPool = malloc( sizeof( tPool ) );
	if (NewPool == NULL) {
	    Stderrp( "unable to malloc a tPool.\n" );
	    exit( 1 );
	}
	NewPool->Last = PoolPtr->Last;
	NewPool->Len  = PoolPtr->Extend;
	NewPool->Extend = PoolPtr->Extend;
	NewPool->Used = 0;

	NewPool->Buffer = malloc( NewPool->Extend );
	if (NewPool->Buffer == NULL) {
	    Stderrp( "unable to allocate %d bytes for pool buffer.\n",
		NewPool->Len );
	    exit( 1 );
	}

	PoolPtr->Last = NewPool;
	cPool = NewPool;
    }

/*
    Align storage on 8 byte bounderies.
*/

    if ((cPool->Used & 0x07) != 0) {
	cPool->Used |= 0x07;
	cPool->Used++;
    }

    p = (void *) (((char *) cPool->Buffer) + cPool->Used);
    cPool->Used += Len;

    return( p );
}

/**
    End if Palloc.
**/

static void
Pdel( tPool * PoolPtr )

/*
    Frees the memory associated with a pool.
*/

{
    tPool * NextPool;

    while( PoolPtr != NULL ) {
	free( PoolPtr->Buffer );
	NextPool = PoolPtr->Last;
	free( PoolPtr );
	PoolPtr = NextPool;
    }
}

/**
    End of Pdel.
**/

static void *
PoolAllocator( len, Flags, p)
    int len;
    enum ListFlags Flags;
    void * p;

/*
    Allocator for use with the list routines.  Allocates from the
    pool.
*/

{
    tPool * PoolPtr = p;

    switch (Flags) {
        case ListMemHeader:
        case ListMemNode:
        case ListMemObject:
	    return( Palloc( PoolPtr, len ) );
	    break;
	default:
	    Stderrp( "PoolAllocator called with unknown flag (%dd).\n",
		Flags );
	    exit( 1 );
    }
}

/**
    End of PoolAllocator.
**/

static int
PoolDeallocator( o, len, Flags, p )
    void * o;
    int len;
    enum ListFlags Flags;
    void * p;

/*
    Used when the storage mechanism needs explicit releases of
    storage.
*/

{
    tPool * PoolPtr = p;

    switch (Flags) {
	case ListMemList:
	    Pdel( PoolPtr );	/* Deletes entire list */
	    break;
	default:
	    return( FALSE );
	    break;
    }

    return( TRUE );
}

/**
    End of PoolDeallocator.
**/

PTobjlistHeader
PoolListCreate( void )

/*
    Used to create a list that references a pool.
*/

{
    return( ListCreateWithAllocator( &PoolAllocator, &PoolDeallocator,
        Pool( POOL_INITIAL, POOL_EXTEND )));
}

/**
    End of PoolListCreate.
**/

/**
    End of pool.c
**/
