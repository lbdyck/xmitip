/**
    UDSMTP - Simple SMTP Transmission Agent.
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: args.c,v 1.8 2001/02/16 20:28:42 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    We use a modified GNU getopt_long to process the arguments.
    The 'options' table will describe the arguments that this
    progrm takes.

    The XtraInfo table is used to create the GNU options table and
    the short form string.  The XtraInfo table also has help
    strings.  So, one table controls long, short and help.  Also,
    its all symbolically associated.  The position in the array
    doesn't matter.  Also, the associated constants do not need to
    be contiguous values, or even small values.
**/

#include "genincl.h"
#include <sys/types.h>
#include <netdb.h>
#include <netinet/in.h>
#include "license.h"
#include "udsmtp.h"
#include "args.h"
#include "getopt.h"
#include "util.h"

/*
    If you have local overrides, create the file deflocal.h, add
    any defines you want to override and re-run configure (or just
    edit the Makefile - but be aware you'll loose the changes if
    you do re-run configure).

    Save deflocal.h from release to release.
*/

#if defined(HAVE_DEFLOCAL_H)
#include "deflocal.h"
#endif

/*
    The following constants are used to link argument names, code,
    and messages for arguments together.
*/

enum ArgIndexes {
    A_HOST,
    A_PORT,
    A_LOGFILE,
    A_RETURNFILE,
    A_NORETURNFILE,
    A_FAILFILE,
    A_NOFAILFILE,
    A_RETRYFILE,
    A_NORETRYFILE,
    A_TRIMBLANKS,
    A_NOTRIMBLANKS,
    A_RECEIVED,
    A_NORECEIVED,
    A_MX,
    A_NOMX,
    A_DELAY,
#if defined(ENABLE_WTO)
    A_WTO,
    A_NOWTO,
#endif
    A_FLUSHLOG,
    A_NOFLUSHLOG,
    A_LICENSE,
    A_HELP,
    A_VERSION
};
 
struct xtraInfo
{
    const char * name;		/* Command name - lower case */
    int	   has_arg;		/* 0-no, 1=required arg, 2=opt. arg */
    char   short_form;		/* Short form of command, lower case */
    int	   negatable;		/* Can option be negated? */
    int	   val;			/* The integer value for this cmd */
    const char * help_text;	/* Associated help text */
    const char * defval;	/* Default value text */
};
 
/*
    By convention, negatable options have a NULL help text.  The
    positive form will have '(no)' added when the help text is
    output.

    This table is best ordered by function or placement in the main
    switch.  It is not otherwise sorted.
*/

struct xtraInfo XtraInfo[] =
{
/*
Command	       Args Short Negatable   Symbol	  Help
Name		    Form			  Text
--------------------------------------------------------------------
*/
{"host",	 1, 'o',    FALSE,    A_HOST,
		"FQDN of host to deliver message to" },
{"port",         1, 'p',    FALSE,    A_PORT,
		"TCP/IP port to use (default is SMTP)"},
{"mx",		 0, 'm',    TRUE,     A_MX,
		"Convert host names using MX records" },
{"nomx",	 0,  0,	    FALSE,    A_NOMX, NULL },
{"delay",        1, 'd',    FALSE,    A_DELAY,
		"Delay (secs), before reconnect, after failure" },
{"logfile",      1, 'l',    FALSE,    A_LOGFILE,
		"File to write log messages to" },
{"returnfile",   1, 'r',    TRUE,     A_RETURNFILE,
		"File to write failed messages to (rfc822 fmt)"},
{"noreturnfile", 0, 0,      FALSE,    A_NORETURNFILE, NULL },
{"retryfile",    1, 't',    TRUE,     A_RETRYFILE,
		"File to write msgs for re-sending" },
{"noretryfile",  0, 0,      FALSE,    A_NORETRYFILE, NULL },
{"failfile",     1, 'f',    TRUE,     A_FAILFILE,
		"File to write dead messages to"},
{"nofailfile",   0, 0,      FALSE,    A_NOFAILFILE, NULL },
{"trimblanks",   0, 0,      TRUE,     A_TRIMBLANKS,
		"Remove trailing blanks from input"},
{"notrimblanks", 0, 0,      FALSE,    A_NOTRIMBLANKS, NULL },
{"received",     1, 0,      TRUE,     A_RECEIVED,
		"Added Received: to header"},
{"noreceived",   0, 0,      FALSE,    A_NORECEIVED, NULL },
{"flushlog",     0, 0,      TRUE,     A_FLUSHLOG,
		 "Flush log file after every write"},
{"noflushlog",   0, 0,      FALSE,    A_NOFLUSHLOG, NULL },
#if defined(ENABLE_WTO)
{"wto",          0, 0,      TRUE,     A_WTO,
		"Output errors and logging using WTO"},
{"nowto",        0, 0,      FALSE,    A_NOWTO, NULL },
#endif
{"version",	 0, 0,	    FALSE,    A_VERSION,
		"Displays the program's version and exits (&)" },
{"help",	 0, 'h',    FALSE,    A_HELP,
		"Display this help and exits (&)"},
{"license",	 0, 0,	    FALSE,    A_LICENSE,
		"Display the program license (&)"}
};
static int LocalArgIndex;
 
/*
    From the above table, we can compute the GNU style long
    options table and the short form as well.
 
    Leave enough room in the table for the lower case form, the
    upper case form, and a final NULL.	Upper case is needed
    because some sub-systems in MVS make it very difficult to pass
    lower case strings.
*/
 
static struct option LongOptions[ DIM( XtraInfo )*2 + 1 ];
 
/*
    For each option, we have a lower case form, and an upper case
    form (for the reason stated above).	 Each option in the string
    could consume 3 characters, c::.  A single colon after the
    option means the option takes an arg, and a double colon means
    it takes an optional arg.  So, we need 6 chars per input
    option.
*/
 
static char ShortOptions[ DIM( XtraInfo )*6 + 1 ];
 
static const char * deftrue  = " (*)";

/*
    Some compilers are able to use the old style function
    headers as function prototypes, others aren't.  So,
    we define the functions here even though they are often
    not used until after their definition.
*/

#if defined(__STDC__)
static void InitOptions( struct xtraInfo XtraInfo[], int Cnt,
    int * LocalArgIndex, struct option LongOptions[],
    char * ShortOptions );
static boolean GetInt( char * optarg, int * val );
static const char * db( boolean b );
static const char * dd( int val, char ** dbp );
static const char * ds( const char * val, char ** dbp );
static void SetDef( int Val, int Cnt, const char * defval );
static void PrintHelp( const char * pgm );
static void PrintLicense( void );
#else
static void InitOptions();
static boolean GetInt();
static const char * db();
static const char * dd();
static const char * ds();
static void SetDef();
static void PrintHelp();
static void PrintLicense();
#endif

/**
    End of Globals.
**/

static boolean
GetInt( optarg, val )
    char * optarg;
    int * val;
 
/*
    Gets an integer from optarg.  Returns TRUE if found,
    else FALSE.
*/
 
{
    int Tval;
    char * End;
 
    Tval = strtol( optarg, &End, 10 );
    while( isspace( (unsigned char) *End ) ) End++;
    if (*End != '\0')
	return( FALSE );
    else {
	*val = Tval;
	return( TRUE );
    }
}
 
/**
    End GetInt.
**/
 
static void
InitOptions( XtraInfo, Cnt, LocalArgIndex, LongOptions, ShortOptions )
    struct xtraInfo XtraInfo[];
    int Cnt;
    int * LocalArgIndex;
    struct option LongOptions[];
    char * ShortOptions;
 
/*
    This routine is used to build a long_options table and a short
    form based on the info in XtraInfo.  These structures are input
    to my_getopt_long, which is baiscally GNU getopt_long with
    recursive calling capability.  See getopt.c and getopt.h.
*/
 
{
    int i;
    char * s = ShortOptions;
 
    *s++ = '+';		/* Don't mess around with arg ordering */

    for( i = 0; i < Cnt; i++ )
    {
	LongOptions[ i*2 + 0 ].name = XtraInfo[ i ].name;
	LongOptions[ i*2 + 1 ].name =
		       strupr( strdup( XtraInfo[ i ].name ) );
	LongOptions[ i*2 + 0 ].has_arg = XtraInfo[ i ].has_arg;
	LongOptions[ i*2 + 1 ].has_arg = XtraInfo[ i ].has_arg;
	LongOptions[ i*2 + 0 ].flag    = LocalArgIndex;
	LongOptions[ i*2 + 1 ].flag    = LocalArgIndex;
	LongOptions[ i*2 + 0 ].val     = XtraInfo[ i ].val;
	LongOptions[ i*2 + 1 ].val     = XtraInfo[ i ].val;
 
	if (XtraInfo[ i ].short_form != 0)
	{
	    *s++ = XtraInfo[ i ].short_form;
	    if (XtraInfo[ i ].has_arg > 0)
		*s++ = ':';
	    if (XtraInfo[ i ].has_arg > 1)
		*s++ = ':';
	    *s++ = toupper( XtraInfo[ i ].short_form );
	    if (XtraInfo[ i ].has_arg == 1)
		*s++ = ':';
	}
    }
 
    LongOptions[ i*2 ].name = NULL;
    *s = '\0';
}
 
/**
    End of InitOptions.
**/

/**
    Various routines that support PrintHelp.  'db' prints a
    boolean, 'dd' prints an integer, and 'ds' prints a
    string.  SetDef is used to note the default value for the
    option list.  The 'opt' argument is used to note when TRUE if
    the value of the argument is optional and will be supplied
    automatically when the option is used.
**/

static const char *
db( b ) 
    boolean b;
{
    return( b ? deftrue : NULL );
}

static const char *
dd( val, dbp )
    int val;
    char ** dbp;
{
    char * sdbp = *dbp;

    sprintf( *dbp, " (%d)", val );
    *dbp += strlen( *dbp );
    *(*dbp)++ = '\0';
    return( sdbp );
}

static const char *
ds( val, dbp )
    const char * val;
    char ** dbp;
{
    char * sdbp = *dbp;

    if (val != NULL) {
	sprintf( *dbp, " (%s)", val );
	*dbp += strlen( *dbp );
	*(*dbp)++ = '\0';
	return( sdbp );
    } else {
	return( NULL );
    }
}

static void
SetDef( Val, Cnt, defval )
    int Val;
    int Cnt;
    const char * defval;

/*
    Sets the default value for an option given it's integer
    name.
*/

{
    int i;
    for( i = 0; i < Cnt; i++ ) {
	if (XtraInfo[ i ].val == Val) {
	    XtraInfo[ i ].defval = defval;
	    break;
	}
    }
}

/**
    End of SetDef.
**/

static void
PrintHelp( pgm )
    const char * pgm;
 
/*
    Prints help.
*/
 
{
    char def_buff[ 512 ];
    char * dbp = def_buff;

    TCmdParse c;
    int len;
    int i;
    int j;
    int Cnt = DIM( XtraInfo );

/*
    Get a new initialized command parse block so that we can obtain
    the true defaults from it.
*/

    InitArgs( &c, 0, NULL );
    c.host = strdup( "<required>" );
    FinalArgs( &c );
 
    SetDef( A_HOST, Cnt, ds( c.host, &dbp ) );
    SetDef( A_PORT, Cnt, dd( c.port , &dbp) );
    SetDef( A_DELAY, Cnt, dd( c.delay , &dbp) );
    SetDef( A_MX,   Cnt, db( c.mx ) );
    SetDef( A_LOGFILE, Cnt, ds( c.logfile, &dbp ) );
    SetDef( A_RETURNFILE, Cnt, ds( c.returnfile, &dbp ) );
    SetDef( A_RETRYFILE, Cnt, ds( c.retryfile, &dbp ) );
    SetDef( A_FAILFILE, Cnt, ds( c.failfile, &dbp ) );
    SetDef( A_TRIMBLANKS, Cnt, db( c.trimblanks ) );
#if defined(ENABLE_WTO)
    SetDef( A_WTO, Cnt, db( GetWto() ) );
#endif
    SetDef( A_RECEIVED, Cnt, ds( c.received, &dbp ) );

    Stdout( "UDSMTP V%d.%d.%d\n",
    UDSMTP_MAJOR, UDSMTP_MINOR, UDSMTP_PATCH );

    Stdout( "Copyright (C) 1995-1999 University of Delaware\n\n" );
    Stdout( "UDSMTP comes with ABSOLUTELY NO WARRANTY; for details\n" );
    Stdout( "type `%s --license'.\n\n", pgm );
    Stdout( "This is free software, and you are welcome to redistribute it\n" );
    Stdout( "under certain conditions; type `%s --license' for details.\n\n",
	pgm );
    Stdout( "This program is a simple BSMTP handler.  It makes one\n" );
    Stdout( "connection and transfers all mail to the host using " );
    Stdout( "the SMTP protocol.\n\n" );

    Stdout( "The standard input consists of a file in BSMTP format.\n" );
    Stdout( "The messages in the file are trasmitted using SMTP to\n" );
    Stdout( "the --host with an smtp server on --port.\n\n" );

    Stdout( "A resolver call is made for the name on --host; connection\n" );
    Stdout( "attempts are made for each host listed as a MX for --host.\n" );
    Stdout( "If no connect is made for any host, sleep for 5 minutes,\n" );
    Stdout( "get new host MX list and try again.  Never stops.  If\n" );
    Stdout( "--nomx is specified, then the MX record lookup is skipped.\n\n");

#if defined(I370)
    Stdout(
    "On MVS, the input file must be specified as the final parameter.\n\n");
#else
    Stdout(
    "An optional input file may be specified as the final parameter.\n\n");
#endif

    Stdout( "\
    Long form (ShortForm)	   Description\n\
--------------------------------------------------------------------------\n" );
 
    for( i = 0, j = 0; i < Cnt; i++ )
    {
	if (XtraInfo[ i ].help_text == NULL)
	    continue;

	if (XtraInfo[ i ].negatable)
	    len = Stdout( "--(no)%s", XtraInfo[ i ].name );
	else
	    len = Stdout( "--%s", XtraInfo[ i ].name );

	if (XtraInfo[ i ].short_form != 0)
	    len += Stdout( " (-%c)", XtraInfo[ i ].short_form );
 
	if (XtraInfo[ i ].has_arg == 1)
	    len += Stdout( "=<arg>" );
	else if (XtraInfo[ i ].has_arg == 2)
	    len += Stdout( "=<<arg>>" );
 
	if (len < 27) {
	    char buff[ 28 ];

	    memset( buff, ' ', 27 - len );
	    buff[ 27 - len ] = '\0';
	    Stdout( buff );
	}

	Stdout( "%s", XtraInfo[ i ].help_text );
	if (XtraInfo[ i ].defval != NULL)
	    Stdout( "%s\n", XtraInfo[ i ].defval );
	else
	    Stdout( "\n" );
    }
 
    Stdout( "\
--------------------------------------------------------------------------\n\
  *   - Denotes a default option.\n\
(...) - A default value that is used.\n\
(no)  - Option can be negated.	Negated options take no values.\n\
[...] - A default value if the option is used without a value.\n\
  #   - Option can be specified more than once.\n" );

    Stdout( "\
  &   - Option performs its action immediately.\n\n\
Note that long option forms start with '--' and short forms\n\
with '-'.  Short forms without arguments can be combined into\n\
one list starting with '-'.  For instance, -xyz is legal.\n" );

    Stdout( "\
'=<arg>' means the option takes an argument, '=<<arg>>', optional.\n" );
 
/*
    Many of these pointers pointed to auto storage in this stack
    frame.  Zap the pointers so we don't accidently use them
    somewhere else.
*/

    for( i = 0; i < Cnt; i++ )
	XtraInfo[ i ].defval = NULL;

    FreeArgs( &c );
}
 
/**
    End of PrintHelp.
**/

static void
PrintLicense()

/*
    This routine is used to print the program license and then
    exit.
*/

{
    int i;

    for( i = 0; i < DIM( license ); i++ ) { puts( license[ i ] ); }
    SetCleanExit();
    exit( 0 );
}

/**
    End of PrintLicense.
**/
 
void
InitArgs( c, argc, argv )
    PTCmdParse c;
    int argc;
    const char * argv[];
 
/*
    This routine is used to initialize a command parse
    block.
*/
 
{
    struct servent * pServent;

    memset( c, 0, sizeof( TCmdParse ) );

    pServent = getservbyname( "smtp", "tcp" );
    if (pServent != NULL) {
        c->port = ntohs( pServent->s_port );
    } else {
	Stderrp( "getservbyname does not locate \"smtp\", \"tcp\".\n" );
	c->port = 25;
    }

    sdup( "-", &c->logfile );
    sdup( "-", &c->returnfile );
    sdup( "-", &c->retryfile );
    sdup( "-", &c->failfile );
    c->trimblanks = FALSE;
    c->received   = NULL;
    c->mx         = TRUE;
    c->delay	  = 300;
#if defined(ENABLE_WTO)
    SetWto( FALSE );
#endif
    SetFlushLog( FALSE );
}
 
/**
    End of InitArgs.
**/
 
void
FinalArgs( c )
    PTCmdParse c;
 
/*
    This routine should be called after all argument sets have
    been processed.  It is used to fill in any defaults that
    we have not yet applied - most likely because the exact
    default depends on what parameters were present.
*/
 
{
    int ExitCode = 0;

    if (c->host == NULL ) {
	Stderrp( "--host is required.\n" );
	ExitCode = 1;
    }

    if (c->port == 0) {
	Stderrp( "A --port=0 (or getservbyname failure) is likely to \
cause a failure.\n" );
    }

    if (ExitCode > 0) exit( ExitCode );
}
 
/**
    End of FinalArgs.
**/

void
FreeArgs( c )
    PTCmdParse c;

/*
    Frees all the items in the command parse block.
*/

{
    empty( &c->logfile );
    empty( &c->returnfile );
    empty( &c->received );

    memset( c, 0, sizeof( TCmdParse ) );
}

/**
    End of FreeArgs.
**/
 
boolean
args( argc, argv, c, AllowFiles, FirstFile )
    int argc;
    char * argv[];
    PTCmdParse c;
    boolean AllowFiles;
    int * FirstFile;
 
/*
    This routine is used to process the command line.  The command
    parse result, 'c', is assume to have been initialized by
    InitArgs.  This routine can be called more than once for the
    same command parse block, allowing command lines to be processed
    from multiple locations.

    AllowFiles	-- If TRUE, then we assume that any arguments that
		   don't start with '-' or '--' are file names.
    FirstFile	-- Receives the index of the first file argument.
*/
 
{
    int	    ret_code;
    boolean BadArg;
    boolean PrtErr;
    struct getopt_info info;
 
/*
    Create the LongOptions and ShortOptions from the table.
*/
 
    if (LongOptions[ 0 ].name == NULL)
	InitOptions( XtraInfo, DIM( XtraInfo ),
		     &LocalArgIndex, LongOptions,
		     ShortOptions );
 
    BadArg = FALSE;
    PrtErr = FALSE;
    info.optind = 0;
    info.opterr = 1;
    info.optopt = '?';
 
    LOOP 
    {
	int OptionIndex;
 
	ret_code = my_getopt_long(&info, argc, argv, ShortOptions,
			       LongOptions, &OptionIndex );
	if (ret_code == EOF) break;
	BadArg = (ret_code == '?') ? TRUE : BadArg;
 
/*
    Each short form option has an associated long form.	 Look up
    the long form in the XtraInfo table, get the associated value,
    and finally compute the index into the 'options' table so that
    error message code works no matter if the long or short form
    was used.  Also, this causes the short form to get expanded
    into the long form in the messages - probably a good thing.
*/
 
	if (ret_code != 0 && ret_code != '?')
	{
	    int c = tolower( ret_code );
 
	    for( OptionIndex = 0;
		 OptionIndex < DIM( XtraInfo ) &&
		 c != XtraInfo[OptionIndex].short_form;
		 OptionIndex++ );
	    LocalArgIndex = XtraInfo[ OptionIndex ].val;
	    OptionIndex *= 2;  /* Indexes LongOptions */
	}
	else if (ret_code == '?')
	    LocalArgIndex = -1;

	switch (LocalArgIndex)
	{
	    case -1: break;

	    case A_PORT:  
		PrtErr = !GetInt( info.optarg, &c->port);
		if (c->port < 1) PrtErr = TRUE;
		break;
	    case A_MX:   c->mx = TRUE;  break;
	    case A_NOMX: c->mx = FALSE; break;

	    case A_DELAY:
		PrtErr = !GetInt( info.optarg, &c->delay);
		if (c->delay < 1) PrtErr = TRUE;
		break;
 
	    case A_HOST:    sdup( info.optarg, &c->host ); break;
	    case A_LOGFILE: sdup( info.optarg, &c->logfile ); break;
	    case A_RETURNFILE: sdup( info.optarg, &c->returnfile ); break;
	    case A_NORETURNFILE: empty( &c->returnfile ); break;
	    case A_RETRYFILE: sdup( info.optarg, &c->retryfile ); break;
	    case A_NORETRYFILE: empty( &c->retryfile ); break;
	    case A_FAILFILE: sdup( info.optarg, &c->failfile ); break;
	    case A_NOFAILFILE: empty( &c->failfile ); break;
	    case A_TRIMBLANKS: c->trimblanks = TRUE; break;
	    case A_NOTRIMBLANKS: c->trimblanks = FALSE; break;
	    case A_RECEIVED: sdup( info.optarg, &c->received ); break;
	    case A_NORECEIVED: empty( &c->received ); break;
#if defined(ENABLE_WTO)
	    case A_WTO: SetWto( TRUE ); empty( &c->logfile ); break;
	    case A_NOWTO: SetWto( FALSE ); break;
#endif

	    case A_FLUSHLOG:
		SetFlushLog( TRUE );
		break;

	    case A_NOFLUSHLOG:
		SetFlushLog( FALSE );
		break;

	    case A_HELP:
		PrintHelp( argv[ 0 ] );
		SetCleanExit();
		exit( 0 );
		break;

	    case A_VERSION:
		Stdout( "%d.%d.%d\n", UDSMTP_MAJOR,
		    UDSMTP_MINOR, UDSMTP_PATCH );
		SetCleanExit();
		exit( 0 );
		break;

	    case A_LICENSE:
		PrintLicense();
		SetCleanExit();
                exit( 0 );
		break;

	    default:
		Stderrp( "Unanticipated argument, code = %d.\n",
			 LocalArgIndex );
		exit( 1 );
	}
	if (PrtErr) {
	    Stderrp( "Invalid argument '%s' to '%s'.\n",
		info.optarg, LongOptions[ OptionIndex ].name );
	    BadArg = TRUE;
	    PrtErr = FALSE;
	}
    }	    /* End of LOOP */
 
    *FirstFile = info.optind;
    if ((AllowFiles && (info.optind + 1 < argc)) ||
        (!AllowFiles && (info.optind < argc))) {
	char buff[ 128 ];
 
	buff[ 0 ] = '\0';
 
	while( info.optind < argc )
	{
	    if (strlen( argv[ info.optind ] ) + strlen( buff ) <
		sizeof buff - 2)
	    {
		if (buff[ 0 ] != '\0') strcat( buff, " " );
		strcat( buff, argv[ info.optind++ ] );
	    }
	}
 
	Stderrp( "Extraneous arguments: %s.\n", buff );
	BadArg = TRUE;
    }
 
    return( !BadArg );
}
 
/**
    End of Args.c.
**/
