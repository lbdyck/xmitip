/**
    UDSMTP - Simple SMTP Client
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: pgmopts.c,v 1.1.1.1 1999/03/15 16:25:15 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    SAC/C Run-time option defaults.  All options are listed,
    with the one in use NOT commented out.
**/

#include <options.h>
 
const int  _options =
		_BTRACE +	   /* Gives traceback */
	     /* _DEBUG	+	*/ /* Starts debugger */
	     /* _FILLMEM +	*/ /* Fills memory with 0xfc */
		_HCSIG	 +	   /* Estae for S0C4, 0C1... */
		_HTSIG	 +	   /* Estae for prog. term */
	     /* _MULTITASK +	*/ /* Multitask under debugger */
	     /* _QUIT	   +	*/ /* Term. prog. on lib msg */
	     /* _USAGE	   +	*/ /* Prints stor. use at pgm end */
	     /* _WARNING   +	*/ /* Forces lib msgs even if quiet()*/
	     /* _ZEROMEM   +	*/ /* Zeroes memory */
		0;
 
const int  _negopts =
	     /* _NOBTRACE +	*/ /* Gives traceback */
		_NODEBUG  +	   /* Starts debugger */
		_NOFILLMEM +	   /* Fills memory with 0xfc */
	     /* _NOHCSIG   +	*/ /* Estae for S0C4, 0C1... */
	     /* _NOHTSIG   +	*/ /* Estae for prog. term */
	     /* _NOQUIT	     +	*/ /* Term. prog. on lib msg */
	     /* _NOUSAGE     +	*/ /* Prints stor. use at pgm end */
	     /* _NOWARNING   +	*/ /* Forces lib msgs even if quiet()*/
		_NOZEROMEM   +	   /* Zeroes memory */
		0;
 
const char _linkage =
	  /*	_FDUMP;	    */	 /* Expensive, but nice */
	  /*	_INTER;	    */	 /* Default, inter language */
	  /*	_MINIMAL;   */	 /* No overflow checks, etc */
		_OPTIMIZE;	 /* Fastest, least checks */
 
const int _stack   = 32767 * 8;	 /* Stack size */
const int _heap	   = 32767 * 8;	 /* Starting heap size */
const int _nlibopt = 0;		 /* SAC/C run-time args */
 
const char * _pgmnm = "UDSMTP";  /* Default pgm name */
 
const char * _style  = "DDN:";	 /* DDnames are assumed for files */
 
/**
    End of Global Definitions.
**/
