/**
    UDSMTP - Simple SMTP Client
    Copyright (C) 1995, 1996 University of Delaware.
    $Id: mx.c,v 1.5 2009/01/27 17:43:31 mike Exp $

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    This module contains routines that query for MX records.  If
    found, the hosts referenced are used instead of the host name
    specified in c->host.  We assume that the request is running
    through a local nameserver, which caches whatever we get.  This
    assumption, if false, does not make this program fail, it
    simply makes it less efficient.  For instance, when obtaining
    MX records, usually, additional resource records are provided
    that specify the address of any listed hosts.  We don't process
    this information directly - we simply do standard gethostbyname
    calls later on.  Since the local named cached the information,
    there is little reason to go to the trouble of handling A
    records and the like.
**/
 
/* #define TRACING */
/* #define CVDEBUG 1 */
 
#include "genincl.h"
#include "getopt.h"
#include "list.h"
#include "udsmtp.h"
#include "args.h"
#include "util.h"
#include "pool.h"
#include "mx.h"

#include <sys/types.h>
#include <netinet/in.h>
#define BIND_8_COMPAT 1
#include <arpa/nameser.h>
#include <arpa/inet.h>
#include <resolv.h>

#if defined(__STDC__)
#else
#endif

/**
    End of Globals.
**/

PTobjlistHeader
GetMX( const char * hostname, boolean DoMX )

/*
    This routine returns a list of names, sorted such that the most
    prefered hosts are first, of MX record domain names associated
    with 'hostname'.  If no MX records are located, then 'hostname'
    is added to the list.

    If 'hostname' is really an IP address, then the IP address is
    added to the list and the lookup is bypassed.

    If DoMX is FALSE, then just add the hostname to the list and
    exit.
*/

{
    unsigned char QueryBuff[ PACKETSZ ];	/* Raw query buffer */
    unsigned char AnswerBuff[ PACKETSZ ];	/* Raw answer buffer */
    HEADER * QueryHeader;	/* Maps header for query */
    HEADER * AnswerHeader;	/* Maps header for answer */

    char NameBuff[ MAXDNAME + 1 ];		/* For expanded names */
    char MXNameBuff[ MAXDNAME + 6 + 1 ];	/* For pref + name */

    unsigned char * rptr;	/* Ptr into answer buffer */
    int QueryLen;		/* Length of query */
    int AnswerLen;		/* Length of answer */
    int CompLen;		/* # of bytes in compressed name */
    int i;

    unsigned short Type;
    unsigned short Class;
    unsigned long Ttl;
    unsigned short Rdl;
    unsigned short Preference;

    PTobjlistHeader MXList = NULL;
    PTobjlistContext Context = NULL;

/*
    IP address check.
*/

    if (!DoMX || inet_addr( hostname ) != -1) {
	MXList = PoolListCreate();
	ListStrAppend( MXList, hostname );
	return( MXList );
    }

/*
    Build the query, then send it.  We do it this way rather than
    using res_search because not all machines have res_search.
*/

    QueryLen =
    res_mkquery( QUERY, (char *) hostname, C_IN, T_MX, NULL, 0, NULL,
	QueryBuff, sizeof QueryBuff );
    
    if (QueryLen <= 0) {
	Stderrp( "internal error in GetMX: res_mkquery=%d.\n",
	    QueryLen );
	exit( 1 );
    }

    AnswerLen =
    res_send( QueryBuff, QueryLen, AnswerBuff, sizeof AnswerBuff );

    if (AnswerLen <= 0) {
	Stderrp( "internal error in GetMX: res_send: %d.\n",
	    AnswerLen );
	exit( 1 );
    }

    QueryHeader  = (HEADER *) QueryBuff;
    AnswerHeader = (HEADER *) AnswerBuff;

    if (QueryHeader->id != AnswerHeader->id) {
	Stderrp( "internal error in GetMX: ids DO NOT match: %x:%x.\n",
	    QueryHeader->id, AnswerHeader->id );
	exit( 1 );
    }

    MXList = PoolListCreate();

    if (AnswerHeader->rcode != 0 || AnswerHeader->ancount == 0) {
	ListStrAppend( MXList, hostname );
	return( MXList );
    }

/*
    Remove the questions.
*/

    rptr = AnswerBuff + sizeof( HEADER );
    for( i = 0; i < ntohs( AnswerHeader->qdcount ); i++ ) {
	CompLen = dn_expand( AnswerBuff, AnswerBuff + AnswerLen - 1,
	    rptr, NameBuff, sizeof NameBuff );

	if (CompLen == -1) {
	    Stderrp( "internal error in GetMX: Error decompressing name.\n" );
	    exit( 1 );
	}
	rptr += CompLen;

	GETSHORT( Type, rptr );
  	GETSHORT( Class, rptr );
    }

/*
    Process the answer section.
*/

    for( i = 0; i < ntohs( AnswerHeader->ancount ); i++ ) {
	CompLen = dn_expand( AnswerBuff, AnswerBuff + AnswerLen - 1,
	    rptr, NameBuff, sizeof NameBuff );

	if (CompLen == -1) {
	    Stderrp( "internal error in GetMX: Error decompressing name.\n" );
	    exit( 1 );
	}

/*
    If you are going to do this, make sure a caseless compare is
    done.  dn_expand does not convert to upper case on all
    systems.  I'm going to drop the test because I am real sure I
    am only asking one question, and therefore only have answers
    for that question.
*/

/*	if (strcmp( NameBuff, hostname ) != 0) continue; */

	rptr += CompLen;

	GETSHORT( Type, rptr );
  	GETSHORT( Class, rptr );
	GETLONG( Ttl, rptr );
	GETSHORT( Rdl, rptr );

	if (Class != C_IN) {
	    continue;
	} else if (Type == T_MX) {
	    GETSHORT( Preference, rptr );
	} else if (Type == T_CNAME) {
	    Preference = 0;
	} else {
	    continue;
	}

	CompLen = dn_expand( AnswerBuff, AnswerBuff + AnswerLen - 1,
	    rptr, NameBuff, sizeof NameBuff );

	if (CompLen == -1) {
	    Stderrp( "internal error in GetMX: Error decompressing name.\n" );
	    exit( 1 );
	}

	rptr += CompLen;

	sprintf( MXNameBuff, "%05u %s", Preference, NameBuff );
	ListStrInsertSorted( MXList, MXNameBuff );
    }

/*
    Re-process the list, removing the preference values.  They
    aren't really useful to the caller.
*/

    Context = NULL;
    LOOP {
	char * MXptr;
	char * spc;

	ListStrNext( MXList, &Context, &MXptr );
	if (Context == NULL) break;

	spc = strchr( MXptr, ' ' );
	if (spc == NULL) continue;	/* Actually, an error */

	memmove( MXptr, spc + 1, strlen( spc + 1 ) + 1 );

	ListStrUpdate( MXList, &Context, MXptr );
    }

    return( MXList );
}

/**
    End of GetMX.
**/

/**
    End of mx.c.
**/
