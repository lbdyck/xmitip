/**
    List Management routines.

    Version 4.3.1

    $Id: list.h,v 1.11 2002/09/12 16:46:05 mike Exp $

    Copyright (C) 1995-1998 University of Delaware.

    This program is free software; you can redistribute it and/or modify
    it under the terms of the GNU General Public License as published by
    the Free Software Foundation; either version 2 of the License, or
    (at your option) any later version.

    This program is distributed in the hope that it will be useful,
    but WITHOUT ANY WARRANTY; without even the implied warranty of
    MERCHANTABILITY or FITNESS FOR A PARTICULAR PURPOSE.  See the
    GNU General Public License for more details.

    You should have received a copy of the GNU General Public
    License along with this program in the file LICENSE; if not,
    write to the Free Software Foundation, Inc., 675 Mass Ave,
    Cambridge, MA 02139, USA.

    Contacts:

	Primary author:	 Mike Porter  mike@udel.edu
			 4 Brennen Ct.
			 Newark, DE 19713, USA

	Copyright Holder: postmaster@udel.edu
			  Network and Systems Services
			  University of Delaware
			  192 S. Chapel St.
			  Newark, DE 19713

    Module Description:

    List types and external interfaces for list.c.

    $Id: list.h,v 1.11 2002/09/12 16:46:05 mike Exp $

**/

#ifndef LIST
#define LIST 1

#define LIST_MAJOR 4
#define LIST_MINOR 3
#define LIST_PATCH 1

/*
    If list.c is compiled with LISTDEBUG, the program will
    exit with this value if an error is detected.
*/

#define LISTDEBUG_ERROR 16

/*
    list.c should be compiled as part of the application.  The
    object should be placed in the application's object directory,
    not list's source directory.  Parts of list can be removed by
    defining LIST_FEATURES and then not defining all the features
    listed below.
*/

#if !defined(LIST_FEATURES)
#define LIST_ARRAY_FEATURES 1
#define LIST_UNION_FEATURES 1
#define LIST_SORTED_FEATURES 1
#endif

/*
    Define the basic list type.
*/

typedef struct objlistHeader TobjlistHeader;
typedef TobjlistHeader * PTobjlistHeader;
typedef PTobjlistHeader * PPTobjlistHeader;

/*
    Context values are used to process lists.  They act as indexes
    into the list and are used by routines that interate the list.
    They are also used by routines that need a list element to
    operate on - most specifically ListRemove.  A context value
    maps one to one with a list element.  Contexts associated with
    certain elements can be saved and reused so long as the element
    still exists.  The context remains valid if the element is
    updated via ListUpdate.  For routines that do not explicitly
    return a context, ListGetContext can be called.
*/

typedef struct objlistContext TobjlistContext;
typedef TobjlistContext * PTobjlistContext;
typedef PTobjlistContext * PPTobjlistContext;
typedef PTobjlistContext (*PTobjlistContextArray)[];
typedef void * (*PTobjectArray)[];

/*
    Lists support user defined comparison routines.  A user defined
    comparison routine will compare p1 to p2 and return:

	p1 <  p2: -1
	p1 == p2:  0
	p1 >  p2:  1

    It is up to the comparator if the length values should be used
    in the comparison or not.  The lengths should be treated as the
    length to compare, not the length of the objects.

    Info is a user supplied field.  It can be used to stack
    comparators, for instance.  Or perhaps access a user supplied
    collating sequence.

    Some routines support a shorter argument list to a compare
    routine.  Specifically, ListQSort will use the shorter argument
    list routine, if set, over the longer one.  This will save a
    fair amount of CPU cycles - about 20-25%.  If you do not write
    a short form compare routine, you will not lose functionality;
    your code may not run quite as fast as it could.

    WARNING: libc qsort passes the address of locations in
    the array to sort.  In other words, if you are doing an
    address sort, then you usually have to deference the object.
    Our routines do not work that way since you are always getting
    a direct address of the objects to compare.  So, a compare
    routine for qsort and a compare routine for ListQSortShort
    are not the same.

    qsort:

    int cmp( const void * p1, const void * p2 ) {
        unsigned char * c1 = *((unsigned char **) p1;
        unsigned char * c2 = *((unsigned char **) p2;
	return( strcmp( c1, c2 );
    }

    ListQSortShort:

    int cmp( const void * p1, const void * p2 ) {
        unsigned char * c1 = (unsigned char *) p1;
        unsigned char * c2 = (unsigned char *) p2;
	return( strcmp( c1, c2 );
    }
*/

typedef int (*PTListComparator)( const void * p1, size_t l1,
			         const void * p2, size_t l2, void * );
typedef int (*PTListComparatorShort)( const void * p1, const void * p2 );

/*
    Objects:  Objects are what we insert into the list.  An object
    is always copied to dynamic storage when inserted, so objects
    can be in auto storage and inserted.  When the list is deleted,
    this storage is freed.  Of course, if the object itself has
    pointers to dynamic storage, the caller must free that storage
    before calling ListDelete.

    When calling a routine that returns a pointer to an object, a
    pointer to the dynamically allocated storage is returned to the
    caller.  It is valid for the caller to modify the area.  The
    caller must not free() the area.  If the area needs to be a
    reallocated, call ListUpdate with the new object pointer.  If
    the area is no longer wanted, call ListRemove.

    The length of the object is the true binary length.  For any
    'C' style string, this is strlen( MyString ) + 1, because the
    '\0' matters and must be kept with the string.  Because adding
    and subtracting the '\0' is error prone a series of special
    string routines exist.  They are named ListStrl...  and
    ListStr....  For instance, we have ListInsert, ListStrlInsert
    and ListStrInsert.

    An Strl routine that adds to the list takes an strlen(MyObject)
    argument and adds one internally to the length.  An Strl
    routine that returns an object returns the true length minus
    one.  The following calls are valid and equivalent:

    ListInsert( MyList, (void *) "MyString", strlen( "MyString" ) + 1 );
    ListStrlInsert( MyList, "MyString", strlen( "MyString" ) );
    ListStrInsert( MyList, "MyString" );

    Use an 'Strl' routine if you are inserting strings and know the
    length already.  An internal strlen call is saved.  If you
    don't know the length, then use an 'Str' routine.  If the
    object you are inserting is not a 'C' string, don't use
    either!
*/


#if defined(__STDC__)

/*
    Create a list.  Returns a pointer to a null list.

    MyList = ListCreate();
*/

PTobjlistHeader ListCreate( void );

/*
    Create a list, but specify the routines used for allocating and
    freeing storage.  'p' is an arbitrary parameter passed that can
    be used for any purpose.  Defaults are standard malloc and
    free.  Flags is used to define the type of object being
    allocated or freed.

    A NULL Deallocator causes ListDelete to return immediately.
    Presumably the storage pool management routines will delete the
    area associated with the list.

    The deallocator has the option to delete the entire list at
    once when the special flag ListMemList is used.  If the
    deallocator wants to delete the entire list, it should do so
    and return TRUE.  When the deallocator is called with
    ListMemList, the list header is passed as the object and the
    length is set to the size of the list header.

    If the deallocator does not want to, or is not able to delete
    the entire list in response to ListMemList, it should return
    FALSE.  In this case, the deallocator will be recalled once per
    header, node and object.
*/

#endif

enum ListFlags { ListMemHeader,	/* Allocate/free a list header */
    ListMemNode,	/* Allocate/free a list node */
    ListMemObject,	/* Allocate/free a list object */
    ListMemList,	/* Free the entire list */
#if defined(LIST_ARRAY_FEATURES)
    ListMemContextArray /* Allocate/free an array of context ptrs */
#endif
};

#if defined(__STDC__)

PTobjlistHeader
ListCreateWithAllocator(
    void * Allocator( int len, enum ListFlags, void * p ),
    int    Deallocator( void * o, int len, enum ListFlags, void * p ),
    void * AllocatorParam );

/*
    Delete a list.  Always returns NULL.  Best way to call is:

    MyList = ListDelete( MyList );

    Note that the Deallocator will be called once with special flag
    ListMemList.
*/

PTobjlistHeader ListDelete( PTobjlistHeader H );

/*
    Set or obtain the address of the Comparator, or its info.

    There is a default comparator that works like memcmp set when
    the list is created.

    The Short versions only take two parameters - the objects to
    be compared.  No lengths and no void * info pointers.
*/

PTListComparator ListGetComparator( PTobjlistHeader );
PTListComparator ListSetComparator( PTobjlistHeader, PTListComparator );
void * ListGetComparatorInfo( PTobjlistHeader );
void * ListSetComparatorInfo( PTobjlistHeader, void * );

PTListComparatorShort ListGetComparatorShort( PTobjlistHeader );
PTListComparatorShort ListSetComparatorShort( PTobjlistHeader,
					      PTListComparatorShort );

/*
    Returns the number of items in the list.
*/

unsigned int ListCnt( PTobjlistHeader H );

/*
    Returns the size of the main list header and the size of
    list node.  This information is useful to those that are
    using cell pool storage allocation.  There is one header
    per list and one list node per object in the list.
*/

void ListInfo( unsigned int * HeaderSize, unsigned int * NodeSize );

/*
    Insert an object at the head of the list.
*/

void ListInsert( PTobjlistHeader H, const void * O, int len );
void ListStrlInsert( PTobjlistHeader H, const char * O, int len );
void ListStrInsert( PTobjlistHeader H, const char * O );

/*
    Insert an object at the end of the list.
*/

void ListAppend( PTobjlistHeader H, const void * O, int len );
void ListStrlAppend( PTobjlistHeader H, const char * O, int len );
void ListStrAppend( PTobjlistHeader H, const char * O );

/*
    Insert an object, keeping the list sorted.  Uses strcmp.  Note
    that the object need not be simple string, it only has to start
    with a string.  For instance,

    "MyKey\000<binary-data>"  can be inserted and will be sorted
    using the value "MyKey".

    The 'Strl' or 'Str' versions can be used if the *entire* object
    is a string.

    ListQSort does a Quick Sort on the list.  Extracting all the
    object pointers to an array and calling the libc quicksort
    can be faster because more optimizations are possible on
    a quicksort done on an array.  However, there are cases,
    particularly when there are large numbers of duplicate keys,
    and on some processors, that quicksorting the linked list is
    faster.  Also, some implementations of qsort are really bad.
    In this case, ListQSort is way, way, faster.
*/

#if defined(LIST_SORTED_FEATURES)
void ListInsertSorted( PTobjlistHeader H, const void * O, int len );
void ListStrlInsertSorted( PTobjlistHeader H, const char * O, int len );
void ListStrInsertSorted( PTobjlistHeader H, const char * O );

void ListQSort( PTobjlistHeader H );
#endif

/*
    Updates the object associated with Context.  Adds the new
    object at the same location in the list and deallocates the old
    object.  Note that objects can always be modified, but if the
    length changes (shortens), and update might be desirable.  Does
    not maintain sort order etc.  The Context value is created by
    one of the find type routines.
*/

void ListUpdate( PTobjlistHeader H, PPTobjlistContext Context,
		 const void * O, int len );
void ListStrlUpdate( PTobjlistHeader H, PPTobjlistContext Context,
		 const char * O, int len );
void ListStrUpdate( PTobjlistHeader H, PPTobjlistContext Context,
		 const char * O );

/*
    Find first object in the list.  ListStrlFirst will return
    strlen( O ) as the length and ListStrFirst doesn't return the
    length at all.

    Context can be NULL if you do not need the context.

    For ListFirst, len can be a NULL ptr.
*/

int ListFirst( PTobjlistHeader H, PPTobjlistContext Context, 
		void ** O, int * len );
int ListStrlFirst( PTobjlistHeader H, PPTobjlistContext Context, 
		char ** O, int * len );
int ListStrFirst( PTobjlistHeader H, PPTobjlistContext Context, 
		char ** O );

/*
    Find last object in the list.  ListStrlLast will return
    strlen( O ) as the length and ListStrLast doesn't return the
    length at all.

    Context can be NULL if you do not need the context.

    For ListLast, len can be a NULL ptr.
*/

int ListLast( PTobjlistHeader H, PPTobjlistContext Context, 
	       void ** O, int * len );
int ListStrlLast( PTobjlistHeader H, PPTobjlistContext Context, 
	       char ** O, int * len );
int ListStrLast( PTobjlistHeader H, PPTobjlistContext Context, 
	       char ** O );

/*
    Find next object in the list.  ListStrlNext will return
    strlen(O) as the length and ListStrNext doesn't return the
    length at all.

    A Context whose value is NULL will cause the first object.
    to be returned.  That is:

    Context = NULL;
    ListNext( MyList, &Context, &Object, &Len )

    is the same as calling

    ListFirst( MyList, &Context, &Object, &Len );

    with Context set to an undefined value.

    If there is no object. returns FALSE, and Context == NULL.

    For ListNext, len can be a NULL ptr.

    List*Prev routines act the same as the Next routines, except
    they go backwards through the list.
*/

int ListNext( PTobjlistHeader H, PPTobjlistContext Context, 
	       void ** O, int * len );
int ListStrlNext( PTobjlistHeader H, PPTobjlistContext Context, 
	       char ** O, int * len );
int ListStrNext( PTobjlistHeader H, PPTobjlistContext Context, 
	       char ** O );
int ListPrev( PTobjlistHeader H, PPTobjlistContext Context, 
	       void ** O, int * len );
int ListStrlPrev( PTobjlistHeader H, PPTobjlistContext Context, 
	       char ** O, int * len );
int ListStrPrev( PTobjlistHeader H, PPTobjlistContext Context, 
	       char ** O );

/*
    Find an object in the list.  ListFind will compare the first
    'len' bytes to each object in the list using memcmp.  It will
    return the first object that matches.

    ListStrlFind and ListStrFind use strcmp( O, ListElement->object )
    and return the first object that matches.  ListStrlFind returns
    strlen( RO ) in rlen and ListStrFind does not return the length
    of the object located.

    These routines return TRUE if the object is located, else
    FALSE.  If FALSE is returned, RO is set to NULL and rlen, if
    used, is not modified.

    For all find routines, RO and rlen can be NULL.

    ListGetContext is used to obtain the context for the last
    object found.  A list always has a context (NULL means there is
    nothing in the list).  The context is set to the last value
    added or found.
*/

int ListFind( PTobjlistHeader H, const void * O, int len,
	      void ** RO, int * rlen );
int ListStrlFind( PTobjlistHeader H, const char * O, int len,
	      char ** RO, int * rlen );
int ListStrFind( PTobjlistHeader H, const char * O, 
	      char ** RO );

/*
    Context routines.

    ListGetContext returns the current context.  The context is set
    by any routine that adds, finds, moves or deletes objects.  A
    NULL context means the list is empty.  The rlen pointer can be
    NULL.

    We never really needed to pass the list itself in order
    to perform this operation.  And in some cases, it is
    inconvientent to do so.  So, we make similar routines
    available with the 'N' suffix.
*/

PTobjlistContext ListGetContext( PTobjlistHeader H );
void ListGetObject( PTobjlistHeader H, PPTobjlistContext,
    void ** RO, int * rlen );
void ListStrlGetObject( PTobjlistHeader H, PPTobjlistContext,
    char ** RO, int * rlen );
void ListStrGetObject( PTobjlistHeader H, PPTobjlistContext, char ** RO );

void ListGetObjectN( PPTobjlistContext, void ** RO, int * rlen );
void ListStrlGetObjectN( PPTobjlistContext, char ** RO, int * rlen );
void ListStrGetObjectN( PPTobjlistContext, char ** RO );

/*
    Removes the object referenced by the Context.  The Context is
    set to the next object in the list, or NULL if the list is
    empty.  Any storage allocated internally by the list management
    routines and associated with the object is freed.  The following
    will remove all elements in the list:

    ListFirst( MyList, &Context, &Dummy, &Dummy2 );
    while( Context != NULL ) {
        ListRemove( MyList, &Context );
    }

    This is *not* the same as ListDelete because in the above
    example, the list itself still exists, thought it does not
    contain anything.  Code could be inserted above the
    'ListRemove' call to free dynamic memory pointed to by the
    object (not the object itself, pointers in the object), and
    then calling ListDelete at loop termination.
*/

void ListRemove( PTobjlistHeader H, PPTobjlistContext Context );

/*
    Returns the union of SubList and MainList in MainList.
    Destroy's SubList.  Returns a pointer to MainList.
    ListStrAccumulate is an old, deprecated, name.
*/

#if defined(LIST_UNION_FEATURES)
PTobjlistHeader ListStrAccumulate( PTobjlistHeader SubList,
    PTobjlistHeader MainList );
PTobjlistHeader ListStrUnion( PTobjlistHeader SubList,
    PTobjlistHeader MainList );
#endif

/*
    Appends the objects in 'From' to the list 'To'.  The from list
    is not changed.  The objects are copied.  So long as the
    objects themselves do not contain pointers, the two lists do
    not share any data and can be manipulated with no
    interdependancies.
*/

void ListCopy( PTobjlistHeader From, PTobjlistHeader To );

/*
    ListArrayContext returns an array of Contexts for objects in
    the list.  ListGetObject can be used to access the object.
    ListArray returns an array of object pointers.  Use
    ListArrayContext if you need object length information, or will
    be deleting and/or manipulating the list using the contexts.
    Use ListArray if the object pointers alone will suffice.  Note
    that the object pointers returned by ListArray point directly
    to the objects in the list.  Take care not to free objects
    still in the list, etc.

    If an array of object pointers is obtain using ListArray, then
    the list can be quickly reordered using the array and a call to
    ListArrayUpdate.  Note that a similar operation can not be
    performed with Context values.
 
    WARNING: length information is lost when a ListArrayUpdate is
    performed.

    WARNING: Context values are invalid when a ListArrayUpdate
    is done.
*/

#if defined(LIST_ARRAY_FEATURES)

PTobjlistContextArray ListArrayContext( PTobjlistHeader );
PTobjectArray ListArray( PTobjlistHeader );
PTobjlistHeader ListArrayUpdate( PTobjlistHeader,
    PTobjectArray );

#endif

#else
PTobjlistHeader ListCreate();
PTobjlistHeader ListCreateWithAllocator();
PTListComparator ListGetComparator();
PTListComparator ListSetComparator();
void * ListGetComparatorInfo();
void * ListSetComparatorInfo();
PTobjlistHeader ListDelete();
void ListInsert();
void ListStrlInsert();
void ListStrInsert();
void ListAppend();
void ListStrlAppend();
void ListStrAppend();
#if defined(LIST_SORTED_FEATURES)
void ListInsertSorted();
void ListStrlInsertSorted();
void ListStrInsertSorted();
#endif
void ListUpdate();
void ListStrlUpdate();
void ListStrUpdate();
int ListFirst();
int ListStrLFirst();
int ListStrFirst();
int ListLast();
int ListStrlLast();
int ListStrLast();
void ListNext();
void ListStrlNext();
void ListStrNext();
void ListPrev();
void ListStrlPrev();
void ListStrPrev();
int ListFind();
int ListStrlFind();
int ListStrFind();
PTobjlistContext ListGetContext();
void ListGetObject();
void ListStrlGetObject();
void ListStrGetObject();
void ListGetObjectN();
void ListStrlGetObjectN();
void ListStrGetObjectN();
int ListRemove();
#if defined(LIST_UNION_FEATURES)
PTobjlistHeader ListStrAccumulate();
PTobjlistHeader ListStrUnion();
#endif
unsigned int ListCnt();
void ListInfo();
void ListCopy();

#if defined(LIST_ARRAY_FEATURES)
*(PTobjlistContext[0]) ListArray();
PTobjlistContextArray ListArrayContext();
PTobjectArray ListArray();
PTobjlistHeader ListArrayUpdate();
#endif
#endif /* __STDC__ */

#endif

/**
    End of list.h.
**/
