/**
    $Id: qsort.h,v 1.35 2005/04/20 18:18:47 mike Exp $

    This file contains a template routine for quick sorting a list.
    Define CMPARGS appropriately and a routine header.  Then,
    include this file.  Also, define PTCOMPARATOR to be the
    type of the comparator routine.
**/

/**
    QSort a list.

    While processing the sublists, keep track of the middle node
    in the list.

    When pushing a sublist on the stack, compare the first,
    middle and last values.  Choose the node with the middle
    value to become the pivot.  Rearrange the nodes in order,
    keeping their positions, and use this fact later on in
    the loops.

    QuickSort is traditionally done with a left list and a right
    list.  This routine adds a middle list that consists of the
    pivot and nodes whose values equal the pivot.  The left list
    and right list need to be sorted, but the nodes that end up
    in the pivot list are in the proper position and so do not
    need to be looked at again.

    See the GNU libc implementation for some notes on this
    implementation.  Also, see the Sedgewick algorithms book.

    Some thoughts:

    1)  This route is somewhat slow.  It is slower than extracting
 	the pointers to the objects into an array and running
	gnulibc qsort on the result.  It is also slower than the
	mergesort in glib.  It is not really, really slow, but
	it is cetainly not faster.
    2)  Unlike either of the above methods, this routine does not
	use space related to the input size.  The stack used is
	relatively small.
    3)  This route is very fast if there are duplicate keys.

    I worked on getting the inner loops tight.  This is why the
    two lists are processed seperately.  This allows us to make
    the loop exit conditions based soley on the comparison codes -
    except the node equal.  However, node equal to pivot is such
    a huge win that we can accept the extra test.

    Interestly, this code is faster than glib on an AMD Opteron
    when compiled by gcc with random input.
**/

{

#define MEASURE 0
#define QSORTDEBUG 0

#if QSORTDEBUG
#define DIAG 1
#else
#define DIAG 0
#endif

/*
    We need a small stack.  If we push the larger partition
    first, we only need lg(n) stack space.  We can figure out
    the maximum number of nodes that will be on the stack based
    on pointer sizes.
*/

#if defined(CHAR_BIT)
#define QSORT_STACK_SIZE      (CHAR_BIT * sizeof( void * ))
#else
#define QSORT_STACK_SIZE      (8 * sizeof( void * ))
#endif

    PTobjlist Stack[ QSORT_STACK_SIZE * 3 ];
    PTobjlist * sp = &(Stack[ 0 ]);
#if QSORTDEBUG
    int Stackcnt[ QSORT_STACK_SIZE ];
    int * pcnt = &(Stackcnt[ 0 ]);
#endif

#if MEASURE
#define START(n) start[n] = clock()
#define END(n) end[n] = clock(); acc[n] += (end[n] - start[n])
#define ITER(n) iter[n]++
#else
#define START(n)
#define END(n)
#define ITER(n)
#endif

/*
    APPEND - Removes list s...e from the list it was in and
    appends to Ptobjlist 'a'.  Node 'e' is not properly connected
    to anything.  APPEND isn't used because there are special
    cases where we can write better code.  However, I keep it
    to document what is happening in those special cases.

    INSERT - Inserts the list s...e into a list, after PTobjlist a.
*/

#define APPEND( s, e, a )			\
    {						\
	s->prev->next	= e->next;		\
	e->next->prev	= s->prev;		\
						\
	a->next		= s;			\
	s->prev		= a;			\
    }

#define INSERT( s, e, a )			\
    {						\
	PTobjlist * pan = &(a->next);		\
	PTobjlist an = *pan;			\
						\
	e->next		= an;			\
	an->prev	= e;			\
						\
	*pan		= s;			\
	s->prev		= a;			\
    }

#if QSORTDEBUG
#define PRINTLIST( l, mh, mc )		\
    {					\
	PTobjlist x; int i;		\
					\
        printf( l "%d: ", mc );		\
        for( i=0, x = mh; i < mc; x = x->next, i++) {	\
	    printf( "%s,", (char *) x->object );	\
	}						\
	printf( "\n" );					\
        printf( "--- backwards - %d: ", mc );		\
        for( i=0, x = x->prev; i < mc; x = x->prev, i++) {	\
	    printf( "%s,", (char *) x->object );	\
	}						\
	printf( "\n" );					\
    }
#define PRINTNODE( l, n )		\
	printf( l " (%p): '%s'\n", n, (char *) n->object );
#else
#define PRINTLIST( l, mh, mc )
#define PRINTNODE( l, n )
#endif

#if DIAG
#define CHECKEQU( cmp3_h, cmp3_n, cmp3_t, cmp3_cnt ) \
    if (cmp3_cnt > 2 && (cmp3_h == cmp3_n || cmp3_n == cmp3_t)) {	\
        printf( "CHECKEQU: '%s' (%p), '%s' (%p), '%s' (%p)\n",		\
	    (char *) cmp3_h->object, cmp3_h,				\
	    (char *) cmp3_n->object, cmp3_n,				\
	    (char *) cmp3_t->object, cmp3_t );				\
	exit( 1 );							\
    }
#define CHECKBALANCE( cmp3_h, cmp3_n, cmp3_t, cmp3_cnt ) \
    if (cmp3_cnt > 2) {						\
	PTobjlist cmp3_x = cmp3_h;					\
	int cmp3_l = 0;							\
	int cmp3_r = 0;							\
									\
	while( cmp3_x != cmp3_n ) {					\
	    cmp3_l++;							\
	    cmp3_x = cmp3_x->next;					\
	}								\
	while( cmp3_x != cmp3_t ) {					\
	    cmp3_r++;							\
	    cmp3_x = cmp3_x->next;					\
	}								\
	cmp3_l	-= cmp3_r;						\
	if (cmp3_l < -1 || cmp3_l > 1) {				\
	    printf( "CMP3: %d, %d: %d.\n", cmp3_l, cmp3_r, cmp3_cnt );	\
	    printf( "UNBALANCED!!!\n" );				\
	    exit( 1 );							\
	}								\
    }
#else
#define CHECKEQU( cmp3_h, cmp3_n, cmp3_t, cmp3_cnt )
#define CHECKBALANCE( cmp3_h, cmp3_n, cmp3_t, cmp3_cnt )
#endif

#define CMP3( cmp3_h, cmp3_n, cmp3_t, cmp3_cnt )			\
    CHECKEQU( cmp3_h, cmp3_n, cmp3_t, cmp3_cnt );			\
    CHECKBALANCE( cmp3_h, cmp3_n, cmp3_t, cmp3_cnt );			\
    if (cmp3_cnt > 2) {							\
	if ((cmprtn) CMPARGS( cmp3_n->object, cmp3_n->len,		\
		    cmp3_h->object, cmp3_h->len, ci ) < 0) {		\
	    if ((cmprtn) CMPARGS( cmp3_t->object, cmp3_t->len,		\
			cmp3_n->object, cmp3_n->len, ci ) < 0) {	\
		swap( &cmp3_h, &cmp3_t );				\
	    } else if ((cmprtn) CMPARGS( cmp3_t->object, cmp3_t->len,	\
			cmp3_h->object, cmp3_h->len, ci ) < 0) {	\
		swap3a( &cmp3_h, &cmp3_n, &cmp3_t ); /* n,t,h */	\
	    } else {							\
		swap( &cmp3_h, &cmp3_n );				\
	    }								\
	} else if ((cmprtn) CMPARGS( cmp3_t->object, cmp3_t->len,	\
			cmp3_n->object, cmp3_n->len, ci ) < 0) {	\
	    if ((cmprtn) CMPARGS( cmp3_t->object, cmp3_t->len,		\
			cmp3_h->object, cmp3_h->len, ci ) < 0) {	\
		swap3b( &cmp3_h, &cmp3_n, &cmp3_t ); /* t,h,n */	\
	    } else {							\
		swap( &cmp3_n, &cmp3_t );				\
	    }								\
	}								\
    } else if (cmp3_cnt == 2) {						\
	if ((cmprtn) CMPARGS( cmp3_t->object, cmp3_t->len,		\
		    cmp3_h->object, cmp3_h->len, ci ) < 0) {		\
	    swap( &cmp3_h, &cmp3_t );					\
	}								\
    }

/*
    This macro is used to make the temp list headers for the
    portions of the left side, right side, and pivot equal nodes.
    Copies the variable name passed to one with _save appeneded
    to the base name.  This gives a fast initialization at the
    top of the loops.
*/

#define INITLIST( initlist_l, initlist_cnt ) \
    {					\
	int i;				\
					\
	for( i = 0; i < initlist_cnt; i++ ) {	\
	    initlist_l[ i ].tail	= &initlist_l[ i ].dummy;	\
	    initlist_l[ i ].cnt		= 0;				\
	    initlist_l[ i ].dummy.prev	= initlist_l[ i ].tail;		\
	    initlist_l[ i ].dummy.next	= initlist_l[ i ].tail;		\
	    initlist_l[ i ].dummy.object= Hdr->objlist.object;		\
	}								\
	memcpy( initlist_l##_save, initlist_l, sizeof initlist_l##_save ); \
    }

/*
    Possibly push a sublist on the stack.  If the list is only
    one object, then it never needs to be sorted.  If it is less
    than INS_BE in size, then do an insertion sort and don't push
    it on the stack.  Otherwise, push it on, we'll pop it later
    and QuickSort it then.
*/

#if QSORTDEBUG
#define PUSHCNT(c) *(pcnt++) = c;
#else
#define PUSHCNT(c)
#endif

#if QSORTDEBUG
#define SETCNT( set_cnt ) cnt = set_cnt
#else
#define SETCNT( set_cnt )
#endif

#if QSORTDEBUG
#define PUSH( push_h, push_n, push_t, push_c )				\
    PRINTLIST( "Pushing List: ", push_h, push_c );			\
    if (push_h == NULL || push_h->object == Hdr->objlist.object) {	\
	PRINTNODE( "Attempting bad header push", push_h );		\
	exit(1 );							\
    }									\
    if (push_n == NULL || push_n->object == Hdr->objlist.object) {	\
	PRINTNODE( "Attempting bad middle push", push_n );		\
	exit(1 );							\
    }									\
    if (push_t == NULL || push_t->object == Hdr->objlist.object) {	\
	PRINTNODE( "Attempting bad tail push", push_t );		\
	exit(1 );							\
    }									\
    *(sp++) = push_h;							\
    *(sp++) = push_n;							\
    *(sp++) = push_t;							\
    PUSHCNT( push_c );
#else
#define PUSH( push_h, push_n, push_t, push_c )				\
    *(sp++) = push_h;							\
    *(sp++) = push_n;							\
    *(sp++) = push_t;
#endif

/*
    This structure is used to keep track of a list that is being
    moved to the other side of the pivot or is equal to the pivot.
    Typically used in an array of two, entries are added to the
    shorter of the two lists.
*/

    struct shiftList {
	PTobjlist tail;
	Tobjlist dummy;
	int cnt;
    };

    typedef struct shiftList TshiftList;

    PTobjlist h;		/* List head */
    PTobjlist t;		/* List tail */

    PTobjlist rm;		/* Middle of right list */
    PTobjlist rp;		/* Current node to process on right */
    int rcnt;			/* Count of objects in right list */

    PTobjlist lm;		/* Middle of left list */
    PTobjlist lp;		/* Current node to process on left */
    int lcnt;			/* Count of objects in left list */

    TshiftList sl[ 2 ];		/* Holds sublists */

    PTobjlist n;		/* Pivot node */
    TshiftList ns[ 1 ];		/* Dummy node for pivot nodes */

    void * pivot;		/* Pivot object ptr */
    int    pivot_len;		/* And its length */

    TshiftList sl_save[ 2 ];	/* Place to save a fully initialized 'sl' */
    TshiftList ns_save[ 1 ];	/* Place to save a fully initialized 'ns' */

    int i;
    int cmp;			/* Results of the compare */
    int cnt;

#if MEASURE
    clock_t start[2];
    clock_t end[2];
    clock_t acc[2];
    int iter[20];
#endif

    PTCOMPARATOR cmprtn;

#if !defined( SHORTCMP )
    void * ci = Hdr->ComparatorInfo;		/* "      " */
#endif

    if (Hdr->ComparatorShort != NULL) {
	cmprtn =  (PTCOMPARATOR) Hdr->ComparatorShort;
    } else {
        cmprtn = (PTCOMPARATOR) Hdr->Comparator;
    }

#if MEASURE
    memset( &start, 0, sizeof start );
    memset( &end, 0, sizeof end );
    memset( &acc, 0, sizeof acc );
    memset( &iter, 0, sizeof iter );
#endif

#if QSORTDEBUG
    printf( "--- Entering QSort.\n" );
#endif

/*
    Find the middle node.  This is actually pretty quick to do.
*/

    h   = Hdr->objlist.next;
    t   = Hdr->objlist.prev;
    cnt = Hdr->cnt;

    for( n = h, i = Hdr->cnt / 2; i-- > 0; n = n->next );	/* NOTE ; */

#if QSORTDEBUG
    printf( "--- h, n, t initially are: '%s', '%s', '%s'\n",
	    (char *) h->object,
	    (char *) n->object,
	    (char *) t->object );
#endif

    CMP3( h, n, t, cnt );

    if (cnt <= 3) return;

/*
    Set up the dummy lists for moving lists across the pivot.
*/

    INITLIST( sl, 2 );
    INITLIST( ns, 1 );

    while( 1 ) {
	PRINTNODE( "--- Starting h", h );
	PRINTNODE( "    Starting n", n );
	PRINTNODE( "    Starting t", t );
	PRINTLIST( "    list: ", h, cnt );
	PRINTLIST( "    Part of: ", Hdr->objlist.next, Hdr->cnt );

/*
    Set up the accumlator dummys and pointers.
*/

 	memcpy( sl, sl_save, sizeof sl_save );
	memcpy( ns, ns_save, sizeof ns_save );

	lm	= h;		/* Set up list middle (previous ptr) */
	lp	= h;		/* Get first node */
	lcnt	= 0;

	rp	= t;		/* Will change to one prior once we know it */
	rcnt	= 0;

	pivot	  = n->object;	/* Drag some pointers out of the pivot */
	pivot_len = n->len;

/*
    Process the left side.  Move nodes that belong on the right
    after 'rp'.  Move nodes equal to the pivot to after 'n',
    and update n.  Keep track of the median left node.
*/

	cmp	= -1;			/* First node is < pivot */

	while( 1 ) {			/* Left pointer not at pivot yet */
	    ITER( 0 );
	    if (cmp < 0) {		/* Skip nodes already on left side */
		do {
		    lp	= lp->next;
		    if (lcnt++ & 1) lm = lm->next;
		    cmp = (cmprtn)
			CMPARGS( lp->object, lp->len, pivot, pivot_len, ci );
		} while( cmp < 0 );
		ITER( 1 );
	    } 

	    if (cmp > 0) {		/* Find nodes to move to the right */
		PTobjlist nt;
		PTobjlist lh = lp;	/* Head of sublist */
		int l;
		int i = 0;

		l	= (sl[ 0 ].cnt > sl[ 1 ].cnt) ? 1 : 0;

		do {
		    lp	= lp->next;
		    i++;
		    cmp = (cmprtn)
			CMPARGS( lp->object, lp->len, pivot, pivot_len, ci );
		} while( cmp > 0 );
		ITER( 2 );

		sl[ l ].cnt += i;

/*
    Roughly:

	nt	= lp->prev;
	APPEND( lh, nt, sl[ l ].tail );
	sl[ l ].tail = nt;
*/

		nt	= sl[ l ].tail;
		sl[ l ].tail = lp->prev;

		nt->next	= lh;
		lh->prev->next	= lp;
		lp->prev	= lh->prev;
		lh->prev	= nt;
	    } else {			/* Nodes equal to pivot */
		PTobjlist nt;
		PTobjlist lh = lp;	/* Head of sublist */

		if (lp == n) break;	/* This is what ends the loop */

		do {
		    if (lp == n) break;
		    lp	= lp->next;
		    cmp = (cmprtn)
			CMPARGS( lp->object, lp->len, pivot, pivot_len, ci );
		} while( cmp == 0 );
		ITER( 3 );

		nt	= ns[ 0 ].tail;		/* Append... */
		ns[ 0 ].tail = lp->prev;
		nt->next	= lh;
		lh->prev->next	= lp;
		lp->prev	= lh->prev;
		lh->prev	= nt;
	    }
	}

/*
    The above code attempted to balance nodes on sl[ n ].  Now,
    insert the sl_dummy lists, set the middle node and adjust.
*/

	rm	= t;
	ITER(4);
	
	PRINTNODE( "Before left to right move, middle right node: ", rm );

	if (sl[ 0 ].cnt > 0) {
	    PRINTLIST( "sl[0].dummy.next: ", sl[0].dummy.next, sl[0].cnt );
	    INSERT( sl[ 0 ].dummy.next, sl[ 0 ].tail, t );
	    t	= sl[ 0 ].tail;
	    rm	= t;
	}

	if (sl[ 1 ].cnt > 0) {
	    PRINTLIST( "sl[1].dummy.next: ", sl[1].dummy.next, sl[1].cnt );
	    INSERT( sl[ 1 ].dummy.next, sl[ 1 ].tail, t );
	    t	= sl[ 1 ].tail;
	}

	if (sl[ 0 ].cnt > sl[ 1 ].cnt) {
	    int mcnt = (sl[ 0 ].cnt - sl[ 1 ].cnt) / 2;

	    for( i = 0; i < mcnt; i++ ) {
		ITER(5);
		rm = rm->prev;
	    }
	} else if (sl[ 1 ].cnt > sl[ 0 ].cnt) {
	    int mcnt = (sl[ 1 ].cnt - sl[ 0 ].cnt - 1) / 2;

	    for( i = 0; i <= mcnt; i++ ) {
		ITER(6);
		rm = rm->next;
	    }
	}
	rcnt	+= (sl[ 0 ].cnt + sl[ 1 ].cnt);

	PRINTLIST( "After left to right move: ", h, cnt );
	PRINTNODE( "Middle right node: ", rm );
END(0);

/*
    Process the right side.
*/

START(1);
 	memcpy( sl, sl_save, sizeof sl_save );

	cmp	= 1;		/* We know first node >= pivot */
	PRINTNODE( "Start start of right, rm: ", rm );

	while( 1 ) {
	    ITER( 7 );
	    if (cmp > 0) {	/* Nodes already on right side */
		do {
		    rp	= rp->prev;
		    if (rcnt++ & 1) rm = rm->prev;
		    cmp = (cmprtn)
			CMPARGS( rp->object, rp->len, pivot, pivot_len, ci );
		} while( cmp > 0 );
		ITER( 8 );
	    } 

	    if (cmp < 0) {	/* Nodes that need to move to left */
		PTobjlist rh = rp;	/* "Head" (really tail!) of a sublist */
		int l;
		int i = 0;


		l	= (sl[ 0 ].cnt > sl[ 1 ].cnt) ? 1 : 0;

		do {
		    rp	= rp->prev;
		    i++;
		    cmp = (cmprtn)
			CMPARGS( rp->object, rp->len, pivot, pivot_len, ci );
		} while( cmp < 0 );
		ITER( 9 );

		sl[ l ].cnt += i;

/*
    Like:
		APPEND( rp->next, rh, sl[ l ].tail );
		sl[ l ].tail = rh;
*/

		rp->next->prev		= sl[ l ].tail;
		sl[ l ].tail->next	= rp->next;
		sl[ l ].tail		= rh;
		rh->next->prev		= rp;
		rp->next		= rh->next;
	    } else {			/* Nodes equal to the pivot */
		PTobjlist rh = rp;	/* "Head" (really tail!) of a sublist */

		if (rp == n) break;

		do {
		    rp	= rp->prev;
		    if (rp == n) break;
		    cmp = (cmprtn)
			CMPARGS( rp->object, rp->len, pivot, pivot_len, ci );
		} while( cmp == 0 );
		ITER( 10 );

		rp->next->prev		= ns[ 0 ].tail;
		ns[ 0 ].tail->next	= rp->next;
		ns[ 0 ].tail		= rh;
		rh->next->prev		= rp;
		rp->next		= rh->next;
	    }
	}

	rp	= rp->next;		/* Make rp point to "last" node */

/*
    Add any node equal nodes into the list.  Gives us the end of the
    left list (ns[ 0 ].dummy.next->prev), also.
*/

	if (sl[ 0 ].cnt > 0) {
	    PTobjlist lmp = lm->prev;

	    PRINTLIST( "sl[0].dummy.next: ", sl[0].dummy.next, sl[0].cnt );
	    INSERT( sl[ 0 ].dummy.next, sl[ 0 ].tail, lmp );

	    if (lm == h) h = sl[ 0 ].dummy.next;	/* Need to move head? */
	}

	if (sl[ 1 ].cnt > 0) {
	    PRINTLIST( "sl[1].dummy.next: ", sl[1].dummy.next, sl[1].cnt );
	    INSERT( sl[ 1 ].dummy.next, sl[ 1 ].tail, lm );
	}
	PRINTLIST( "After right to left move: ", h, lcnt );
	PRINTNODE( "Before adjusting, middle left node: ", lm );

	if (sl[ 0 ].cnt > sl[ 1 ].cnt) {
	    int mcnt = (sl[ 0 ].cnt - sl[ 1 ].cnt) / 2;

	    if (!(lcnt & 1)) mcnt++;
	    for( i = 0; i < mcnt; i++ ) {
		ITER( 12 );
		lm = lm->prev;
	    }
	} else if (sl[ 1 ].cnt > sl[ 0 ].cnt) {
	    int mcnt = (sl[ 1 ].cnt - sl[ 0 ].cnt) / 2;

	    for( i = 0; i < mcnt; i++ ) {
		ITER( 13 );
		lm = lm->next;
	    }
	}
	lcnt	+= (sl[ 0 ].cnt + sl[ 1 ].cnt);

	PRINTNODE( "After adjusting, middle left node: ", lm );

	if (ns[ 0 ].tail != &ns[ 0 ].dummy) {	/* Found nodes == pivot */
	    PTobjlist np = n->prev;
	    INSERT( ns[ 0 ].dummy.next, ns[ 0 ].tail, np );
	    lp	= ns[ 0 ].dummy.next->prev;
	} else {
	    lp	= n->prev;
	}

/*
    Make H <= M <= T be true for both sublists.  Then decide if we
    need to push any, and what to process.  If this falls through,
    pop and continue.  Need to set node pointers into variables
    to avoid macro oddities.
*/

	ITER( 14 );
	{
	    PTobjlist temp;

	    PRINTLIST( "Left list: ", h, lcnt );
	    PRINTNODE( "    Middle", lm );
	    CMP3( h, lm, lp, lcnt );
	    PRINTLIST( "Left list, reordered: ", h, lcnt );
	    PRINTNODE( "    Middle", lm );

	    PRINTLIST( "Right list: ", n->next, rcnt );
	    PRINTNODE( "    Middle", rm );
	    temp = n->next;
	    CMP3( temp, rm, t, rcnt );
	    PRINTLIST( "Right list, reordered: ", n->next, rcnt );
	    PRINTNODE( "    Middle", rm );
	}

/*
    This really should be 3.  It's fun to change it and see what
    happens to the run time.  Note that the output list is not
    sorted unless this IS 3, or you run some sort of insertion
    sort over the final list.  Changing this value does not impact
    the run time as much as you might think.  That is, changing
    to a 9 doesn't cause a random list to sort much faster.
    This is why I don't use an insertion sort.
*/

#define ENDCNT 3

	if (lcnt > ENDCNT && rcnt > ENDCNT) {
	    if (lcnt < rcnt) {
		PRINTLIST( "Large right, right push: ", n->next, rcnt );
		PUSH( n->next, rm, t, rcnt );
		ITER( 15 );
		n	= lm;
		t	= lp;
		SETCNT( lcnt );
		continue;
	    } else {
		PRINTLIST( "Large left, left push: ", h, lcnt );
		PUSH( h, lm, lp, lcnt );
		ITER( 16 );
		h	= n->next;
		n	= rm;
		SETCNT( rcnt );
		continue;
	    }
	} else if (lcnt <= ENDCNT) {
	    if (rcnt > ENDCNT) {
		h	= n->next;
		n	= rm;
		SETCNT( rcnt );
		continue;
	    }
	} else if (rcnt <= ENDCNT) {
	    n	= lm;
	    t	= lp;
	    SETCNT( lcnt );
	    continue;
	}

	if (sp == &(Stack[ 0 ])) break;
	t  = *(--sp);
	n  = *(--sp);
	h  = *(--sp);
	SETCNT( *(--pcnt) );
	ITER( 17 );
    }

#if MEASURE
    printf( "0: Total loop time: %f\n", acc[0] / (double) CLOCKS_PER_SEC );
    printf( "1: Total loop time: %f\n", acc[1] / (double) CLOCKS_PER_SEC );

    {
	int i;

	for( i = 0; i < 20; i++ ) {
	    printf( "iter[%d] = %d.\n", i, iter[i] );
 	}
    }
#endif
}

#undef QSORT_STACK_SIZE
#undef MEASURE
#undef QSORTDEBUG
#undef START
#undef END
#undef PRINTLIST
#undef PUSH

/**
    End of QSort.
**/

/**
    End of qsort.h.
**/
